
declare interface ChatMessageData1<ChatMessageData2Type = unknown> extends EntityBaseData<ChatMessageData2Type> {
	speaker: { scene: string, actor: string, token: string, alias: string };			
	flavor: string;		// Flavor text, like "X rolls for initiative!" or some such. TODO: More info
	template: unknown;	
	user: string;		// ID of the user?
	content: string;	
	type: string;
	blind: boolean;
}




declare class ChatMessage<ChatMessageData1Type extends ChatMessageData1<any> = ChatMessageData1> extends Entity<ChatMessageData1Type, never> {
    static getSpeaker(arg: { token: Token<any, any>, alias?: string }): { ChatMessage: number; token: number; actor: string, alias: string };
	static getSpeaker(arg: { actor: Actor<any, any, any>, alias?: string }): { ChatMessage: number; actor: string, alias: string };
	static getSpeaker(arg: { ChatMessage: ChatMessageData1, alias?: string }): { ChatMessage: number; actor: string, alias: string };
	static getSpeaker(arg?: { ChatMessage?: ChatMessageData1, token?: Token<any, any>, actor?: Actor<any, any, any>, alias?: string }): { ChatMessage: number | null; actor: string | null, token: number | null, alias: string };

	get alias(): string;
	get isAuthor(): boolean;
	get isRoll(): boolean;
	get isContentVisible(): boolean;

	get roll(): Roll<unknown>;

	// TODO: Get the correct options type--doesn't seem to be used though??
	render(force: boolean, options?: {}): Promise<void>;
}