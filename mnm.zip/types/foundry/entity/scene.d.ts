
interface SceneBaseData<
    SceneData2Type, 
    OtherClassTypes extends { token: Token<any, any>, item: Item<any, any, any> }
> extends EntityBaseData<SceneData2Type> {
    img: string;
    token: OtherClassTypes['token']['data'];
    items: OtherClassTypes['item']['data'][];
    active: boolean;
    navigation: boolean;
}

/*interface CreateOwnedItemDataArgument<SceneData1Type extends SceneData1<any, ItemData1, TokenData1<SceneData1Type>>> {
    name: SceneData1Type['items'][number]['name'];
    type: SceneData1Type['items'][number]['type'];
    data: Partial<SceneData1Type['items'][number]['data']>
}*/

declare interface SceneOptions<TokenClassType extends Token<any, any>> extends EntityOptions {
    token?: TokenClassType;
}

interface SceneEmbeddedEntities extends EntityEmbeddedEntities {
    "AmbientLight": "lights",
    "AmbientSound": "sounds",
    "Drawing": "drawings",
    "Note": "notes",
    "MeasuredTemplate": "templates",
    "Tile": "tiles",
    "Token": "tokens",
    "Wall": "walls"
}

declare interface SceneConfig<SceneType extends Scene<any, any, any>, SceneSheetType extends SceneSheet<SceneType>> extends EntityConfig<SceneType, SceneSheetType> {
    label: "ENTITY.Scene",
    permissions: {
        create: "SCENE_CREATE"
    }
}

interface SceneCreateOptions extends EntityCreateOptions { }
interface SceneUpdateOptions extends EntityUpdateOptions { }
interface SceneDeleteOptions extends EntityDeleteOptions { }

declare class Scene<
    SceneData2Type extends unknown = unknown,
    SceneSheetType extends SceneSheet<any> = SceneSheet<Scene<SceneData2Type, any>>,
    OtherClassTypes extends { token: Token<any, any>, item: Item<any, any, any> } = { token: Token, item: Item }
> extends Entity<SceneBaseData<SceneData2Type, OtherClassTypes>, SceneSheetType> {


    readonly options: SceneOptions<OtherClassTypes['token']>;
    readonly config: SceneConfig<this, SceneSheetType>;

    get img(): SceneBaseData<any, any>['img'];

    get active(): this['data']['active'];
    get isView(): boolean;
    get journal(): unknown | null;
    get playlist(): unknown | null;

    /**
     * Set this scene as the current view
     */
    view(): Promise<void>;

    /** 
     * Set this scene as currently active
     * TODO: What's the difference between view() and activate() ?
     */
    activate(): Promise<void>;

    clone(createData: DeepPartial<SceneBaseData<SceneData2Type, OtherClassTypes>> & { active?: never, navigation?: never }, options?: SceneCreateOptions): Promise<this>;
}
