
interface UserBaseData<UserData2Type> extends EntityBaseData<UserData2Type> {
    active: boolean;
    viewedScene: string;
    role: number;
    permissions: unknown;       // TODO: permission vs permissions?
}

declare interface UserOptions<TokenClassType extends Token<any, any>> extends EntityOptions {
    token?: TokenClassType;
}

interface UserEmbeddedEntities extends EntityEmbeddedEntities {
    OwnedItems: 'items'
}

declare interface UserConfig<UserType extends User<any>> extends EntityConfig<UserType, any> {
    label: "ENTITY.User"
}

interface ActorCreateOptions extends EntityCreateOptions { }
interface ActorUpdateOptions extends EntityUpdateOptions { }
interface ActorDeleteOptions extends EntityDeleteOptions { }

// TODO: Can there be a UserSheet type?
declare class User<UserData2Type> extends Entity<UserBaseData<UserData2Type>, null> {

    readonly active: boolean;
    readonly targets: unknown;
    readonly viewedScene: string | null;
    readonly role: number;

    constructor(data: UserBaseData<UserData2Type>, options: UserOptions<any>);

    /* -------------------------------------------- */

    get avatar(): string;

    /**
     * Return the Actor instance of the user's impersonated character (or undefined)
     * @type {Actor}
     */
    get character(): Actor<unknown, any, any>;

    /**
     * A convenience shortcut for the permissions object of the current User
     * @type {Object}
     */
    get permissions(): UserBaseData<UserData2Type>['permissions'];

    /* ---------------------------------------- */

    /**
     * A flag for whether the current User is a Trusted Player
     * @return {Boolean}
     */
    get isTrusted(): boolean;

    /* ---------------------------------------- */

    /**
     * A flag for whether the current User has Assistant GameMaster or full GameMaster role
     * @return {Boolean}
     */
    get isGM(): boolean;

    /* ---------------------------------------- */

    /**
     * A flag for whether this User is the connected client
     * @return {Boolean}
     */
    get isSelf(): boolean;

    /* ---------------------------------------- */
    /*  User Methods                            */
    /* ---------------------------------------- */

    /**
     * Test whether the User is able to perform a certain permission action. Game Master users are always allowed to
     * perform every action, regardless of permissions.
     *
     * @param {string} permission     The action to test
     * @return {boolean}              Does the user have the ability to perform this action?
     */
    can(permission: UserPermission): boolean;

    /* -------------------------------------------- */

    /**
     * Test whether the User has a specific permission entitled .This differs from user#can because it does not always
     * return true for Game Master users and should be used in cases where a permission could be withheld even from
     * a GM player (for example cursor display, or A/V audio).
     *
     * @param {string} permission     The action to test
     * @return {boolean}              Does the user have explicit permission to perform this action?
     */
    hasPermission(permission: UserPermission): boolean;

    /* ---------------------------------------- */

    /**
     * Test whether the User has at least the permission level of a certain role
     * @param {string|number} role     The role name from USER_ROLES to test
     * @return {boolean}               Does the user have at least this role level?
     */
    hasRole(role: UserRole): boolean;

    /* ---------------------------------------- */

    /**
     * Test whether the User has exactly the permission level of a certain role
     * @param {string|number} role     The role name from USER_ROLES to test
     * @return {boolean}               Does the user have exactly this role level?
     */
    isRole(role: UserRole): boolean;

    /* -------------------------------------------- */

    /**
     * Sets a user's permission
     * Modifies the user permissions to grant or restrict access to a feature.
     * 
     * TODO: Does this return a promise?
     *
     * @param {String} permission    The permission name from USER_PERMISSIONS
     * @param {Boolean} allowed      Whether to allow or restrict the permission
     */
    setPermission(permission: UserPermission, allowed: boolean): void;

    /* -------------------------------------------- */

    /**
     * Submit User activity data to the server for broadcast to other players.
     * This type of data is transient, persisting only for the duration of the session and not saved to any database.
     *
     * @param {Object} activityData             An object of User activity data to submit to the server for broadcast.
     * @param {Object} activityData.cursor      The coordinates of the user's cursor
     * @param {boolean} activityData.focus      Is the user pulling focus to the cursor coordinates?
     * @param {boolean} activityData.ping       Is the user emitting a ping at the cursor coordinates?
     * @param {string} activityData.ruler       Serialized Ruler coordinate data in JSON format
     * @param {string} activityData.sceneId     The id of the Scene currently being viewed by the User
     * @param {Array} activityData.targets      An id of Token ids which are targeted by the User
     */
    broadcastActivity(activityData?: { cursor: unknown, focus: boolean, ping: boolean, ruler: string, sceneId: string, targets: string[] }): void;

    /* -------------------------------------------- */

    /**
     * Assign a Macro to a numbered hotbar slot between 1 and 50
     * @param {Macro|null} macro  The Macro entity to assign
     * @param {number} slot       The integer Hotbar slot to fill
     * @param {number} [fromSlot] An optional origin slot from which the Macro is being shifted
     * @return {Promise}          A Promise which resolves once the User update is complete
     */
    assignHotbarMacro(macro: unknown | null, slot: number, options?: { fromSlot?: number | null }): Promise<this>;

    /* -------------------------------------------- */

    /**
     * Get an Array of Macro Entities on this User's Hotbar by page
     * @param {number} page     The hotbar page number (1-indexed?)
     * @return {Array.<Object>}
     */
    getHotbarMacros(page?: number): { slot: number, macro: unknown }[];

    /* -------------------------------------------- */

    updateTokenTargets(targetIds: string[]): void;

}

//  = Actor<unknown, ActorSheet<Actor<unknown, any, any>, any>>
declare class Users<UserType extends User<any>> extends EntityCollection<UserType> {
    

  /**
   * Get all users with the role "player"
   * @return {Array.<User>}
   */
  get players(): Array<UserType>;

  get current(): UserType | null;
}

