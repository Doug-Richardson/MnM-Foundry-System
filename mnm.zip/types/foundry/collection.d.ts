
declare class Collection<K, V> {
    constructor(entries?: Iterable<[K, V]> | null);

    // Note that we can't just do "extends Map<K, V>" because of these two lines, to my knowledge anyway
    [Symbol.iterator](): IterableIterator<V>;
    get entries(): IterableIterator<V>;


    clear(): void;
    delete(key: K): boolean;
    forEach(callbackfn: (value: V, key: K, map: Map<K, V>) => void, thisArg?: any): void;
    get(key: K): V | undefined;
    has(key: K): boolean;
    set(key: K, value: V): this;
    get size(): number;

    keys(): IterableIterator<K>;

    values(): IterableIterator<V>;


    find(condition: (t: V) => boolean): V | null;

    filter(condition: (t: V) => boolean): V[];

    get(key: K, options?: { strict?: boolean }): V | null;

    map<U>(transformer: (t: V) => U): U[];
    reduce(evaluator: (lhs: V, rhs: V) => V, initial: V): V[];
}
