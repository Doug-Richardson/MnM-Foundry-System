/**
 * Extend the base Actor entity by defining a custom roll data structure which is ideal for the Simple system.
 * @extends {Actor}
 */
export class mnmActor extends Actor {

  /**
   * Augment the basic actor data with additional dynamic data.
   */
  prepareData() {
    super.prepareData();

    const actorData = this.data;
    const data = actorData.data;
    const flags = actorData.flags;

    // Make separate methods for each Actor type (character, npc, etc.) to keep
    // things organized.
    if (actorData.type === 'character') this._prepareCharacterData(actorData);
  }

  /**
   * Prepare Character type specific data
   */
  _prepareCharacterData(actorData) {
    const data = actorData.data;
    data.PLWARNabilityskill = '';
    data.PPSummary = '';
    //

    // Make modifications to data here. For example:
    data.powerpoints.value = 0//we need some global or somthing to track power points spent.
    // Loop through ability scores, and add their modifiers to our sheet output.
    let PPSpent = 0;
    for (let [key, ability] of Object.entries(data.abilities)) {
      let temp = ability.value;
      //If you have -10 to a stat, you lack that stat, and rules work differently
      if (temp == -10)
      {
        temp = 0;
        data.powerpoints.value += -10
        PPSpent += -10;
      }
      else
      {
        data.powerpoints.value += (ability.value*2)
        PPSpent += (ability.value*2);
      }
      ability.current = temp - Math.abs(ability.damage);
    }
    data.PPSummary += "Abilities[" + PPSpent + "] ";
    PPSpent = 0;    
    for (let [key, defense] of Object.entries(data.defenses)) {
      let ability_modifier = data.abilities[defense.modifier].current
      defense.current = defense.value + ability_modifier - Math.abs(defense.damage);
      //negitave ranks should only exist to make PL limits work. They don't give points back.
      if(defense.value > 0){
        data.powerpoints.value += defense.value
        PPSpent += defense.value
      }
    }
    data.PPSummary += "Defenses[" + PPSpent + "] ";
    PPSpent = 0;  

    for (let [key, skill] of Object.entries(data.skills)) {
      skill.current = skill.rank + data.abilities[skill.modifier].current;//add related atribute
      //negitave ranks should not give back points.
      if(skill.rank > 0){
        data.powerpoints.value += skill.rank * 0.5
        PPSpent += skill.rank * 0.5;
      }
    }
    data.PPSummary += "Skills[" + PPSpent + "] ";
    PPSpent = 0;  

    //Power level limit checking
    let PL = data.powerlevel;

    //Dodge+Toughness < 2*PL
    //If Dodge and Toughness are greater than PL*2, we are going to limit Dodge and Parry, because Toughness is more likely to change. There is no
    //formal ruling on this, but this is code, so we had to make one.
    // We add damage and current to get uninjured values, since these limits still apply even when hurt.
    //This avoids someone with PL 2 and 4 points in both Fighting and Stamina from having a weird, on injury become better at parrying thing.
    //which seems unintentional.
    //            Unhurt Dodge + unhurt toughness > 2PL
    if((data.defenses.dodge.current + data.defenses.dodge.damage) + (data.defenses.toughness.current + data.defenses.toughness.damage) > (PL * 2))
    {
      data.PLWARNabilityskill += "(TOUGHNESS + DODGE > PL*2)"
    }

    //Same logic for Parry
    if(data.defenses.parry.current + data.defenses.parry.damage + data.defenses.toughness.current + data.defenses.toughness.damage > (PL * 2))
    {
      data.PLWARNabilityskill += "(TOUGHNESS + PARRY > PL*2)"
    }

    //Williams and Fortonian saves are next.
    //PL*2 >= Will + Fort. Because it is tied to stamina, we will use the same logic from before.
    //If they break the rules, limit 
    if((data.defenses.will.current + data.defenses.will.damage) + (data.defenses.fort.current + data.defenses.fort.damage) > (PL * 2))
    {
      data.PLWARNabilityskill += "(WILL + FORTITUDE > PL*2)"
    }

    for (let [key, skill] of Object.entries(data.skills)) {
      if(skill.current > (PL + 10))
      {
        data.PLWARNabilityskill += "(SKILL "  + key + " > PL + 10)";
      }
    }

    
    if(data.PLWARNabilityskill == "")
      data.PLWARNabilityskill = "None."
    if(actorData.token) {
      actorData.token.bar1 = { attribute: 'defenses.toughness.damage' };
    }
  }
}