import { AdvantageMetadata } from "../meta";


export class RankCalculator extends Application {
    
  /** @override */
  static get defaultOptions() {
    return mergeObject<ApplicationOptions>(super.defaultOptions, {
      classes: ["mnm", "sheet", "actor"],
      template: "systems/mnm3e/templates/item/item-advantage-list.html",
      width: 600,
      height: 600,
      //tabs: [{ navSelector: ".sheet-tabs", contentSelector: ".sheet-body", initial: "description" }]
    });
  }

  getData() {
      return { advantages: AdvantageMetadata };
  }

}
