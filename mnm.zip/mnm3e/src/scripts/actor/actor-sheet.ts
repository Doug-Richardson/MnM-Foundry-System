import type { MnmActor } from "./actor";
import { AbilityMap, AbilityMetadata, AbilityType, DefenseMap, DefenseMetadata, SkillMetadata, SkillMapDynamic, SkillMapStatic } from "../meta";
import { AdvantageList } from "../item/advantage-list";
import { MnmEffectData2, MnmEquipmentEffectData2, MnmItemData2 } from "../item/item";
import { ObjectArray } from "../object-array";
import { MnmAdvantageData2 } from "../item/types/advantage";

declare const DEFAULT_TOKEN: any;



export interface MnmActorSheetData1 extends ActorSheetData<MnmActor> {

  viewerIsGM: boolean;
  tokenIsLinked: boolean;
  isSyntheticToken: boolean;

  metadata: {
    abilities: AbilityMap<AbilityMetadata>;
    defenses: DefenseMap<DefenseMetadata>;
    skills: SkillMapStatic<SkillMetadata>;
  };

  advantages: ItemBaseData<MnmAdvantageData2>[];
  powers: ItemBaseData<MnmEffectData2>[];
  equipmentEffects: ItemBaseData<MnmEquipmentEffectData2>[];
  //powers: ItemData1<MnmPowerData2>[];

  // This is derived from finding the "equipment" advantage.
  equipmentPoints: {
    hasAdvantage: boolean;  // Used to determine whether or not to show the "Equipment" section in the first place.
    available: number;      // How many equipment points the player has (ranks * )
    spent: number;
  }

  powerPointsSpent: {
    total: number;

    abilities: number;
    defenses: number;
    skills: number;
    advantages: number;
    powers: number;
  }
}


/**
 * Extend the basic ActorSheet with some very simple modifications
 * @extends {ActorSheet}
 */
export class MnmActorSheet extends ActorSheet<MnmActor> {

  /** @override */
  static get defaultOptions(): ActorSheetOptions {
    return mergeObject(super.defaultOptions, {
      classes: ["mnm", "sheet", "actor"],
      template: "systems/mnm3e/templates/actor/actor-sheet.html",
      width: 650,
      height: 750,
      tabs: [{ navSelector: ".sheet-tabs", contentSelector: ".sheet-body", initial: "description" }]
    }) as any;
  }

  /* -------------------------------------------- */

  /** @override */
  async getData(): Promise<MnmActorSheetData1> {
    this.actor.prepareData();
    //this.actor.items?.forEach(item => item.prepareData());

    const data = await super.getData();
    const advantages: ItemBaseData<MnmAdvantageData2>[] = [];
    //const powers: ItemData1<MnmEffectData2>[] = [];
    const effects: ItemBaseData<MnmEffectData2>[] = [];
    const equipmentEffects: ItemBaseData<MnmEquipmentEffectData2>[] = [];

    const equipmentPoints: MnmActorSheetData1['equipmentPoints'] = {
      available: 0,
      spent: 0,
      hasAdvantage: false
    };
    let hasJackOfAllTrades = false;

    const powerPointsSpent: MnmActorSheetData1['powerPointsSpent'] = {
      total: 0,

      abilities: data.actor.data._derived?.powerPointsSpent.abilities ?? 0,
      defenses: data.actor.data._derived?.powerPointsSpent.defenses ?? 0,
      skills: data.actor.data._derived?.powerPointsSpent.skills ?? 0,
      advantages: 0,
      powers: 0,
      //equipment: 0
    }

    if (this.actor.items) {
      for (let item of this.actor.items) {
        switch (item.type) {
          case "advantage": {
            const data = (item.data as ItemBaseData<MnmAdvantageData2>);
            powerPointsSpent.advantages += (data.data.ranked ? (data.data.ranks ?? 1) : 1);
            advantages.push(data);

            //let approxName = data.name.toLowerCase().replace(/a/, );

            if (/^\s*equipment\s*(\d+)?$/gi.test(data.name)) {
              equipmentPoints.hasAdvantage = true;
              equipmentPoints.available += (data.data.ranks ?? 1) * 5;
            }
            else if (data.name.toLowerCase() === 'jack-of-all-trades') {
              hasJackOfAllTrades = true;
            }
            break;
          }

          case "effect": {
            const data = (item.data as ItemBaseData<MnmEffectData2>);
            powerPointsSpent.advantages += ((data.data.basecpr * data.data.rank) + data.data.flatcost);
            effects.push(data);
            break;
          }

          case "equipmenteffect": {
            const data = (item.data as ItemBaseData<MnmEquipmentEffectData2>);
            equipmentPoints.spent += (data.data.basecpr * data.data.rank) + data.data.flatcost;
            equipmentEffects.push(data);
            break;
          }

          /*case "power":{
            const data = (item.data as ItemData1<MnmPowerData2>);
            powerPointsSpent.powers += data.data._derived.totalCost;
            powers.push(data);
            break;
          }*/
        }
      }
    }


    console.assert(data.entity === data.actor);
    console.assert(data.entity.data === data.data);
    console.assert(data.entity.data === data.actor.data);

    // Note: it's fine that we don't explicitly exclude the "total" field from all the values we sum up since it starts at 0 anyway.
    powerPointsSpent.total = Object.values(powerPointsSpent).reduce((prev, current) => current + prev, 0);

    // Make sure that if the actor has Jack-of-all-Trades they can still roll the dice
    // TODO: This is terrible and I'm worse and I have Sinned™
    if (hasJackOfAllTrades) {
      Object.entries(data.data.skills).map(([key, skill]) => {
        if (!('subtypes' in skill)) {
          if (skill._derived.cantUseMessage?.toLowerCase() === 'untrained')
            skill._derived.canUse = true;
        }
        else {
          for (let subtype of ObjectArray.toArray(skill.subtypes)) {
            if (subtype._derived.cantUseMessage?.toLowerCase() === 'untrained')
              subtype._derived.canUse = true;
          }
        }
      });
      /*for (let skillName in data.data.skills) {
        const skill = data.data.skills[skillName as any];
      }*/
    }

    const tokenIsLinked = this.actor.data.token.actorLink || false;
    const viewerIsGM = game.users.current?.isGM || false;


    return {
      ...data,
      metadata: {
        abilities: AbilityMetadata,
        defenses: DefenseMetadata,
        skills: SkillMetadata
      },
      advantages,
      powers: effects,
      equipmentEffects,
      equipmentPoints,
      powerPointsSpent,
      tokenIsLinked,
      isSyntheticToken: this.actor.isToken,
      viewerIsGM
    };
  }

  /*
  private _prepareCharacterItems(sheetData: MnmActorSheetData1) {
    const actorData = sheetData.actor;
    //actorData.

    // Initialize containers.
    //const gear: Item[] = [];

    if (actorData.data._derived) {
      //actorData.data._derived.advantages = []
      //actorData.data._derived.effects = []

      // Iterate through items, allocating to containers
      // let totalWeight = 0;
      for (let i of sheetData.items) {
        let item = i.data;
        i.img = i.img || DEFAULT_TOKEN;
        // Append to gear.

        // Append to advantages.
        if (i.type === 'advantage') {
          let advantage = i.data as MnmAdvantageData2;

          advantage._derived.showRankInInventory = (advantage.ranked && advantage.ranks != 1);
          actorData.data._derived.advantages.push(i as any);
        }
        // Append to effects.
        else if (i.type === 'effect') {
          actorData.data._derived.effects.push(i as any);
        }
      }
    }
  }
*/

  /* -------------------------------------------- */

  /** @override */
  activateListeners(html: JQuery<HTMLHtmlElement>) {
    super.activateListeners(html);

    // Everything below here is only needed if the sheet is editable
    if (!this.options.editable)
      return;


    html.find('.expertise-add').click(this._onSubskillAdd('expertise'));
    html.find('.expertise-delete').click(this._onSubskillDelete('expertise'));

    html.find('.close_combat-add').click(this._onSubskillAdd('close_combat'));
    html.find('.close_combat-delete').click(this._onSubskillDelete('close_combat'));

    html.find('.ranged_combat-add').click(this._onSubskillAdd('ranged_combat'));
    html.find('.ranged_combat-delete').click(this._onSubskillDelete('ranged_combat'));

    html.find('.advantage-create').on('click', (e) => {
      e.preventDefault();
      return this.actor.createOwnedItem({
        name: 'Custom Advantage',
        type: 'advantage',
        data: {
          isCustom: true
        }
      });
    });

    // Add Inventory Item
    html.find('.item-create').click(this._onItemCreate);

    // Update Inventory Item
    html.find('.item-edit').on('click', ev => {
      const li = $(ev.currentTarget).parents(".item");
      const item = this.actor.getOwnedItem(li.data("itemId"));
      item?.sheet.render(true);
    });

    html.find('.item-activate').on('click', ev => {
      const li = $(ev.currentTarget).parents(".item");
      const item = this.actor.getOwnedItem(li.data("itemId"))
      console.log("GotThisFar");
      let messagecontents = item.name;
      messagecontents += "   RANK:" + item.data.data.rank;
      if(item.data.data.description)
        messagecontents += item.data.data.description;

      ChatMessage.create({content: messagecontents , 
        speaker: {
          actor: this.actor._id,
          token: this.actor.token,
          alias: this.actor.name
        }});
    });

    /*html.find<HTMLInputElement>('.ability-absent-checkbox').on('change', ev => {
      const abilityKey = ev.currentTarget.dataset['ability']
      const newData = this.actor.data.data;
      console.log(`About to change ${newData.abilities[abilityKey as AbilityType].absent} to ${ev.currentTarget.checked}`);
      newData.abilities[abilityKey as AbilityType].absent = ev.currentTarget.checked;
      this.actor.update(newData);
    })*/

    html.find('.random-stamp-rotation').each(function () {
      this.style.setProperty('--stamp-rotation', `${Math.sign(Math.random() - 0.5) * (Math.random() * 20 + 7)}deg`)
    });

    html.find('.level-up-button').on('click', ev => {
      setTimeout(() => {

        const nextEditMode = (this.actor.data.data.editMode === 'temp' ? 'level-up' : 'temp');
        //this.options.submitOnChange = false;
        // $(`select[name="data.editMode"] option[value="${prevEditMode}"]`).removeAttr('selected');
        //this.options.submitOnChange = true;
        //$(`select[name="data.editMode"] option[value="${nextEditMode}"]`).attr('selected', 'selected');
        //this.actor.data.data.editMode = nextEditMode;
        //this.actor.data.data._derived.editModeLevelUp = (nextEditMode === 'level-up');
        //this.actor.data.data._derived.editModeTemporary = (nextEditMode === 'temp');

        //let updateData: DeepPartial<ActorData2<DeepPartial<MnmCharacterData>>> = { _id: this.actor.data._id, data: { editMode: nextEditMode } };
        //this.actor.update(updateData).then(_ => this.render());
        const newData = duplicate(this.actor.data);
        newData.data.editMode = nextEditMode;
        //Promise.all([this.actor.token?.update({ actorData: newData } as any, { diff: false }), this.actor.update(newData, { diff: false })]).then(() => {
        Actor.update(newData as any).then(() => {
          this.actor.data = newData;
          this.actor.prepareData();
          this.render();
        });
        //Actor.update(updateData);

        //Actor.update(this.actor.data);
        //this.render();
      }, 100);
    });

    html.find('.add-advantage-button').on('click', ev => {
      //debugger;
      new (AdvantageList as any)().render(true);
    });

    // Delete Inventory Item
    html.find('.item-delete').click(ev => {
      const li = $(ev.currentTarget).parents(".item");
      this.actor.deleteOwnedItem(li.data("itemId"));
      li.slideUp(200, () => this.render(false));
    });

    // Rollable abilities.
    html.find('.rollable').click(this._onRoll);

    // Drag events for macros.
    if (this.actor.owner) {
      let handler = (ev: DragEvent) => (this as any)._onDragStart(ev);
      html.find('li.item').each((i, li) => {
        if (li.classList.contains("inventory-header")) return;
        li.setAttribute("draggable", "true");
        li.addEventListener("dragstart", handler, false);
      });
    }
  }

  /**
   * Handle creating a new Owned Item for the actor using initial data defined in the HTML dataset
   * @param {Event} event   The originating click event
   * @private
   */
  _onItemCreate = (event: JQuery.ClickEvent) => {

    event.preventDefault();
    const header = event.currentTarget as HTMLButtonElement;
    // Get the type of item to create.
    const type = header.dataset.type ?? '';
    // Grab any data associated with this control.
    const data = duplicate(header.dataset as { [k: string]: any });
    // Initialize a default name.
    const name = `New ${type?.toUpperCase()}`;
    // Prepare the item object.
    const itemData: DeepPartial<ItemBaseData<MnmItemData2>> = {
      name: name,
      type: type,
      data: data
    };

    // Remove the type from the dataset since it's in the itemData.type prop.
    delete (itemData.data as any)["type"];

    // Finally, create the item!g
    return this.actor.createOwnedItem(itemData);
  }

  _onSubskillAdd = (which: 'expertise' | 'close_combat' | 'ranged_combat'): JQuery.EventHandlerBase<HTMLElement, JQuery.ClickEvent<HTMLElement, null, HTMLElement, HTMLElement>> => (ev) => {


    const index = +(ev.currentTarget.dataset['index'] ?? NaN);
    if (isFinite(index)) {
      const data = this.actor.data;

      //const newSubskill = ObjectArray.spliced(ObjectArray.clone(data.data.skills[which].subtypes), index + 1, 0, { _derived: {} as any, _meta: { ...SkillMetadata[which] }, name: '', ranks: 0, other: 0, temporary: 0 });
      const newSubskill = ObjectArray.toArray(data.data.skills[which].subtypes);
      newSubskill.splice(index + 1, 0, { _derived: {} as any, _meta: { ...SkillMetadata[which] }, name: '', ranks: 1, other: 0, temporary: 0, rollFlavorText: null });

      const newData = duplicate(this.actor.data);
      newData.data.skills[which].subtypes = ObjectArray.fromArray(newSubskill);
      newData.data.skills[which].subtypeCount += 1;
      Actor.update(newData as any).then(() => {
        this.actor.data = newData;
        this.actor.prepareData();
        this.render();
      });

      return;

    }
  }

  _onSubskillDelete = (which: 'expertise' | 'close_combat' | 'ranged_combat'): JQuery.EventHandlerBase<HTMLElement, JQuery.ClickEvent<HTMLElement, null, HTMLElement, HTMLElement>> => (ev) => {
    const index = +(ev.currentTarget.dataset['index'] ?? NaN);
    if (isFinite(index)) {

      //const newSubskill = ObjectArray.spliced(ObjectArray.clone(this.entity.data.data.skills[which].subtypes), index, 1);
      const newSubskill = ObjectArray.toArray(this.entity.data.data.skills[which].subtypes);
      newSubskill.splice(index, 1);

      const newData = duplicate(this.actor.data);
      newData.data.skills[which].subtypes = ObjectArray.fromArray(newSubskill);
      newData.data.skills[which].subtypeCount -= 1;

      Actor.update(newData as any).then(() => {
        this.actor.data = newData;
        this.actor.prepareData();
        this.render();
      });

      return;
    }
  }

  /**
   * Handle clickable rolls.
   * @param {Event} event   The originating click event
   * @private
   */
  _onRoll = (event: JQuery.ClickEvent) => {
    event.preventDefault();
    const element = event.currentTarget as HTMLButtonElement;
    const dataset = element.dataset;

    if (dataset.roll) {
      let roll = new Roll(dataset.roll, this.actor.data.data);
      let label = dataset.label ?? dataset.roll;
      roll.roll().toMessage({
        speaker: ChatMessage.getSpeaker({ actor: this.actor }),
        flavor: label
      });
    }
  }


}

/*type DeepPartial<T> = {
  [P in keyof T]?: DeepPartial<T[P]>;
};*/


declare function duplicate<T>(original: T): T;
