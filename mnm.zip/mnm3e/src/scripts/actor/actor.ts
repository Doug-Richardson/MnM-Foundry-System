
import { AbilityMetadata, DefenseMetadata, SkillMetadata, getAbilityBenchmark } from "../meta";
import { canonicalizeActorData } from "./canonicalize";
import type { MnmActorSheet } from "./actor-sheet";
import type { MnmItem } from "../item/item";

import indefinite from 'indefinite';

import type { DefenseMap, AbilityMap, SkillMapDynamic, AbilityType, DefenseType, SkillType } from "../meta";
import { ObjectArray } from "../object-array";

export type MnmToken = Token<MnmActorData2, { actor: MnmActor, scene: Scene<unknown, any, any> }>;

export interface AbilityInfo {
  _derived: { 
    totalNetBonus: number, 
    benchmark: string,
    resolvedRollFlavorText: string // The actual text that's used (i.e. if the user-supplied one is null, then just something like "rolling will" or whatever)
  };
  ranks: number;
  temporary: number;
  absent: boolean;


  rollFlavorText?: string | null;    // The text that's sent to the chat when rolling
}

export interface DefenseInfo {
  _meta: DefenseMetadata;
  _derived: {
    totalNetBonus: number;
    abilityBonus: number;
    abilityAbsent: boolean;
    isNonToughness: boolean;
    abilityAbsentAndIsNonToughness: boolean;    // TODO: Handlebars helpers to make this less dumb

    minRanks: number | null;
    maxRanks: number | null;
    temporaryMax: number | null;
    otherMax: number | null;

    resolvedRollFlavorText: string;       
  }
  ranks: number;
  temporary: number;
  other: number;

  rollFlavorText?: string | null;
}

export interface SkillInfo {
  _meta: SkillMetadata;
  _derived: {
    totalNetBonus: number;
    abilityBonus: number;
    maxRanks: number;
    minRanks: number;
    canUse: boolean;                // Note: this can be updated in the actor sheet when it discovers the actor has the JOAT advantage. TODO: That sucks and also is dumb
    cantUseMessage: string | null;
    abilityAbsent: boolean;

    resolvedRollFlavorText: string;   
  };
  ranks: number;
  other: number;
  temporary: number;

  rollFlavorText?: string | null;
}

const CURRENT_ACTOR_DATA_VERSION = 2;


/*interface CombinedCondition {
  subConditions: ReadonlyArray<ActorCondition>;
  description: string;
}*/

/*const Conditions: { [K in ActorCondition]: any } = {
  'compelled': 0,
  'controlled': { supercedes: 'compelled' },

  'dazed': 0,
  'stunned': { supercedes: 'dazed' },
  
  'hindered': 0,
  'immobile': { supercedes: 'hindered' },

  'impaired': null,
  'disabled': null,
  
  'weakened': null,
  'debilitated': null,

  'defenseless': 0,
  'fatigued': 0,
  'normal': 0,
  'transformed': null,
  'unaware': 0,
  'vulnerable': 0
}

const CombinedConditions: { [K in ActorCondition2]: CombinedCondition } = {
  'asleep': {
    subConditions: ['defenseless', 'stunned', 'unaware'],
    description: 'While asleep, a character is defenseless, stunned, and unaware. A hearing Perception check with three or more degrees of success wakes the character and removes all these conditions, as does any sudden movement (such as shaking the sleeping character) or any effect allowing a resistance check.'
  }
}*/

export interface MnmActorData2 {

  confirmedVersion: typeof CURRENT_ACTOR_DATA_VERSION;

  // Anything in these _derived objects is automatically overwritten each time prepareData() is called.
  // That means that they cannot really be edited by <input> fields, since it'll just be immediately overwritten by the newly derived value.
  // Incidentally these are also safe to exclude from serialization (like in JSONs and such), and don't need to be accounted for when upgrading.
  _derived?: {

    powerPointsSpent: {
      abilities: number;
      defenses: number;
      skills: number;
    }

    editModeLevelUp: boolean;       // TODO: Register a Handlebars helper that makes these obsolete
    editModeTemporary: boolean;

    // These are used by the defense tab
    doubledPowerLevel: number;
    dodgeToughnessTooHigh: boolean;
    parryToughnessTooHigh: boolean;
    willFortitudeTooHigh: boolean;
  };
  editMode: 'temp' | 'level-up';
  powerLevel: number;
  powerPoints: number;
  heroPoints: number;

  biography: string;
  abilities: AbilityMap<AbilityInfo>;
  defenses: DefenseMap<DefenseInfo>;
  skills: SkillMapDynamic<SkillInfo>;

  /*conditions: {
    basic: {
      cc: null | 'compelled' | 'controlled';
      ds: null | 'dazed' | 'stunned';
      vd: null | 'vulnerable' | 'defenseless';
      hi: null | 'hindered' | 'immobile';

      //debilitated: unknown;
      //debilitated, disabled, impaired
      fatigued: boolean;
      transformed: unknown;
      unaware: unknown;

    }
  }*/
}


function orDefaultNumber(obj: number | null | undefined, defaultRet = 0): number {
  if (obj == null)
    return defaultRet;

  if (isNaN(obj))
    return defaultRet;

  if (!isFinite(obj))
    return defaultRet;

  return obj;
}



export class MnmActor extends Actor<MnmActorData2, MnmActorSheet, { token: MnmToken, item: MnmItem }> {



  // Hijack the import JSON function to clean up any imported data instead of blindly trusting it
  async importFromJSON(json: string) {
    return super.importFromJSON(JSON.stringify(canonicalizeActorData(JSON.parse(json))));
  }

  /**
   * Augment the basic actor data with additional dynamic data.
   */
  prepareData() {
    super.prepareData();

    // Don't bother with anything if we're still in game.setupGame()
    if (!game.ready)
      return this.data;

    const updatedData = canonicalizeActorData(this.data);
    if (updatedData.data.confirmedVersion !== this.data.data.confirmedVersion) {
      this.update(updatedData);
    }

    this.data = updatedData;

    _prepareCharacterData(this.data);


    return this.data;
  }

}

/**
 * Prepare Character type specific data
 */
function _prepareCharacterData(actorData: ActorBaseData<MnmActorData2, any>) {
  const data = actorData.data;

  const powerPointsSpent: Exclude<MnmActorData2['_derived'], undefined>['powerPointsSpent'] = {
    abilities: 0,
    defenses: 0,
    skills: 0,
  }

  //


  data.powerLevel = orDefaultNumber(data.powerLevel, 5);
  data.powerPoints = orDefaultNumber(actorData.data.powerPoints);




  for (let ukey in data.abilities) {
    const key = ukey as AbilityType;

    const ability = data.abilities[key];
    //ability._meta = AbilityMetadata[key as AbilityType];



    const totalNetBonus = ability.absent ? -5 : (ability.ranks + ability.temporary);
    const relatedDefenseName = AbilityMetadata[key].defense;
    const relatedDefense = relatedDefenseName? data.defenses[relatedDefenseName] : null;

    const resolvedAbilityRollFlavorText = ability.rollFlavorText? `${ability.rollFlavorText} (${AbilityMetadata[key].displayName.toLowerCase()})` : `Makes ${"aeiou".includes(AbilityMetadata[key].displayName[0].toLowerCase())? 'an' : 'a'} ${AbilityMetadata[key].displayName.toLowerCase()} check`;

    ability._derived = {
      totalNetBonus,  // Having an absent ability gives 10 character points, so it's the same as having -5,
      //relatedDefense,
      benchmark: getAbilityBenchmark(totalNetBonus),
      resolvedRollFlavorText: resolvedAbilityRollFlavorText
    };

    powerPointsSpent.abilities += ability.absent ? -10 : ability.ranks * 2;

    //let temp = ability.value;
    //If you have -10 to a stat, you lack that stat, and rules work differently
    /* if (temp == -10) {
       temp = 0;
       data.powerpoints.value += -10
     }
     else {
       data.powerpoints.value += (ability.value * 2)
     }*/
    //ability.current = temp - Math.abs(ability.damage);


  }

  for (let key in data.defenses) {

    const defense = data.defenses[key as DefenseType];
    defense._meta = DefenseMetadata[key as DefenseType];





    const isGM = game.users.current?.isGM || false;
    let displayName = defense._meta.displayName.toLowerCase();


    const absent = data.abilities[defense._meta.ability].absent;
    const isNonToughness = (defense._meta.name !== 'toughness');
    const abilityAbsentAndIsNonToughness = (absent && isNonToughness);

    
    const resolvedDefenseRollFlavorText = defense.rollFlavorText? `${defense.rollFlavorText} (${displayName})` : `Attempts a ${displayName} save`;



    let abilityBonus = data.abilities[defense._meta.ability]._derived.totalNetBonus;

    // Normally characters do take a -5 on checks related to stamina if they don't have it, but this does not apply to toughness, which just gets a standard +0 if stamina is absent instead.
    if (!isNonToughness && absent)
      abilityBonus = 0;

    const temporaryBonus = defense.temporary;
    const otherBonus = defense.other;
    const totalNetBonus = Math.min(data.powerLevel * 2, abilityBonus + temporaryBonus + otherBonus + defense.ranks);



    defense._derived = {
      abilityAbsent: absent,
      totalNetBonus,
      abilityBonus,
      isNonToughness,
      abilityAbsentAndIsNonToughness,
      maxRanks: null,
      minRanks: null,
      temporaryMax: null,
      otherMax: null,
      resolvedRollFlavorText: resolvedDefenseRollFlavorText
    };

    if (defense.ranks > 0)
      powerPointsSpent.defenses += defense.ranks;
  }


  // Handle the extra defense stuff (mins and maxes, error reporting, etc)
  // There's a pattern here, I swear
  data.defenses.dodge._derived.maxRanks = (data.powerLevel * 2) - data.defenses.toughness._derived.totalNetBonus - data.defenses.dodge.other - data.defenses.dodge.temporary - data.abilities[data.defenses.dodge._meta.ability]._derived.totalNetBonus;
  data.defenses.dodge._derived.otherMax = (data.powerLevel * 2) - data.defenses.toughness._derived.totalNetBonus - data.defenses.dodge.ranks - data.defenses.dodge.temporary - data.abilities[data.defenses.dodge._meta.ability]._derived.totalNetBonus;
  data.defenses.dodge._derived.temporaryMax = (data.powerLevel * 2) - data.defenses.toughness._derived.totalNetBonus - data.defenses.dodge.other - data.defenses.dodge.ranks - data.abilities[data.defenses.dodge._meta.ability]._derived.totalNetBonus;

  data.defenses.parry._derived.maxRanks = (data.powerLevel * 2) - data.defenses.toughness._derived.totalNetBonus - data.defenses.parry.other - data.defenses.parry.temporary - data.abilities[data.defenses.parry._meta.ability]._derived.totalNetBonus;
  data.defenses.parry._derived.otherMax = (data.powerLevel * 2) - data.defenses.toughness._derived.totalNetBonus - data.defenses.parry.ranks - data.defenses.parry.temporary - data.abilities[data.defenses.parry._meta.ability]._derived.totalNetBonus;
  data.defenses.parry._derived.temporaryMax = (data.powerLevel * 2) - data.defenses.toughness._derived.totalNetBonus - data.defenses.parry.other - data.defenses.parry.ranks - data.abilities[data.defenses.parry._meta.ability]._derived.totalNetBonus;

  data.defenses.will._derived.maxRanks = (data.powerLevel * 2) - data.defenses.fortitude._derived.totalNetBonus - data.defenses.will.other - data.defenses.will.temporary - data.abilities[data.defenses.will._meta.ability]._derived.totalNetBonus;
  data.defenses.will._derived.otherMax = (data.powerLevel * 2) - data.defenses.fortitude._derived.totalNetBonus - data.defenses.will.ranks - data.defenses.will.temporary - data.abilities[data.defenses.will._meta.ability]._derived.totalNetBonus;
  data.defenses.will._derived.temporaryMax = (data.powerLevel * 2) - data.defenses.fortitude._derived.totalNetBonus - data.defenses.will.other - data.defenses.will.ranks - data.abilities[data.defenses.will._meta.ability]._derived.totalNetBonus;

  data.defenses.fortitude._derived.maxRanks = (data.powerLevel * 2) - data.defenses.will._derived.totalNetBonus - data.defenses.fortitude.other - data.defenses.fortitude.temporary - data.abilities[data.defenses.fortitude._meta.ability]._derived.totalNetBonus;
  data.defenses.fortitude._derived.otherMax = (data.powerLevel * 2) - data.defenses.will._derived.totalNetBonus - data.defenses.fortitude.ranks - data.defenses.fortitude.temporary - data.abilities[data.defenses.fortitude._meta.ability]._derived.totalNetBonus;
  data.defenses.fortitude._derived.temporaryMax = (data.powerLevel * 2) - data.defenses.will._derived.totalNetBonus - data.defenses.fortitude.other - data.defenses.fortitude.ranks - data.abilities[data.defenses.fortitude._meta.ability]._derived.totalNetBonus;

  data.defenses.toughness._derived.maxRanks = Math.min(
    (data.powerLevel * 2) - data.defenses.dodge._derived.totalNetBonus - data.defenses.toughness.other - data.defenses.toughness.temporary - data.abilities[data.defenses.toughness._meta.ability]._derived.totalNetBonus,
    (data.powerLevel * 2) - data.defenses.parry._derived.totalNetBonus - data.defenses.toughness.other - data.defenses.toughness.temporary - data.abilities[data.defenses.toughness._meta.ability]._derived.totalNetBonus
  );

  data.defenses.toughness._derived.otherMax = Math.min(
    (data.powerLevel * 2) - data.defenses.dodge._derived.totalNetBonus - data.defenses.toughness.ranks - data.defenses.toughness.temporary - data.abilities[data.defenses.toughness._meta.ability]._derived.totalNetBonus,
    (data.powerLevel * 2) - data.defenses.parry._derived.totalNetBonus - data.defenses.toughness.ranks - data.defenses.toughness.temporary - data.abilities[data.defenses.toughness._meta.ability]._derived.totalNetBonus
  );

  data.defenses.toughness._derived.temporaryMax = Math.min(
    (data.powerLevel * 2) - data.defenses.dodge._derived.totalNetBonus - data.defenses.toughness.other - data.defenses.toughness.ranks - data.abilities[data.defenses.toughness._meta.ability]._derived.totalNetBonus,
    (data.powerLevel * 2) - data.defenses.parry._derived.totalNetBonus - data.defenses.toughness.other - data.defenses.toughness.ranks - data.abilities[data.defenses.toughness._meta.ability]._derived.totalNetBonus
  );


  data.defenses.dodge._derived.minRanks = Math.min(0, data.defenses.dodge._derived.maxRanks);
  data.defenses.parry._derived.minRanks = Math.min(0, data.defenses.parry._derived.maxRanks);
  data.defenses.toughness._derived.minRanks = Math.min(0, data.defenses.toughness._derived.maxRanks);
  data.defenses.will._derived.minRanks = Math.min(0, data.defenses.will._derived.maxRanks);
  data.defenses.fortitude._derived.minRanks = Math.min(0, data.defenses.fortitude._derived.maxRanks);

  //data.defenses.will._derived.maxRanks = ()

  const handleSkill = (skill: SkillInfo, key: SkillType, displayName: string) => {
    skill._meta = { ...SkillMetadata[key] };

    const abilityBonus = data.abilities[skill._meta.ability]._derived.totalNetBonus;
    const rankBonus = skill.ranks;
    const otherBonus = skill.other;
    const temporaryBonus = skill.temporary;

    const allBonusesButRank = (abilityBonus || 0) + (otherBonus || 0) + (temporaryBonus || 0);

    const totalNetBonus = Math.min(data.powerLevel + 10, allBonusesButRank + (rankBonus || 0));
    //const tooHigh = (skill.temporary > (data.powerLevel + 10));
    const maxRanks = (data.powerLevel + 10) - (allBonusesButRank);
    const minRanks = 0;
    const abilityAbsent = data.abilities[skill._meta.ability].absent;

    let cantUseMessage: 'Absent' | 'Untrained' | null = null; // ((skill._meta.untrained ? null : (skill.rank > 0)) && !data.abilities[skill.modifier].absent);
    if (abilityAbsent)
      cantUseMessage = 'Absent';
    else if (!(skill._meta.untrained || skill.ranks > 0))
      cantUseMessage = 'Untrained';

    const canUse = !cantUseMessage;
    
    const resolvedSkillRollFlavorText = skill.rollFlavorText? `${skill.rollFlavorText} (${displayName})` : `Makes ${indefinite(displayName)} check`;


    skill._derived = { totalNetBonus, abilityBonus, maxRanks, minRanks, canUse, cantUseMessage, abilityAbsent, resolvedRollFlavorText: resolvedSkillRollFlavorText };
    //skill.current = skill.rank + data.abilities[skill._meta.ability]._derived.totalNetBonus; //add related atribute
    //negitave ranks should not give back points.
    if (skill.ranks > 0)
      powerPointsSpent.skills += skill.ranks * 0.5;
  }



  for (let key in data.skills) {


    if (key === 'expertise' || key === 'close_combat' || key === 'ranged_combat') {
      // Handle the three special skills that have subskills

      if (data.skills[key].subtypes == null || ObjectArray.size(data.skills[key].subtypes) == 0) {
        data.skills[key].subtypes = [{ name: '', ranks: 0, other: 0, temporary: 0, _derived: {} as any, _meta: { ...SkillMetadata[key] }, rollFlavorText: null }];
        data.skills[key].subtypeCount = 1;
      }

      const typeCount = data.skills[key].subtypeCount; //ObjectArray.size(data.skills[key].subtypes);
      //actorData.data.skills.expertise.subtypeCount = typeCount;

      data.skills[key]._derived = { countPlusOne: typeCount + 1, hideDelete: typeCount <= 1 };

      // Remove any skills past the number of skills we're supposed to have
      // TODO
      data.skills[key].subtypes = ObjectArray.spliced(data.skills[key].subtypes, typeCount);

      ObjectArray.forEach(data.skills[key].subtypes, (type) => {
        type.name = type.name ?? '';
        type.ranks = orDefaultNumber(type.ranks);
        type.other = orDefaultNumber(type.other);
        type.temporary = orDefaultNumber(type.temporary);
      });
    }
    else {
      // Handle all "normal" skills
      const skill = data.skills[key as Exclude<SkillType, 'expertise' | 'close_combat' | 'ranged_combat'>];
      skill._meta = SkillMetadata[key as SkillType];
      skill.ranks = orDefaultNumber(skill.ranks);
      skill.other = orDefaultNumber(skill.other);
      skill.temporary = orDefaultNumber(skill.temporary);
    }
  }

  //delete (data.skills as any)['this' as any];

  for (let key in data.skills) {

    if (key === 'expertise' || key === 'close_combat' || key === 'ranged_combat') {

      const expertiseCount = ObjectArray.size(data.skills[key].subtypes);
      //actorData.data.skills.expertise.subtypeCount = expertiseCount;
      data.skills[key]._derived = { countPlusOne: expertiseCount + 1, hideDelete: expertiseCount <= 1 }
      data.skills[key]._meta = SkillMetadata[key];

      ObjectArray.forEach(data.skills[key].subtypes, (subtype) => {
        
        subtype.name = subtype.name ?? '';
        subtype.ranks = orDefaultNumber(subtype.ranks);
        subtype.other = orDefaultNumber(subtype.other);
        subtype.temporary = orDefaultNumber(subtype.temporary);

        handleSkill(subtype, key as SkillType, subtype.name || SkillMetadata[key as 'expertise' | 'close_combat' | 'ranged_combat'].displayName.toLowerCase());

        switch (key) {
          case 'expertise':
            if (subtype.name)
              subtype._meta.displayName = `Expertise (${subtype.name})`;
            else
              subtype._meta.displayName = 'Expertise';
            break;

          case 'close_combat':
            subtype._meta.displayName = `${subtype.name || 'Close Combat'}`;
            break;

          case 'ranged_combat':
            subtype._meta.displayName = `${subtype.name || 'Ranged Combat'}`;
            break;
        }

      });
    }
    else {
      const k = key as Exclude<SkillType, 'expertise' | 'close_combat' | 'ranged_combat'>;
      handleSkill(data.skills[k], key as SkillType, SkillMetadata[k].displayName.toLowerCase());
    }
  }




  //const totalPowerPointsForLevel = data.powerLevel * 15;
  const doubledPowerLevel = data.powerLevel * 2;

  const dodgeToughnessTooHigh = (data.defenses.dodge._derived.totalNetBonus + data.defenses.toughness._derived.totalNetBonus > data.powerLevel * 2);
  const parryToughnessTooHigh = (data.defenses.parry._derived.totalNetBonus + data.defenses.toughness._derived.totalNetBonus > data.powerLevel * 2);
  const willFortitudeTooHigh = (data.defenses.will._derived.totalNetBonus + data.defenses.fortitude._derived.totalNetBonus > data.powerLevel * 2);

  data._derived = {
    editModeTemporary: (data.editMode === 'temp'),
    editModeLevelUp: (data.editMode === 'level-up' || !data.editMode),
    powerPointsSpent,
    doubledPowerLevel,
    dodgeToughnessTooHigh,
    parryToughnessTooHigh,
    willFortitudeTooHigh
  };


  if (actorData.token) {
    (actorData.token as any).bar1 = { attribute: 'defenses.toughness.temporary' };
  }
}