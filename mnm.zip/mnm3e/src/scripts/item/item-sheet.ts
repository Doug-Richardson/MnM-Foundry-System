import { MnmItem, MnmItemData2 } from "./item";
import { MnmAdvantageData2 } from "./types/advantage";

export interface MnmItemSheetData1 extends ItemSheetData<MnmItem> {
  // Note: These can both be false
  canEditFundamentals: boolean;   // Whether or not we are allowed to change things like the category, whether or not the advantage is ranked, etc.
  canEditBasics: boolean;         // Whether or not we are allowed to change things like the name, ranks the associated character has put in, etc. 
  canEditRanks: boolean;          // Whether or not we are allowed to change how many ranks have been put into this item (true if the item is owned AND this is their owner or the GM)
}



/**
 * Extend the basic ActorSheet with some very simple modifications
 * @extends {ActorSheet}
 */
export class MnmItemSheet extends ItemSheet<MnmItem> {

  /** @override */
  static get defaultOptions(): ItemSheetOptions {
    return mergeObject<ItemSheetOptions>(super.defaultOptions, {
      classes: ["mnm", "sheet", "item"],
      width: 520,
      height: 480,
      tabs: [{ navSelector: ".sheet-tabs", contentSelector: ".sheet-body", initial: "description" }]
    });
  }

  /** @override */
  get template() {
    const path = "systems/mnm3e/templates/item";
    // Return a single sheet for all item types.
    // return `${path}/item-sheet.html`;

    // Alternatively, you could use the following return statement to do a
    // unique item sheet by type, like `weapon-sheet.html`.
    return `${path}/item-${this.item.data.type}-sheet.html`;
  }

  /* -------------------------------------------- */

  /** @override */
  async getData(): Promise<MnmItemSheetData1> {
    this.item.prepareData();
    const data = await super.getData();

    const isGM = game.users.current?.isGM || false;

    let canEditBasics = false;
    let canEditFundamentals = false;
    let canEditRanks = false;
    
    if (this.item.actor) {
      if (this.item.actor.data.data.editMode === 'level-up') {
        canEditRanks = canEditBasics = (data.owner || isGM);
        canEditFundamentals = ((data.owner || isGM) && !!(data.data as MnmAdvantageData2).isCustom);
      }
    }
    else {
      canEditRanks = false;
      canEditBasics = canEditFundamentals = isGM;
    }

    return {
      canEditBasics,
      canEditFundamentals,
      canEditRanks,
      ...data
    }
  }

  /* -------------------------------------------- */

  /** @override */
  /*setPosition(options = {}) {
    const position = super.setPosition(options);
    const sheetBody = $(this.element).find(".sheet-body");
    const bodyHeight = position.height - 192;
    sheetBody.css("height", bodyHeight);
    return position;
  }*/

  /* -------------------------------------------- */

  /** @override */
  activateListeners(html: JQuery<HTMLElement>) {
    super.activateListeners(html);

    // Everything below here is only needed if the sheet is editable
    if (!this.options.editable) return;

    // Roll handlers, click handlers, etc. would go here.

    //We ought to make them click to send to chat-able... But IDK how to do that right now.
  }
}
