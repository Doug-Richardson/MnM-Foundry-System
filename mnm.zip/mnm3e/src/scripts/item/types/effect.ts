import type { AdvantageType, DefenseType } from "../../meta";
import { MnmItemDataBase } from "../item";


const CURRENT_POWER_DATA_VERSION = 2;
const CURRENT_EFFECT_DATA_VERSION = 2;
const CURRENT_EFFECT_MODIFIER_DATA_VERSION = 2;

export interface MnmPowerData2 extends MnmItemDataBase {
    _lastConfirmedVersion: typeof CURRENT_POWER_DATA_VERSION;
    //name: string;
    summary: string;
    description: string;
    effects: Array<ItemBaseData<MnmEffect2Data2>>;
    additionalCost: {
        perRank: number;
        flat: number;
        ranks: number;
    };
    _derived: {
        totalCost: number
    }
}


export interface MnmEffect2Data2 extends MnmItemDataBase {
    _lastConfirmedVersion: typeof CURRENT_EFFECT_DATA_VERSION;
    
        // Many effects have unique modifiers exclusive to those effects
        // If we would like to use one of them, 
        // we can create a new item using the selected entry in the array.
        availableExclusiveModifiers: Array<MnmEffectModifierData2 & { name: string }>;
    

    _derived: {
        totalCost: number;
    }

    isCustom: boolean;      // false if the effect is a built-in one, true if it's a player-made one added directly from the character sheet
    //name: string;
    ranks: number;
    type: 'attack' | 'movement' | 'sensory' | 'defense' | 'control' | 'general' | 'sensory';
    action: 'standard' | 'free' | 'reaction' | 'move' | 'none';
    duration: 'instant' | 'sustained' | 'permanent';
    resistances: { [K in DefenseType]: boolean };
    baseCost: {     // Not including modifiers--just the effect itself
        perRank: number;
        flat: number;
    }
    summary: string;
    description: string;

    
    
    appliedModifiers: Array<ItemBaseData<MnmEffectModifierData2>>;
    
}


export interface MnmEffectModifierData2 {
    _lastConfirmedVersion: typeof CURRENT_EFFECT_MODIFIER_DATA_VERSION;
    //name: string;
    summary: string;
    description: string;
    cost: {
        perRank: number;
        flat: number;
    }

}




