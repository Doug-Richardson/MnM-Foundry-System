import { MnmItem } from "../item";



type V1Advantage = { "description": string, "rank": number };

export interface MnmAdvantageData2 {
    confirmedVersion: typeof LATEST_VERSION;

    eligibleForV1CompendiumRefresh?: boolean;   // Used to indicate that this advantage was upgraded from V1 and may be eligible to have its data filled in

    _derived: {
        showRankInInventory: boolean;   // In the Advantages tab in the player's inventory, should we show the +3 (or whatever) rank indicator?
        totalCost: number;              // Advantages generally just cost whatever the rank count is, but just to be safe
        rankDisplay: string;            // Either the rank count or "-"
    }
    isCustom?: boolean | null;  // If falsy this is a built-in advantage, effect, etc. and can only be edited by the GM. If true it was made by the player and can be edited by anyone.
    summary: string;
    description: string;
    ranks: number | null;

    category: 'general' | 'skill' | 'combat' | 'fortune';

    ranked: boolean;             // Editable by owner only
    maxRanks: number | null;     // Editable by owner only
}




export const LATEST_VERSION = 2;

export function canonicalize(item: MnmItem<MnmAdvantageData2>): ItemBaseData<MnmAdvantageData2> {
    let v1Advantage = (item.data.data as DeepPartial<V1Advantage> | undefined);
    let v2Advantage = (item.data.data as DeepPartial<MnmAdvantageData2> | undefined);
    let version = (v2Advantage?.confirmedVersion || 1);

    const name = item.data.name ?? 'New Advantage';
    const img = item.data.img ?? '';

    let ret: ItemBaseData<MnmAdvantageData2>

    if (version <= 1) {
        ret = {
            ...(item.data as Required<typeof item.data>),
            _id: item.data._id!,
            name,
            type: 'advantage',
            img,
            data: {
                eligibleForV1CompendiumRefresh: true,
                _derived: {} as any,
                category: 'general',
                summary: '(Advantage summary)',
                description: v1Advantage?.description ?? '(Advantage description)',
                ranks: v1Advantage?.rank ?? 1,
                maxRanks: null,
                ranked: true,
                isCustom: true,
                confirmedVersion: 2
            }
        }
    }
    else {
        ret = {
            ...(item.data as Required<typeof item.data>),
            _id: item.data._id!,
            name,
            type: 'advantage',
            img,
            data: {
                eligibleForV1CompendiumRefresh: v2Advantage?.eligibleForV1CompendiumRefresh,
                _derived: v2Advantage?._derived ?? {} as any,
                category: v2Advantage?.category ?? 'general',
                summary: v2Advantage?.summary ?? '(Advantage summary)',
                description: (v2Advantage?.description ?? ''),
                ranks: v2Advantage?.ranks ?? 1,
                maxRanks: v2Advantage?.maxRanks ?? null,
                ranked: v2Advantage?.ranked ?? true,
                isCustom: v2Advantage?.isCustom,
                confirmedVersion: 2
            }
        }
    }


    return ret;
}

export function prepareData(item: MnmItem<MnmAdvantageData2>) {
    if (item.data.data.confirmedVersion != LATEST_VERSION)
        return;

    let advantageData = item.data.data as MnmAdvantageData2;
    //advantageData.data._meta = (AdvantageMetadata[advantageData.name as any as AdvantageType] ?? {  });
    advantageData._derived = {
        showRankInInventory: advantageData.ranked && advantageData.ranks != 1,
        totalCost: advantageData.ranked ? (advantageData.ranks ?? 0) : 1,
        rankDisplay: advantageData.ranked ? (`${advantageData.ranks}`) : '-'
    }
    advantageData.ranks = (advantageData.ranks ?? 0);

    if (item.actor && item.name.toLowerCase() === 'luck') {
        advantageData.maxRanks = (item.actor.data.data.powerLevel / 2);
    }
}









