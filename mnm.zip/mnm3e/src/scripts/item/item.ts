
import { MnmActor } from "../actor/actor";
import { MnmItemSheet, MnmItemSheetData1 } from "./item-sheet";
import { MnmAdvantageData2 } from "./types/advantage";
import * as Advantage from './types/advantage';
//import { MnmEffect2Data2, MnmEffectModifierData2, MnmPowerData2 } from "./effect";


export interface MnmItemDataBase {
  confirmedVersion: number;
}

const CURRENT_ADVANTAGE_DATA_VERSION = 2;

type ActorCondition = 'compelled' | 'controlled' | 'dazed' | 'debilitated' | 'defenseless' | 'disabled' | 'fatigued' | 'hindered' | 'immobile' | 'impaired' | 'normal' | 'stunned' | 'transformed' | 'unaware' | 'vulnerable' | 'weakened';
type ActorCondition2 = 'asleep' | 'blind' | 'bound' | 'deaf' | 'dying' | 'entranced' | 'exhausted' | 'incapacitated' | 'paralyzed' | 'prone' | 'restrained' | 'staggered' | 'surprised';


export interface MnmBasicConditionData2 extends MnmItemDataBase {
  conditionType: ActorCondition;
}

export interface MnmDerivedConditionData2 extends MnmItemDataBase {
  conditionType: ActorCondition2;
}


export interface MnmEffectData2 extends MnmItemDataBase {
  _derived: {
    totalCost: number;
  }
  rank: number;
  basecpr: number;
  flatcost: number;
  description: string;
  resistances: {
    damage: boolean;
    dodge: boolean;
    parry: boolean;
    toughness: boolean;
    will: boolean;
    fortitude: boolean;
  }
}




export interface MnmEquipmentEffectData2 extends MnmItemDataBase {
  _derived: {
    totalCost: number;
  }
  rank: number;
  basecpr: number;
  flatcost: number;
  description: string;
}


/*export interface MnmEquipmentData2 extends MnmItemDataBase {
  rank: number;
  basecpr: number;
  flatcost: number;
  description: string;
}*/

//export interface MnmAdvantageData1 extends ItemData1<MnmAdvantageData2> {  }
//export interface MnmEffectData1 extends ItemData1<MnmEffectData2> {  }
//export interface MnmEquipmentData1 extends ItemData1<MnmEquipmentData2> {  }
//export interface MnmEquipmentEffectData1 extends ItemData1<MnmEquipmentEffectData2> {  }


interface ConditionInterface {

}


// General versions of the above
export type MnmItemData2 = MnmAdvantageData2 | MnmEffectData2 | MnmEquipmentEffectData2 | MnmBasicConditionData2 | MnmDerivedConditionData2 //| MnmEffect2Data2 | MnmPowerData2 | MnmEffectModifierData2;
//export interface MnmItemData1 extends ItemData1<MnmItemData2> {  }


// Attempts to find an existing item of the same type/name in an existing compendium and copies the description and other relevant info into the given data
async function syncWithExistingItem(dataToSync: ItemBaseData<MnmItemData2>) {
  let name = dataToSync.name;

  const compendiumItem = await findExistingItem(dataToSync.name, dataToSync.type);
  if (compendiumItem) {
    switch (dataToSync.type) {
      case 'advantage':

        //await this.update({ '-=data._eligibleForV1CompendiumRefresh': null, } as any);

        /*await (this as MnmItem<MnmAdvantageData2>).update({
          name: compendiumItem?.name,
          type: compendiumItem?.type,
          data: {
            eligibleForV1CompendiumRefresh: null as any,
            description: (<MnmAdvantageData2>dataToSync.data).description + compendiumItem?.data.description,
            category: (<MnmAdvantageData2>dataToSync.data).category,
            isCustom: false,
            maxRanks: compendiumItem?.data.maxRanks,
            ranked: compendiumItem?.data.ranked,
            summary: compendiumItem?.data.summary
          }
        });*/

        let advantageToSync = dataToSync as ItemBaseData<MnmAdvantageData2>;
        advantageToSync.data.confirmedVersion = Advantage.LATEST_VERSION;
        advantageToSync.name = compendiumItem.name;
        advantageToSync.data.eligibleForV1CompendiumRefresh = false;
        advantageToSync.data.description = advantageToSync.data.description + compendiumItem.data.description;
        advantageToSync.data.category = compendiumItem.data.category;
        advantageToSync.data.maxRanks = compendiumItem.data.maxRanks;
        advantageToSync.data.ranked = compendiumItem.data.ranked;
        advantageToSync.data.summary = compendiumItem.data.summary;
        advantageToSync.data.isCustom = false;

        console.log(`Successfully found and synced ${advantageToSync._id} with compendium item ${compendiumItem._id}`);

        break;

    }
  }
}

/**
 * Extend the basic Item with some very simple modifications.
 * @extends {Item}
 */
export class MnmItem<DataType extends MnmItemData2 = MnmItemData2> extends Item<DataType, MnmItemSheet, { actor: MnmActor, scene: Scene<unknown, any, any> }> {

  //eligibleForV1CompendiumRefresh = false;

  private _getHelper() {
    return (this.data.type === 'advantage' ? Advantage : { canonicalize: <T>(t: T) => t });
  }


  initialize() {


    const canonicalized: ItemBaseData<DataType> = this._getHelper().canonicalize(this as any);

    if (this.compendium == null) {

      if ((canonicalized.data as MnmAdvantageData2).eligibleForV1CompendiumRefresh || canonicalized.data.confirmedVersion !== this.data.data.confirmedVersion) {

        if (this.can(game.users.current, "update")) {
          (async () => {
            // This item should be "officially" updated because the version has changed 
            // and this user has permission to do the update action.
  
            if ((canonicalized.data as MnmAdvantageData2).eligibleForV1CompendiumRefresh) {
              console.log(`Attemping to sync item ${canonicalized._id} with compendium`);
              // If we've updated from V1 we should try to sync with existing compendium data.
              await syncWithExistingItem(canonicalized as any);
            }
  
            
            addDeletes(this.data, canonicalized);
            await this.update(canonicalized as any);
  
          })();

        }
      }
    }

    //this.data.data = canonicalized.data;

    // Before we do prepareData or whatever, 

    /*let canonicalData = canonicalizeItemData(this.data);

    if ((canonicalData.data as MnmAdvantageData2)._lastConfirmedVersion !== (originalData.data as MnmAdvantageData2)._lastConfirmedVersion) {


      this.update(canonicalData);

      if ((canonicalData.data as MnmAdvantageData2)._eligibleForV1CompendiumRefresh) {


      }

    }*/

    this.prepareEmbeddedEntities();
    this.prepareData();

    super.initialize();
  }

  /**
   * Augment the basic Item data model with additional dynamic data.
   */
  prepareData() {
    super.prepareData();


    // Replace any paths that reference the old location
    this.data.img = this.data.img.replace('/mnm2/', '/mnm3e/');

    switch (this.data.type) {
      case 'advantage':
        Advantage.prepareData(this as MnmItem<MnmAdvantageData2>);
        break;

      case 'effect':
      case 'equipmenteffect':
        let powerData = this.data.data as MnmEffectData2;
        powerData._derived = {
          totalCost: powerData.flatcost + powerData.basecpr * powerData.rank// + powerData.effects.map(effect => effect.data._derived.totalCost).reduce((prev, current) => prev + current, 0)
        }
        if(!powerData.resistances)
        {
          powerData.resistances = 
          {
            "damage": false,
            "dodge": false,
            "parry": false,
            "toughness": false,
            "will": false,
            "fortitude": false
          }
        }
        break;

      /*case 'power': {
        let powerData = this.data.data as MnmPowerData2;
        powerData._derived = {
          totalCost: powerData.additionalCost.flat + powerData.additionalCost.perRank * powerData.additionalCost.ranks + powerData.effects.map(effect => effect.data._derived.totalCost).reduce((prev, current) => prev + current, 0)
        }
        break;
      }*/
    }

    return this.data;
  }

  exportToJSON() {

    // Prepare export data
    const data = duplicate(this.data);
    delete data.folder;
    delete data.permission;
    delete (data.data as any)._meta;
    delete (data.data as any)._derived;

    // Flag some metadata about where the entity was exported some - in case migration is needed later
    data.flags["exportSource"] = {
      world: game.world.id,
      system: game.system.id,
      coreVersion: game.data.version,
      systemVersion: game.system.data.version
    };

    // Trigger file save procedure
    const filename = `${this.data.name.toLowerCase().replace(/\s/g, "_")}.json`;
    saveDataToFile(JSON.stringify(data, null, 2), "text/json", filename);
  }

  /**
   * Handle clickable rolls.
   * @param {Event} event   The originating click event
   * @private
   */
  async roll() {
    // Basic template rendering data
    let actor = this.actor;

    if (actor) {
      const token = this.actor?.token;
      const item = this.data;
      const actorData = this.actor ? this.actor.data.data : {};
      const itemData = item.data;

      let roll = new Roll('d20+@abilities.str.current', actorData);
      let label = `Rolling ${item.name}`;
      roll.roll().toMessage({
        speaker: ChatMessage.getSpeaker({ actor }),
        flavor: label,

      })
    }
  }
}



export async function findExistingItem(inputName: string, type: string): Promise<ItemBaseData<MnmAdvantageData2> | null> {

  while (!game.items && !game.packs) {
    await (new Promise(resolve => setTimeout(resolve, 100)));
  }

  const pack = game.packs.get("mnm-items.advantages");

  const simplifiedV1Name = inputName.toLowerCase().replace(/[^a-z]/g, '');

  const existingAdvantages = await (pack as Compendium<MnmItem>).getContent();
  const allExistingItems = Array.from(game.items).concat(existingAdvantages);

  for (let v2 of allExistingItems) {
    if (v2.isOwned)
      continue;

    if (v2.data.type === type) {
      const simplifiedV2Name = v2.data.name.toLowerCase().replace(/[^a-z]/g, '');

      if (simplifiedV1Name === simplifiedV2Name) {
        return v2.data as ItemBaseData<MnmAdvantageData2>
      }
    }
  }

  return null;
}



function addDeletes(obsoleteObject: any | null | undefined, updatedObject: any) {


  function helper<T extends {}>(obsoleteObject: T | null | undefined, updatedObject: T | null | undefined, updatedObjectRoot: any, currentPath: string[]) {


    if (typeof obsoleteObject != typeof updatedObject || !obsoleteObject || !updatedObject || typeof obsoleteObject != 'object' || typeof updatedObject != 'object')
      return;


    const fieldsInObsoleteObject = Object.keys(obsoleteObject);
    const fieldsInUpdatedObject = Object.keys(updatedObject);
    const allFields = new Set([...fieldsInObsoleteObject, ...fieldsInUpdatedObject]);

    for (let field of allFields) {

      const fullPath = [...currentPath, field];

      let fieldInObsoleteObject = (typeof obsoleteObject === 'object' && field in obsoleteObject);
      let fieldInUpdatedObject = (typeof updatedObject === 'object' && field in updatedObject);

      if (fieldInObsoleteObject && fieldInUpdatedObject) {
        // Do nothing but recurse
        helper((obsoleteObject as any)[field], (updatedObject as any)[field], updatedObjectRoot, fullPath)
      }
      else if (fieldInObsoleteObject && !(fieldInUpdatedObject)) {
        // This field is obsolete, so it should be marked to be deleted.
        (updatedObjectRoot as any)[`-=${fullPath.join('.')}`] = null!;
      }
      else if (!(fieldInObsoleteObject) && (fieldInUpdatedObject)) {
        // This field is brand new, so we don't need to mark anything inside it as obsolete
        // (There might have been an obsolete counterpart to this field, e.g. closeCombat -> close_combat, but that's taken care of elsewhere)
      }
      else {
        // Logic?????
      }
    }
  }

  helper(obsoleteObject, updatedObject, updatedObject, []);
}




