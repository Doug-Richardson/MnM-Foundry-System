
/*

 Tiny set of functions to allow array-like operations on objects with numbers as keys
 (since Foundry doesn't support arrays to be stored in the database, I think?).

 Not necessarily stress-tested.

*/

const ObjectArraySize = Symbol('object-array-size');

export const dummy = 0;

export interface ObjectArray<T> {
    [i: number]: T;
}

export interface ObjectArrayInternal<T> extends ObjectArray<T> {
    [i: string]: T;
    [ObjectArraySize]?: number;
}



export function size<T>(array: ObjectArray<T>): number {
    if ((array as ObjectArrayInternal<T>)[ObjectArraySize] != undefined)
        return (array as ObjectArrayInternal<T>)[ObjectArraySize]!;

    const maxIndex = Math.max(...Object.keys(array).map(k => +k).filter(n => isFinite(n)));

    return ((array as ObjectArrayInternal<T>)[ObjectArraySize] = isFinite(maxIndex) ? maxIndex + 1 : 0);
}

export function clear<T>(array: ObjectArray<T>) {
    for (let s in array) {
        const n = +s;
        if (isFinite(n))
            deleteAt(array, n);
    }
}

export function clone<T>(array: ObjectArray<T>) {
    return map(array, t => t);
}


// TODO: Why is this pure but spliced isn't?
export function deleteAt<T>(array: ObjectArray<T>, index: number) {
    console.assert(isFinite(index));
    delete array[index];
    (array as ObjectArrayInternal<T>)[ObjectArraySize] = (array as ObjectArrayInternal<T>)[ObjectArraySize] != undefined ? (array as ObjectArrayInternal<T>)[ObjectArraySize]! - 1 : undefined;
}

export function forEach<T>(array: ObjectArray<T>, fn: (obj: T, index: number) => void) {
    for (let s in array) {
        const n = +s;
        if (isFinite(n))
            fn(array[s], n);
    }
}

export function map<T, F extends (obj: T, index: number) => any>(array: ObjectArray<T>, fn: F) {
    let ret: ObjectArray<ReturnType<F>> = {};
    forEach(array, (obj, index) => {
        ret[index] = fn(obj, index);
    });

    return ret;
}

// TODO: If there are holes in the array (which shouldn't generally happen), what happens?
export function toArray<T>(array: ObjectArray<T>): T[] {
    return Object.entries(array)
        .map(([key, value]) => [+key, value])
        .filter(([key, value]) => isFinite(key))
        .sort((([lhsKey], [rhsKey]) => lhsKey - rhsKey))
        .map(([key, value]) => value);
}

export function fromArray<T>(array: T[]) {
    let ret: ObjectArray<T> = {};
    forEach(array, (obj, index) => {
        ret[index] = obj;
    });

    return ret;
}

// TODO: Why isn't this pure but deleteAt is?
export function spliced<T>(inputArray: ObjectArray<T>, start: number, deleteCount?: number, ...items: T[]) {
    const jsArray = toArray(inputArray);
    if (deleteCount)
        jsArray.splice(start, deleteCount, ...items);
    else
        jsArray.splice(start);
    let ret = fromArray(jsArray) as ObjectArrayInternal<T>;

    ret[ObjectArraySize] = ret[ObjectArraySize] != undefined ? ret[ObjectArraySize]! - 1 : undefined;

    return ret;
}


export const ObjectArray = {
    size,
    clear,
    clone,
    deleteAt,
    forEach,
    map,
    toArray,
    fromArray,
    spliced
}

export default ObjectArray;



