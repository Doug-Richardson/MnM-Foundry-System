
/**
 * 
 * @param options 
 */
export function rankToMeasurement(options: { type: 'distance', distanceRank: number }): number;
export function rankToMeasurement(options: { type: 'distance', timeRank: number, speedRank: number }): number;
export function rankToMeasurement(options: { type: 'distance', strengthRank: number, massRank: number }): number;
export function rankToMeasurement(options: { type: 'time', timeRank: number }): number;
export function rankToMeasurement(options: { type: 'time', distanceRank: number, speedRank: number }): number;
export function rankToMeasurement(options: { type: 'mass', massRank: number }): number;
export function rankToMeasurement(options: { type: 'volume', volumeRank: number }): number;
export function rankToMeasurement(options: { type: 'distance' | 'time' | 'mass' | 'volume', distanceRank?: number, timeRank?: number, massRank?: number, volumeRank?: number, speedRank?: number, strengthRank?: number }): number {
    const { type, distanceRank, massRank, speedRank, strengthRank, timeRank, volumeRank } = options;
    switch (type) {
        case 'distance':
            if (distanceRank != undefined)
                return 30 * (2 ** distanceRank);
            if (timeRank != undefined && speedRank != undefined)
                return rankToMeasurement({ type: 'distance', distanceRank: timeRank + speedRank });
            if (strengthRank != undefined && massRank != undefined)
                return rankToMeasurement({ type: 'distance', distanceRank: strengthRank - massRank });
            break;
        case 'mass':
            if (massRank != undefined)
                return 50 * (2 ** massRank);
                break;
        case 'time':
            if (timeRank != undefined)
                return 6 * (2 ** timeRank);
            if (distanceRank != undefined && speedRank != undefined)
                return rankToMeasurement({ type: 'time', timeRank: distanceRank - speedRank });
                break;
        case 'volume':
            if (volumeRank != undefined)
                return 1 * (2 ** volumeRank);
                break;
    }
    return 0;
}

function errorCheck(array: boolean[]) {
    return array.filter(a => a).reduce((x, y) => x != y)
}