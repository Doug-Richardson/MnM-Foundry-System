import type { ObjectArray } from "./object-array";



export type AbilityType = 'str' | 'agl' | 'fgt' | 'awe' | 'sta' | 'dex' | 'int' | 'pre';
export type DefenseType = 'dodge' | 'parry' | 'fortitude' | 'toughness' | 'will';
export type SkillType = 'acrobatics' | 'athletics' | 'close_combat' | 'deception' | 'expertise' | 'insight' | 'intimidation' | 'investigation' | 'perception' | 'persuasion' | 'ranged_combat' | 'sleight_of_hand' | 'stealth' | 'technology' | 'treatment' | 'vehicles';
export type AdvantageType = "accurate_attack" | "agile_feint" | "all_out_attack" | "animal_empathy" | "artificer" | "assessment" | "attractive" | "beginners_luck" | "benefit" | "chokehold" | "close_attack" | "connected" | "contacts" | "daze" | "defensive_attack" | "defensive_roll" | "diehard" | "eidetic_memory" | "equipment" | "evasion" | "extraordinary_effort" | "fascinate" | "fast_grab" | "favored_environment" | "favored_foe" | "fearless" | "grabbing_finesse" | "great_endurance" | "hide_in_plain_sight" | "improved_aim" | "improved_critical" | "improved_defense" | "improved_disarm" | "improved_grab" | "improved_initiative" | "improved_hold" | "improved_smash" | "improved_trip" | "improvised_tools" | "improvised_weapon" | "inspire" | "instant_up" | "interpose" | "inventor" | "jack_of_all_trades" | "languages" | "leadership" | "luck" | "minion" | "move_by_action" | "power_attack" | "precise_attack" | "prone_fighting" | "quick_draw" | "ranged_attack" | "redirect" | "ritualist" | "second_chance" | "seize_initiative" | "set_up" | "sidekick" | "skill_mastery" | "startle" | "takedown" | "taunt" | "teamwork" | "throwing_mastery" | "tracking" | "trance" | "ultimate_effort" | "uncanny_dodge" | "weapon_bind" | "weapon_break" | "well_informed";

export interface AbilityData {
    value: number;
    modifier?: number;
}

type GeneralMap<S extends string, T> = { [A in S]: T };

interface SkillWithSubskills<T extends { _meta: any, _derived: any }> {
    _meta: T['_meta'],
    _derived: { countPlusOne: number, hideDelete: boolean },
    subtypes: ObjectArray<T & { name: string; }>;
    subtypeCount: number;
}

export type AbilityMap<T> = GeneralMap<AbilityType, T>;
export type DefenseMap<T> = GeneralMap<DefenseType, T>;
export type SkillMapStatic<T> = GeneralMap<SkillType, T>;
export type SkillMapDynamic<T extends { _meta: any, _derived: any }> = GeneralMap<Exclude<SkillType, 'expertise' | 'close_combat' | 'ranged_combat'>, T> & {
    expertise: SkillWithSubskills<T>,
    close_combat: SkillWithSubskills<T>,
    ranged_combat: SkillWithSubskills<T>,
};
export type AdvantageMap<T> = GeneralMap<AdvantageType, T>;

export interface AbilityMetadata { name: AbilityType; displayName: string, defense: Exclude<DefenseType, 'toughness'> | null };
export interface DefenseMetadata { name: DefenseType, displayName: string, ability: AbilityType; };
export interface SkillMetadata { name: SkillType, displayName: string, ability: AbilityType, untrained: boolean; placeholderName?: string; };

export const AbilityMetadata: AbilityMap<AbilityMetadata> = {
    str: { name: 'str', displayName: 'Strength', defense: null },
    agl: { name: 'agl', displayName: 'Agility', defense: 'dodge' },
    fgt: { name: 'fgt', displayName: 'Fighting', defense: 'parry' },
    awe: { name: 'awe', displayName: 'Awareness', defense: 'will' },
    sta: { name: 'sta', displayName: 'Stamina', defense: 'fortitude' },
    dex: { name: 'dex', displayName: 'Dexterity', defense: null },
    int: { name: 'int', displayName: 'Intellect', defense: null },
    pre: { name: 'pre', displayName: 'Presence', defense: null },
}

const AbilityBenchmarks: (string | undefined)[] = [];

AbilityBenchmarks[-5] = 'Completely inept or disabled';
AbilityBenchmarks[-4] = 'Weak; infant';
AbilityBenchmarks[-3] = 'Younger child';
AbilityBenchmarks[-2] = 'Child, elderly, impaired';
AbilityBenchmarks[-1] = 'Below average; teenager';
AbilityBenchmarks.push('Average adult',
    'Above average',
    'Well above average',
    'Gifted',
    'Highly gifted',
    'Best in a nation',
    'One of the best in the world',
    'Best ever; peak of human achievement',
    'Low superhuman',
    undefined,
    undefined,
    'Moderate superhuman',
    undefined,
    undefined,
    'High superhuman',
    undefined,
    'Very high superhuman',
    undefined,
    undefined,
    undefined,
    undefined,
    'C̜̺̟̩̻̥̯ͨ́ͬͩ͒̋o͎̱͙̺̲̣̬̱͐̏̐̅ͪ͝s̵̖͕̹̳͔̻̟̻͇ͮ̇̊̂̾ͪ̃͗͝m̻͍̟͈̟̩̖̌̈́̃͒͋̃̽̀͝î̬͎̖̍͢c̢̪̹̠̭̼͙̘͕̰̄ͣͪ̐ͯ̽'
);

export function getAbilityBenchmark(abilityScore: number) {

    for (let i = -5; i <= 20; ++i) {
        //let i = +s;
        if (i != undefined && abilityScore <= i)
            return AbilityBenchmarks[i]!;
    }

    return AbilityBenchmarks[20]!;
}

export const DefenseMetadata: DefenseMap<DefenseMetadata> = {
    dodge: { name: 'dodge', displayName: 'Dodge', ability: 'agl' },
    parry: { name: 'parry', displayName: 'Parry', ability: 'fgt' },
    fortitude: { name: 'fortitude', displayName: 'Fortitude', ability: 'sta' },
    toughness: { name: 'toughness', displayName: 'Toughness', ability: 'sta' },
    will: { name: 'will', displayName: 'Will', ability: 'awe' },
}

export const SkillMetadata: SkillMapStatic<SkillMetadata> = {
    acrobatics: { name: "acrobatics", displayName: "Acrobatics", ability: 'agl', untrained: false },
    athletics: { name: "athletics", displayName: "Athletics", ability: 'str', untrained: true },
    "close_combat": { name: "close_combat", displayName: "Close Combat", ability: 'fgt', untrained: true, placeholderName: 'Close combat type' },
    deception: { name: "deception", displayName: "Deception", ability: 'pre', untrained: true },
    expertise: { name: "expertise", displayName: "Expertise", ability: 'int', untrained: false, placeholderName: 'Field of expertise' },
    insight: { name: "insight", displayName: "Insight", ability: 'awe', untrained: true },
    intimidation: { name: "intimidation", displayName: "Intimidation", ability: 'pre', untrained: true },
    investigation: { name: "investigation", displayName: "Investigation", ability: 'int', untrained: false },
    perception: { name: "perception", displayName: "Perception", ability: 'awe', untrained: true },
    persuasion: { name: "persuasion", displayName: "Persuasion", ability: 'pre', untrained: true },
    "ranged_combat": { name: "ranged_combat", displayName: "Ranged Combat", ability: 'dex', untrained: true, placeholderName: 'Ranged combat type' },
    "sleight_of_hand": { name: "sleight_of_hand", displayName: "Sleight of hand", ability: 'dex', untrained: false },
    stealth: { name: "stealth", displayName: "Stealth", ability: 'agl', untrained: true },
    technology: { name: "technology", displayName: "Technology", ability: 'int', untrained: false },
    treatment: { name: "treatment", displayName: "Treatment", ability: 'int', untrained: false },
    vehicles: { name: "vehicles", displayName: "Vehicles", ability: 'dex', untrained: false },
}




export interface AdvantageMetadata {
    name: AdvantageType;
    displayName: string;
    ranked: boolean;
    summary: string;
    otherAdvantages?: Partial<AdvantageMap<AdvantageMetadata>>;
    //allMetadata?: () => typeof AdvantageMetadata; // TODO: This is always !undefined, it's just added one step after initialization.
}

export const AdvantageMetadata: AdvantageMap<AdvantageMetadata> = {
    accurate_attack: { name: "accurate_attack", displayName: "Accurate Attack", ranked: false, summary: "Trade effect DC for attack bonus." },
    agile_feint: { name: "agile_feint", displayName: "Agile Feint", ranked: false, summary: "Feint using Acrobatics skill or Speed rank" },
    all_out_attack: { name: "all_out_attack", displayName: "All-out Attack", ranked: false, summary: "Trade active defense for attack bonus." },
    animal_empathy: { name: "animal_empathy", displayName: "Animal Empathy", ranked: false, summary: "Use Interaction skills normally with animals." },
    artificer: { name: "artificer", displayName: "Artificer", ranked: false, summary: "Use Expertise (Magic) to create temporary magical devices." },
    assessment: { name: "assessment", displayName: "Assessment", ranked: false, summary: "Use Insight to learn an opponent's combat capabilities." },
    attractive: { name: "attractive", displayName: "Attractive", ranked: true, summary: "Circumstance bonus to interaction based on your looks." },
    beginners_luck: { name: "beginners_luck", displayName: "Beginner's Luck", ranked: false, summary: "Spend a hero point to gain 5 temporary ranks in a skill." },
    benefit: { name: "benefit", displayName: "Benefit", ranked: true, summary: "Gain a significant perquisite or fringe benefit." },
    chokehold: { name: "chokehold", displayName: "Chokehold", ranked: false, summary: "Suffocate an opponent you have successfully grabbed." },
    close_attack: { name: "close_attack", displayName: "Close Attack", ranked: true, summary: "+1 bonus to close attack checks per rank." },
    connected: { name: "connected", displayName: "Connected", ranked: false, summary: "Call in assistance or favors with a Persuasion check." },
    contacts: { name: "contacts", displayName: "Contacts", ranked: false, summary: "Make an initial Investigation check in one minute." },
    daze: { name: "daze", displayName: "Daze", ranked: true, summary: "Use Deception or Intimidation to daze an opponent." },
    defensive_attack: { name: "defensive_attack", displayName: "Defensive Attack", ranked: false, summary: "Trade attack bonus for active defense bonus." },
    defensive_roll: { name: "defensive_roll", displayName: "Defensive Roll", ranked: true, summary: "+1 active defense bonus to Toughness per rank." },
    diehard: { name: "diehard", displayName: "Diehard", ranked: false, summary: "Automatically stablize when dying." },
    eidetic_memory: { name: "eidetic_memory", displayName: "Eidetic Memory", ranked: false, summary: "Total recall, +5 circumstance bonus to remember things." },
    equipment: { name: "equipment", displayName: "Equipment", ranked: true, summary: "5 points of equipment per rank." },
    evasion: { name: "evasion", displayName: "Evasion", ranked: true, summary: "Circumstance bonus to avoid area effects." },
    extraordinary_effort: { name: "extraordinary_effort", displayName: "Extraordinary Effort", ranked: false, summary: "Gain two benefits when using extra effort." },
    fascinate: { name: "fascinate", displayName: "Fascinate", ranked: true, summary: "Use an interaction skill to entrance others." },
    fast_grab: { name: "fast_grab", displayName: "Fast Grab", ranked: false, summary: "Make a free grab check after an unarmed attack." },
    favored_environment: { name: "favored_environment", displayName: "Favored Environment", ranked: false, summary: "Circumstance bonus to attack or defense in an environment." },
    favored_foe: { name: "favored_foe", displayName: "Favored Foe", ranked: false, summary: "Circumstance bonus to certain checks against a type of opponent." },
    fearless: { name: "fearless", displayName: "Fearless", ranked: false, summary: "Immune to fear effects." },
    grabbing_finesse: { name: "grabbing_finesse", displayName: "Grabbing Finesse", ranked: false, summary: "Substitute DEX for STR when making grab attacks." },
    great_endurance: { name: "great_endurance", displayName: "Great Endurance", ranked: false, summary: "+5 checks involving endurance." },
    hide_in_plain_sight: { name: "hide_in_plain_sight", displayName: "Hide in Plain Sight", ranked: false, summary: "Hide while observed without need for a diversion." },
    improved_aim: { name: "improved_aim", displayName: "Improved Aim", ranked: false, summary: "Double circumstance bonuses for aiming." },
    improved_critical: { name: "improved_critical", displayName: "Improved Critical", ranked: true, summary: "+1 to critical threat range with an attack per rank." },
    improved_defense: { name: "improved_defense", displayName: "Improved Defense", ranked: false, summary: "+2 bonus to active defense when you take the defend action." },
    improved_disarm: { name: "improved_disarm", displayName: "Improved Disarm", ranked: false, summary: "No penalty for the disarm action." },
    improved_grab: { name: "improved_grab", displayName: "Improved Grab", ranked: false, summary: "Make grab attacks with one arm.  Not vulnerable while grabbing." },
    improved_initiative: { name: "improved_initiative", displayName: "Improved Initiative", ranked: true, summary: "+4 bonus to initiative checks per rank." },
    improved_hold: { name: "improved_hold", displayName: "Improved Hold", ranked: false, summary: "-5 circumstance penalty to escape from your holds." },
    improved_smash: { name: "improved_smash", displayName: "Improved Smash", ranked: false, summary: "No penalty for the smash action." },
    improved_trip: { name: "improved_trip", displayName: "Improved Trip", ranked: false, summary: "No penalty for the trip action." },
    improvised_tools: { name: "improvised_tools", displayName: "Improvised Tools", ranked: false, summary: "No penalty for using skills without tools." },
    improvised_weapon: { name: "improvised_weapon", displayName: "Improvised Weapon", ranked: true, summary: "Use Close Combat: Unarmed skill with improvised weapons, +1 damage bonus." },
    inspire: { name: "inspire", displayName: "Inspire", ranked: true, summary: "Spend a hero point to grant allies a +1 circumstance bonus per rank." },
    instant_up: { name: "instant_up", displayName: "Instant Up", ranked: false, summary: "Stand from prone as a free action." },
    interpose: { name: "interpose", displayName: "Interpose", ranked: false, summary: "Take an attack meant for an ally." },
    inventor: { name: "inventor", displayName: "Inventor", ranked: false, summary: "Use Technology to create temporary devices." },
    jack_of_all_trades: { name: "jack_of_all_trades", displayName: "Jack-of-All-Trades", ranked: false, summary: "Use any skill untrained." },
    languages: { name: "languages", displayName: "Languages", ranked: true, summary: "Speak and understand additional languages." },
    leadership: { name: "leadership", displayName: "Leadership", ranked: false, summary: "Spend a hero point to remove a condition from an ally." },
    luck: { name: "luck", displayName: "Luck", ranked: true, summary: "Re-roll a die once per rank." },
    minion: { name: "minion", displayName: "Minion", ranked: true, summary: "Gain a follower or minion with (15xrank) power points." },
    move_by_action: { name: "move_by_action", displayName: "Move-by Action", ranked: false, summary: "Move both before and after your standard action." },
    power_attack: { name: "power_attack", displayName: "Power Attack", ranked: false, summary: "Trade attack bonus for effect bonus." },
    precise_attack: { name: "precise_attack", displayName: "Precise Attack", ranked: true, summary: "Ignore attack check penalties for either cover or concealment." },
    prone_fighting: { name: "prone_fighting", displayName: "Prone Fighting", ranked: false, summary: "No penalties for fighting while prone." },
    quick_draw: { name: "quick_draw", displayName: "Quick Draw", ranked: false, summary: "Draw a weapon as a free action." },
    ranged_attack: { name: "ranged_attack", displayName: "Ranged Attack", ranked: true, summary: "+1 bonus to ranged attack checks per rank." },
    redirect: { name: "redirect", displayName: "Redirect", ranked: false, summary: "Use Deception to redirect a missed attack at another target." },
    ritualist: { name: "ritualist", displayName: "Ritualist", ranked: false, summary: "Use Expertise (Magic) to create and perform rituals." },
    second_chance: { name: "second_chance", displayName: "Second Chance", ranked: true, summary: "Re-roll a failed check against a hazard once." },
    seize_initiative: { name: "seize_initiative", displayName: "Seize Initiative", ranked: false, summary: "Spend a hero point to go first in the initiative order." },
    set_up: { name: "set_up", displayName: "Set-up", ranked: true, summary: "Transfer the benefit of an interaction skill to an ally." },
    sidekick: { name: "sidekick", displayName: "Sidekick", ranked: true, summary: "Gain a sidekick with (5xrank) power points." },
    skill_mastery: { name: "skill_mastery", displayName: "Skill Mastery", ranked: false, summary: "Make routine checks with one skill under any circumstances." },
    startle: { name: "startle", displayName: "Startle", ranked: false, summary: "Use Intimidation to feint during combat." },
    takedown: { name: "takedown", displayName: "Takedown", ranked: true, summary: "Free extra attack when you incapacitate a minion." },
    taunt: { name: "taunt", displayName: "Taunt", ranked: false, summary: "Use Deception to demoralize in combat." },
    teamwork: { name: "teamwork", displayName: "Teamwork", ranked: false, summary: "+5 bonus to support team checks." },
    throwing_mastery: { name: "throwing_mastery", displayName: "Throwing Mastery", ranked: true, summary: "+1 damage bonus with thrown weapons per rank." },
    tracking: { name: "tracking", displayName: "Tracking", ranked: false, summary: "Use Perception to follow tracks." },
    trance: { name: "trance", displayName: "Trance", ranked: false, summary: "Go into a deathlike trance that slows bodily functions." },
    ultimate_effort: { name: "ultimate_effort", displayName: "Ultimate Effort", ranked: false, summary: "Spend a hero point to get an effective 20 on a specific check." },
    uncanny_dodge: { name: "uncanny_dodge", displayName: "Uncanny Dodge", ranked: false, summary: "Not vulnerable when surprised or caught off-guard." },
    weapon_bind: { name: "weapon_bind", displayName: "Weapon Bind", ranked: false, summary: "Free disarm attempt when you actively defend." },
    weapon_break: { name: "weapon_break", displayName: "Weapon Break", ranked: false, summary: "Free smash attack when you actively defend." },
    well_informed: { name: "well_informed", displayName: "Well-Informed", ranked: false, summary: "Immediate Investigation or Persuasion check to know something." },
}

