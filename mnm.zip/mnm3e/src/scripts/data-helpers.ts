

function addDeletesHelper<T extends {}>(obsoleteObject: T | null | undefined, updatedObject: T | null | undefined, updatedObjectRoot: any, currentPath: string[]) {


    if (typeof obsoleteObject != typeof updatedObject || !obsoleteObject || !updatedObject || typeof obsoleteObject != 'object' || typeof updatedObject != 'object')
        return;


    const fieldsInObsoleteObject = Object.keys(obsoleteObject);
    const fieldsInUpdatedObject = Object.keys(updatedObject);
    const allFields = new Set([...fieldsInObsoleteObject, ...fieldsInUpdatedObject]);

    for (let field of allFields) {

        const fullPath = [...currentPath, field];

        let fieldInObsoleteObject = (typeof obsoleteObject === 'object' && field in obsoleteObject);
        let fieldInUpdatedObject = (typeof updatedObject === 'object' && field in updatedObject);

        if (fieldInObsoleteObject && fieldInUpdatedObject) {
            // Do nothing but recurse
            addDeletesHelper((obsoleteObject as any)[field], (updatedObject as any)[field], updatedObjectRoot, fullPath)
        }
        else if (fieldInObsoleteObject && !(fieldInUpdatedObject)) {
            // This field is obsolete, so it should be marked to be deleted.
            (updatedObjectRoot as any)[`-=${fullPath.join('.')}`] = null!;
        }
        else if (!(fieldInObsoleteObject) && (fieldInUpdatedObject)) {
            // This field is brand new, so we don't need to mark anything inside it as obsolete
            // (There might have been an obsolete counterpart to this field, e.g. closeCombat -> close_combat, but that's taken care of elsewhere)
        }
        else {
            // Logic?????
        }
    }
}

export function addDeletes(obsoleteObject: any | null | undefined, updatedObject: any) {


    addDeletesHelper(obsoleteObject, updatedObject, updatedObject, []);
}
