

/*declare class ItemSheet<ItemType extends Item<any>> extends Application<ItemType extends Item<infer U>? U : never> {
    constructor(actor: ItemType, options?: { editable?: boolean });

    item: ItemType;

}*/

