
/**
 * Defines the base for all structures stored in the database.
 * In general you shouldn't add properties to Data1, instead adding them to Data2.
 * The Data2 parameter can contain any serializable JSON data.
 * 
 * In terms of terminology, the following is used consistently to avoid any possible ambiguity:
 * 
 * * Data1 refers to this.data
 * * Data2 refers to this.data.data
 * 
 * For anything that inherits from Entity or uses a similar structure. Some classes, like the sheets, use Data1 even though there's no corresponding Data2 (may change).
 */
declare interface EntityBaseData<EntityCustomData = unknown> {
    _id: string;
    name: string;
    type: string;
    flags: { exportSource?: { world: string, system: string, coreVersion: any, systemVersion: string }, [k: string]: unknown };
    data: EntityCustomData;
    folder?: unknown;
    permission?: { [K: string]: unknown };
}


type EntityBaseDataUpdateable<T extends EntityBaseData> = DeepPartial<T>;
type EntityBaseDataUpdateableWithId<T extends EntityBaseData> = EntityBaseDataUpdateable<T> & Pick<T, '_id'>;

interface EntityOptions {
    compendium?: unknown;
}

/*
export type LiteralUnion<
	LiteralType,
	BaseType
> = LiteralType | (BaseType & {_?: never});

export type LiteralStringUnion<T extends string> = LiteralUnion<T, string>;

type STR = LiteralStringUnion<'a' | 'B'>;

type PathExcludes = '__typename';
type PathImpl<T, TFound, TPref extends keyof T = never> =
    T extends TFound ? never :
    TPref extends never? PathImpl<T, TFound, keyof T> | keyof T: 
    TPref extends string? T[TPref] extends string | number | Date ? never : `${TPref}.${PathImpl<T[TPref], TFound | T, Exclude<keyof T[TPref], PathExcludes>> & string}` | `${TPref}.${Exclude<keyof T[TPref], PathExcludes> & string}`
    : keyof T;
type PathImpl2<T> = PathImpl<T, never, Exclude<keyof T, PathExcludes>> | Exclude<keyof T, PathExcludes>;
type Path<T> = (PathImpl2<T> extends string | keyof T ? PathImpl2<T> : keyof T);


type Query<T extends {}> = Path<T>;*/


// TODO: Make sure that EmbeddedEntities adhers to the constraint { [K: string]: string }
declare interface EntityEmbeddedEntities {
    // TODO: Do all entities have any shared embedded entities? E.g. items?
}


//type WithEmbeddedEntities<EntityType extends Entity<any, any, any>> = { embeddedEntities: GetEntityEmbeddedEntities<EntityType>; }

interface EntityConfig<EntityType extends Entity<any, any>, EntitySheetType extends null | BaseEntitySheet<any>> {
    collection: EntityCollection<EntityType>;
    baseEntity: EntityType;
    sheetClass: EntitySheetType;
    embeddedEntities: unknown;
}

interface EntityCreateOptions { renderSheet?: boolean; temporary?: boolean; }
interface EntityUpdateOptions { diff?: boolean; }
interface EntityDeleteOptions { }


/**
 * 
 * A wrapper class around some database object that can be used to inspect and modify the data that's used to build an Actor, Scene, Item, etc.
 * Each type of object has its own JavaScript wrapper class, though Entity doesn't represent anything in particular and is just a wrapper class (I think).
 * 
 * The most important functions to start with here are probably going to be: 
 * * prepareData: Add data that doesn't need to be stored in the database (like derived properties and metadata and such) before it's rendered
 * * create: Make a new one with new, custom data
 * * update: Send updated data to the server
 * * delete: Delete an entity from the server
 * 
 * There are also functions for adding entities to this entity (like actors who own items) that look very similar to the create, update, delete functions above.
 * 
 * 
 * Generic parameters:
 * * EntityBaseDataType: The data type used for this.data.  Actors, items, and other subclasses of entity modify EntityData1Type, and allow subclasses of *those* to modify the Data2Type.
 * * BaseEntitySheetClass: The sheet application to use for this entity (e.g. ActorSheet), or null if this entity type does not have a sheet type.
 */
declare abstract class Entity<
    EntityBaseDataType extends EntityBaseData,// = EntityData1, 
    BaseEntitySheetClass extends null | BaseEntitySheet<Entity<EntityBaseDataType, BaseEntitySheetClass>>// = BaseEntitySheet<Entity<EntityData1Type, any>, BaseEntitySheetData1<Entity<EntityData1Type, any>>>
    //SheetData1Type extends BaseEntitySheetData1<EntityData1Type, Entity<EntityData1Type, EmbeddedEntities, any>> = BaseEntitySheetData1<EntityData1Type, Entity<EntityData1Type, EmbeddedEntities, any>>
> {

    /**
     * Creates an entity
     * TODO: I think this should be prtoected, right? Since I think you're supposed to use the static creation functions instead.
     */
    protected constructor(data: EntityBaseDataType, options?: EntityCreateOptions);

    /** 
     * The data stored on the server for this entity.
     * While you can change this object (such as to add new, temporary properties)
     * any actual changes must be saved to the server by calling update().
     * 
     * In general, you cannot add new fields to this object, but you can freely modify its data field.
     */
    data: EntityBaseDataType;

    /**
     * The data stored on the server. Absolute source of truth.
     * Probably.
     * Updates aren't diffed against this though so ??????
     */
    readonly _data: EntityBaseDataType;

    /** 
     * The options object that was used to configure the Entity upon initialization.
     * Base classes often have different options.
     * */
    options: EntityOptions;

    /** 
     * A collection of Application instances which should be re-rendered whenever this Entity experiences an update to its data. 
     * The keys of this object are the application ids and the values are Application instances. 
     * Each Application in this object will have its render method called by {@link Entity#render}.
     * 
     * */
    apps: { [K: string]: Application };

    /** 
     * A reference to the Compendium pack object that this entity is a part of, if any.
     * */
    compendium: Compendium<this> | null;


    /** Subclasses must define this object */
    config: EntityConfig<this, BaseEntitySheetClass>

    /** 
     * A Universally Unique Identifier (uuid) for this Entity instance.
     * Not used for indexing any Foundry data structures, explicitly just a uuid.
     */
    get uuid(): string;


    /**
     * Initialize data structure for the Entity by calling prepareData on the entity and all embededded entities.
     * Any errors thrown during this process will be swallowed and sent to console.log.
     * 
     * This is only called during the constructor (probably?)
     */
    initialize(): void;

    /**
     * This function is called any time an Entity has been created or updated.
     * It is used to derive properties used on a character sheet, clean up and migrate data, etc.
     * When overriding, be sure to call super.getData() as well.
     * While this function does return the data type, it also modifies the data in-place (and so should any overriding functions).
     * 
     * This function does not need to be called manually.
     */
    prepareData(): EntityBaseDataType;


    /**
     * Prepare Embedded Entities which exist within this parent Entity.
     * For example, in the case of an Actor, this method is responsible for preparing the Owned Items the Actor contains.
     * If not overridden, this function uses _constructEmbeddedEntity, which base classes (such as Actor) must implement.
     * 
     * This function is called during initialize() and does not need to be called manually, but may be overridden.
     */
    prepareEmbeddedEntities(): void;

    /**
     * TODO: This function is not used?
     */
    _constructEmbeddedEntity(embeddedName: string, data: EntityBaseDataType): void;


    /**
     * Obtain a reference to the Array of source data within the data object for a certain Embedded Entity name
     * 
     * TODO: I haven't used this function yet.
     * 
     * @param {string} embeddedName   The name of the Embedded Entity type
     * @return {Array}                The Array of source data where Embedded Entities of this type are stored
     */
    getEmbeddedCollection<T extends Entity<any, any> = Entity<EntityBaseData<unknown>, BaseEntitySheet<any>>>(embeddedName: string): T[];


    /**
     * Render all of the Application instances which are connected to this Entity by calling their respective {@link Application#render} methods.
     * 
     * TODO: Need more details, does this ever need to be called manually?
     * 
     * @param {boolean} force     Force rendering
     * @param {Options} context   Optional context
     */
    render(force: boolean, context: unknown): void;







    /**
     * Return a reference to the EntityCollection instance which stores Entity instances of this type. This property is
     * available as both a static and instance method and should be overridden by subclass Entity implementations.
     * @type {EntityCollection}
     * @static
     */
    static get collection(): EntityCollection<Entity<EntityBaseData<unknown>, BaseEntitySheet<any>>>;

    static get entity(): EntityTypes;
    get entity(): EntityTypes;


    /** Convenience property that maps onto data._id */
    get id(): string;

    /** Convenience property that maps onto data._id */
    get _id(): string;

    /** Convenience property that maps onto data.name */
    get name(): string;

    get sheet(): BaseEntitySheetClass;


    /**
     * Return a reference to the Folder which this Entity belongs to, if any.
     *
     * @example <caption>Entities may belong to Folders</caption>
     * let folder = game.folders.entities[0];
     * let actor = await Actor.create({name: "New Actor", folder: folder.id});
     * console.log(actor.data.folder); // folder.id;
     * console.log(actor.folder); // folder;
     */
    get folder(): unknown | null;


    /**
     * Return the permission level that the current game User has over this Entity.
     * See the CONST.ENTITY_PERMISSIONS object for an enumeration of these levels.
     * @type {Number}
     *
     * @example
     * game.user.id; // "dkasjkkj23kjf"
     * entity.data.permission; // {default: 1, "dkasjkkj23kjf": 2};
     * entity.permission; // 2
     */
    get permission(): unknown;

    /** A boolean indicator for whether or not the current game User has ownership rights (in terms of permissions) for this Entity. */
    get owner(): boolean;

    /** A boolean indicator for whether or not the current game User has at least limited visibility (in terms of permissions) for this Entity. */
    get visible(): boolean;

    /** A boolean indicator for whether the current game user has ONLY limited visibility (in terms of permissionss) for this Entity. Note that a GM user's perspective of an Entity is never limited. */
    get limited(): boolean;


    /**
     * Test whether a provided User a specific permission level (or greater) over the Entity instance
     * @param {User} user                   The user to test for permission
     * @param {string|number} permission    The permission level or level name to test
     * @param {boolean} exact               Tests for an exact permission level match, by default this method tests for
     *                                      an equal or greater permission level.
     * @return {boolean}                    Whether or not the user has the permission for this Entity.
     *
     * @example <caption>Test whether a specific user has a certain permission</caption>
     * // These two are equivalent
     * entity.hasPerm(game.user, "OWNER");
     * entity.owner;
     * // These two are also equivalent
     * entity.hasPerm(game.user, "LIMITED", true);
     * entity.limited;
     */
    hasPerm(user: unknown, permission: UserPermission, exact?: boolean): boolean;

    /**
     * Test whether a given User has permission to perform some action on this Entity
     * @param {User} user           The User requesting creation
     * @param {string} action       The attempted action
     * @param {Entity} target       The targeted Entity
     * @return {boolean}            Does the User have permission?
     */
    static can(user: unknown, action: "create" | "update" | "delete", target: Entity<any, any>): boolean;

    /**
     * Test whether a given User has permission to perform some action on this Entity
     * @alias Entity.can
     */
    can(user: unknown, action: "create" | "update" | "delete"): boolean;




    /**
     * Create one or multiple new entities using provided input data.
     * Data may be provided as a single object to create one Entity, or as an Array of Objects.
     * Entities may be temporary (unsaved to the database) by passing the temporary option as true.
     * @static
     *
     * @param {Data|Data[]} data            A Data object or array of Data
     * @param {Options} options             Additional options which customize the creation workflow
     * @param {boolean} [options.temporary]     Create a temporary entity which is not saved to the world database. Default is false.
     * @param {boolean} [options.renderSheet]   Display the sheet for the created entity once it is created. Default is false.
     * 
     * @return {Promise<Entity|Entity[]>}   The created Entity or array of Entities
     *
     * @example
     * const data = {name: "New Entity", type: "character", img: "path/to/profile.jpg"};
     * const created = await Entity.create(data); // Returns one Entity, saved to the database
     * const temp = await Entity.create(data, {temporary: true}); // Not saved to the database
     *
     * @example
     * const data = [{name: "Tim", type: "npc"], [{name: "Tom", type: "npc"}];
     * const created = await Entity.create(data); // Returns an Array of Entities, saved to the database
     * const created = await Entity.create(data, {temporary: true}); // Not saved to the database
     */
    static create<EntityType extends Entity<any, any>>(data: EntityType['data'], options?: EntityCreateOptions): Promise<EntityType>;
    static create<EntityType extends Entity<any, any>>(data: Array<EntityType['data']>, options?: EntityCreateOptions): Promise<EntityType[]>;


    /**
     * Update one or multiple existing entities using provided input data.
     * Data may be provided as a single object to update one Entity, or as an Array of Objects.
     * @static
     *
     * @param {Data|Data[]} data            A Data object or array of Data. Each element must contain the _id of an existing Entity.
     * @param {Options} options             Additional options which customize the update workflow
     * @param {boolean} [options.diff]      Difference the provided data against the current to eliminate unnecessary changes.
     *
     * @return {Promise<Entity|Entity[]>}   The updated Entity or array of Entities
     *
     * @example
     * const data = {_id: "12ekjf43kj2312ds", name: "New Name"}};
     * const updated = await Entity.update(data); // Updated entity saved to the database
     *
     * @example
     * const data = [{_id: "12ekjf43kj2312ds", name: "New Name 1"}, {_id: "kj549dk48k34jk34", name: "New Name 2"}]};
     * const updated = await Entity.update(data); // Returns an Array of Entities, updated in the database
     */
    static update<EntityType extends Entity<any, any>>(data: EntityBaseDataUpdateableWithId<EntityType['data']>, options?: EntityUpdateOptions): Promise<EntityType>;
    static update<EntityType extends Entity<any, any>>(data: Array<EntityBaseDataUpdateableWithId<EntityType['data']>>, options?: EntityUpdateOptions): Promise<EntityType[]>;


    /**
     * Delete one or multiple existing entities using provided ids.
     * The target ids may be a single string or an Array of strings.
     * @static
     *
     * @param {string|string[]} data            A single id or Array of ids
     * @param {Options} options                 Additional options which customize the deletion workflow
  
     * @return {Promise<Entity|Entity[]>}       The deleted Entity or array of Entities
     *
     * @example
     * const id = "12ekjf43kj2312ds";
     * const deleted = await Entity.delete(id); // A single deleted entity from the database
     *
     * @example
     * const ids = ["12ekjf43kj2312ds", "kj549dk48k34jk34"];
     * const deleted = await Entity.delete(ids); // Returns an Array of deleted Entities
     */
    static delete<EntityType extends Entity<any, any>>(id: string, options?: EntityDeleteOptions): Promise<EntityType>;
    static delete<EntityType extends Entity<any, any>>(ids: Array<string>, options?: EntityDeleteOptions): Promise<EntityType[]>;


    /**
     * Update the current Entity using provided input data.
     * Data must be provided as a single object which updates the Entity data.
     * @see {Entity.update}
     *
     * @param {Data} data                   A Data object which updates the Entity
     * @param {Options} options             Additional options which customize the update workflow
     * @return {Promise<Entity>}            The updated Entity
     */
    update(data: EntityBaseDataUpdateable<EntityBaseDataType>, options?: EntityUpdateOptions): Promise<this>;

    /**
     * Delete the current Entity.
     * @see {Entity.delete}

    * @param {Options} options             Options which customize the deletion workflow
    * @return {Promise<Entity>}            The deleted Entity
    */
    delete(options?: EntityDeleteOptions): Promise<this>;




    /**
     * Get an Embedded Entity by its id from a named collection in the parent Entity.
     *
     * @param {string} embeddedName   The name of the Embedded Entity type to retrieve
     * @param {string} id             The numeric ID of the child to retrieve
     * @param {boolean} strict        Throw an Error if the requested id does not exist, otherwise return null. Default false.
     * @return {Object|null}          Retrieved data for the requested child, or null
     */
    getEmbeddedEntity<EntityType extends Entity<any, any>>(embeddedName: string, id: number, options?: { strict: boolean }): EntityType | null;



    /**
     * Create one or multiple EmbeddedEntities within this parent Entity.
     * Data may be provided as a single Object to create one EmbeddedEntity or as an Array of Objects to create many.
     * Entities may be temporary (unsaved to the database) by passing the temporary option as true.
     *
     * @param {string} embeddedName   The name of the Embedded Entity class to create
     * @param {Data|Data[]} data      A Data object or an Array of Data objects to create
     * @param {Options} options       Additional creation options which modify the request
     * @param {boolean} [options.temporary]     Create a temporary entity which is not saved to the world database. Default is false.
     * @param {boolean} [options.renderSheet]   Display the sheet for each created Embedded Entities once created.
     *
     * @return {Promise<Data|Data[]>} A Promise which resolves to the created embedded Data once the creation request is successful
     *
     * @example
     * const actor = game.actors.get("dfv934kj23lk6h9k");
     * const data = {name: "Magic Sword", type: "weapon", img: "path/to/icon.png"};
     * const created = await actor.createEmbeddedEntity("OwnedItem", data); // Returns one EmbeddedEntity, saved to the Actor
     * const temp = await actor.createEmbeddedEntity("OwnedItem", data, {temporary: true}); // Not saved to the Actor
     *
     * @example
     * const actor = game.actors.get("dfv934kj23lk6h9k");
     * const data = [{name: "Mace of Crushing", type: "weapon"}, {name: "Shield of Defense", type: "armor"}];
     * const created = await actor.createEmbeddedEntity("OwnedItem", data); // Returns an Array of EmbeddedEntities, saved to the Actor
     * const temp = await actor.createEmbeddedEntity("OwnedItem", data, {temporary: true}); // Not saved to the Actor
     */
    createEmbeddedEntity<EntityType extends Entity<any, any>>(embeddedName: string, data: EntityType['data'], options?: EntityCreateOptions): Promise<EntityType>;
    createEmbeddedEntity<EntityType extends Entity<any, any>>(embeddedName: string, data: Array<EntityType['data']>, options?: EntityCreateOptions): Promise<EntityType[]>;

    /**
     * Update one or multiple existing entities using provided input data.
     * Data may be provided as a single object to update one Entity, or as an Array of Objects.
     * @static
     *
     * @param {string} embeddedName   The name of the Embedded Entity class to create
     * @param {Data|Data[]} data            A Data object or array of Data. Each element must contain the _id of an existing Entity.
     * @param {Options} options             Additional options which customize the update workflow
     * @param {boolean} [options.diff]      Difference the provided data against the current to eliminate unnecessary changes.
     *
     * @return {Promise<Entity|Entity[]>}   The updated Entity or array of Entities
     *
     * @example
     * const actor = game.actors.get("dfv934kj23lk6h9k");
     * const item = actor.data.items.find(i => i.name === "Magic Sword");
     * const update = {_id: item._id, name: "Magic Sword +1"};
     * const updated = await actor.updateEmbeddedEntity("OwnedItem", update); // Updates one EmbeddedEntity
     *
     * @example
     * const actor = game.actors.get("dfv934kj23lk6h9k");
     * const weapons = actor.data.items.filter(i => i.type === "weapon");
     * const updates = weapons.map(i => {
     *   return {_id: i._id, name: i.name + "+1"};
     * }
     * const updated = await actor.createEmbeddedEntity("OwnedItem", updates); // Updates multiple EmbeddedEntity objects
     */
    updateEmbeddedEntity<EntityType extends Entity<any, any>>(embeddedName: string, data: EntityType['data'], options?: EntityUpdateOptions): Promise<EntityType>;
    updateEmbeddedEntity<EntityType extends Entity<any, any>>(embeddedName: string, data: Array<EntityType['data']>, options?: EntityUpdateOptions): Promise<EntityType[]>;


    /**
     * Delete one or multiple existing EmbeddedEntity objects using provided input data.
     * Data may be provided as a single id to delete one object or as an Array of string ids.
     * @static
     *
     * @param {string} embeddedName   The name of the Embedded Entity class to create
     * @param {string|string[]} data        A Data object or array of Data. Each element must contain the _id of an existing Entity.
     * @param {Options} options             Additional options which customize the update workflow
  
     * @return {Promise<Data|Data[]>}       The deleted Embedded Entities
     *
     * @example
     * const actor = game.actors.get("dfv934kj23lk6h9k");
     * const item = actor.data.items.find(i => i.name === "Magic Sword");
     * const deleted = await actor.deleteEmbeddedEntity("OwnedItem", item._id); // Deletes one EmbeddedEntity
     *
     * @example
     * const actor = game.actors.get("dfv934kj23lk6h9k");
     * const weapons = actor.data.items.filter(i => i.type === "weapon");
     * const deletions = weapons.map(i => i._id);
     * const updated = await actor.deleteEmbeddedEntity("OwnedItem", deletions); // Deletes multiple EmbeddedEntity objects
  
     */
    deleteEmbeddedEntity<EntityType extends Entity<any, any>>(embeddedName: string, id: string, options?: EntityDeleteOptions): Promise<EntityType>;
    deleteEmbeddedEntity<EntityType extends Entity<any, any>>(embeddedName: string, id: string[], options?: EntityDeleteOptions): Promise<EntityType[]>;

    /**
     * Get the value of a "flag" for this Entity
     * See the setFlag method for more details on flags
     *
     * @param {String} scope    The flag scope which namespaces the key
     * @param {String} key      The flag key
     * @return {*}              The flag value
     */
    getFlag(scope: string, key: string): unknown;


    /**
     * Assign a "flag" to this Entity.
     * Flags represent key-value type data which can be used to store flexible or arbitrary data required by either
     * the core software, game systems, or user-created modules.
     *
     * Each flag should be set using a scope which provides a namespace for the flag to help prevent collisions.
     *
     * Flags set by the core software use the "core" scope.
     * Flags set by game systems or modules should use the canonical name attribute for the module
     * Flags set by an individual world should "world" as the scope.
     *
     * Flag values can assume almost any data type. Setting a flag value to null will delete that flag.
     *
     * @param {String} scope    The flag scope which namespaces the key
     * @param {String} key      The flag key
     * @param {*} value         The flag value
     *
     * @return {Promise.<Entity>} A Promise resolving to the updated Entity
     */
    setFlag(scope: string, key: string, value: unknown): Promise<this>;

    /**
     * Remove a flag assigned to the Entity
     * @param {string} scope    The flag scope which namespaces the key
     * @param {string} key      The flag key
     * @return {Promise}        A Promise resolving to the updated Entity
     */
    unsetFlag(scope: string, key: string): Promise<this>;


    /**
     * Sort this Entity relative a target by providing the target, an Array of siblings and other options.
     * If the Entity has an rendered sheet, record the sort change as part of a form submission
     * See SortingHelper.performIntegerSort for more details
     */
    sortRelative(options?: { target: unknown | null, siblings: unknown[], sortKey: string, sortBefore: boolean, updateData?: unknown }): Promise<unknown>;


    /**
     * Clone an Entity, creating a new Entity using the current data as well as provided creation overrides.
     *
     * @param {Object} createData     Additional data which overrides current Entity data at the time of creation
     * @param {Object} options        Additional creation options passed to the Entity.create method
     * @returns {Promise.<Entity>}    A Promise which resolves to the created clone Entity
     */
    clone(createData: DeepPartial<EntityBaseDataType>, options: EntityCreateOptions): Promise<this>;


    /**
     * Returns an entity's data (this.data, generally) serialized as a JSON string.
     * If overridden, your version should do the same, e.g. returning JSON.stringify(this.data) (or comparible).
     */
    toJSON(): string;

    /**
     * Import data and update this entity, opposite of toJSON.
     */
    importFromJSON(json: string): Promise<this>;


    /**
     * Download the current entity's data (as represented by toJSON())
     */
    exportToJSON(): void;

    /**
     * Render an import dialog for updating the data related to this Entity through an exported JSON file, opposite of exportToJSON
     */
    importFromJSONDialog(): Promise<void>;


    /**
     * Transform the Entity data to be stored in a Compendium pack.
     * Remove any features of the data which are world-specific.
     * This function is asynchronous in case any complex operations are required prior to exporting.
     *
     * @return {Object}   A data object of cleaned data ready for compendium import
     */
    toCompendium(): Promise<EntityBaseDataType>;

    //type: string;


    //items: Collection<unknown, Item<unknown, ItemData1<unknown>, ItemSheetData1<unknown, ItemData1<unknown>>, Actor<unknown, ActorData1<unknown>, ActorSheetData1<unknown, ActorData1<unknown>>>>>;




}

declare class EntityCollection<EntityType> extends Collection<string, EntityType> {
    apps: Application[];

    get entities(): IterableIterator<EntityType>;

    render(...args: unknown[]): this;

    get name(): string;

    get instance(): unknown | null;
    get directory(): unknown | null;

    fromCompendium(data: unknown): unknown;

    // TODO: Figure out the types for these
    static registerSheet(arg1: string, entityClass: any, options?: { types?: string[], makeDefault?: boolean }): void;
    static unregisterSheet(arg1: string, entityClass: any): void;
}




/*declare class FormApplication {
    static defaultOptions: unknown;

    constructor(object: unknown, options: unknown);

    appId: number;
    editors: unknown;
    element: JQuery | HTMLElement;
    filepickers: unknown[];
    form: HTMLElement;
    id: string;
    isEditable: boolean;
    object: unknown;
    options: { editable: boolean; }

    activateListeners(html: JQuery): void;

    _onSubmit(event: Event, options?: { updateData?: unknown | null, preventClose?: boolean, preventRender?: boolean }): Promise<void>

    render(force?: boolean, options?: { left: number, top: number, width: number, height: number, scale: number, log: boolean, renderContext: string, renderData: unknown }): void;
}*/




