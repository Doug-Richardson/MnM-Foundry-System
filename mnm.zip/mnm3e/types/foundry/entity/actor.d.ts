
interface ActorBaseData<ActorCustomDataType, OtherClassTypes extends { token: Token<any, any>, item: Item<any, any, any> }> extends EntityBaseData<ActorCustomDataType> {
    img: string;
    token: OtherClassTypes['token']['data'],
    items: Array<OtherClassTypes['item']['data']>,
}

declare interface ActorOptions<TokenClassType extends Token<any, any>> extends EntityOptions {
    token?: TokenClassType;
}

interface ActorEmbeddedEntities extends EntityEmbeddedEntities {
    OwnedItems: 'items'
}

declare interface ActorConfig<ActorType extends Actor<any, any>, ActorSheetType extends ActorSheet<any>> extends EntityConfig<ActorType, ActorSheetType> {
    label: "ENTITY.Actor",
    permissions: {
        create: "ACTOR_CREATE"
    }
}

interface ActorCreateOptions extends EntityCreateOptions { }
interface ActorUpdateOptions extends EntityUpdateOptions { }
interface ActorDeleteOptions extends EntityDeleteOptions { }

declare class Actor<
    ActorData2Type = unknown,
    ActorSheetType extends ActorSheet<Actor<ActorData2Type, ActorSheetType, any>> = ActorSheet<Actor<ActorData2Type, any>>,
    OtherClassTypes extends { token: Token<any, any>, item: Item<any, any, any> } = { token: Token, item: Item }
> extends Entity<ActorBaseData<ActorData2Type, OtherClassTypes>, ActorSheetType> {


    options: ActorOptions<Token<ActorData2Type, any>>;
    config: ActorConfig<this, ActorSheetType>;

    /**
     * A reference to a placed Token which creates a synthetic Actor
     * TODO: This can be initialialized with creation options, can it be set after that too? Also corresponds to data.token Y/N?
     * @type {Token}
     */
    token: OtherClassTypes['token']['data'] | null;

    /**
     * Same as this.data.img
     */
    get img(): string;


    /**
     * Classify Owned Items by their type
     * TODO
     */
    get itemTypes(): { [K: string]: unknown[] };


    /**
     * A boolean flag for whether this Actor is a player-owned character.
     * True if any User who is not a GM has ownership rights over the Actor entity.
     */
    get isPC(): boolean;


    /**
     * Test whether an Actor entity is a synthetic representation of a Token (if true) or a full Entity (if false)
     * @type {boolean}
     */
    get isToken(): boolean;


    /**
     * Create a synthetic Actor using a provided Token instance
     * If the Token data is linked, return the true Actor entity
     * If the Token data is not linked, create a synthetic Actor using the Token's actorData override
     * @param {Token} token
     * @return {Actor}
     */
    static fromToken<TokenType extends Token<any, any>>(token: TokenType): Promise<TokenType['actor']>;


    /**
     * Create a synthetic Token Actor instance which is used in place of an actual Actor.
     * Cache the result in Actors.tokens.
     * 
     * TODO: ????????
     */
    static createTokenActor(baseActor: unknown, token: unknown): Promise<unknown>;


    /**
     * Retrieve an Array of active tokens which represent this Actor in the current canvas Scene.
     * If the canvas is not currently active, or there are no linked actors, the returned Array will be empty.
     * 
     * TODO: Return type might not be accurate, might be Token<unknown>
     *
     * @param [linked] {Boolean}  Only return tokens which are linked to the Actor. Default (false) is to return all
     *                            tokens even those which are not linked.
     *
     * @return {Array}            An array of tokens in the current Scene which reference this Actor.
     */
    getActiveTokens(linked?: boolean): OtherClassTypes['token'][];


    /**
     * Prepare a data object which defines the data schema used by dice roll commands against this Actor
     * By default, just returns this.data.data.
     * TODO: Exact return type
     */
    getRollData(): unknown;


    /**
     * Get an Array of Token images which could represent this Actor
     * @return {Promise}
     */
    getTokenImages(): Promise<unknown[]>;


    /**
     * Handle how changes to a Token attribute bar are applied to the Actor.
     * This allows for game systems to override this behavior and deploy special logic.
     * 
     * This function returns once the actor has been updated.
     * 
     * @param {string} attribute    The attribute path, relative to this.data.data
     * @param {number} value        The target attribute value
     * @param {boolean} isDelta     Whether the number represents a relative change (true) or an absolute change (false)
     * @param {boolean} isBar       Whether the new value is part of an attribute bar, or just a direct value
     * @return {Promise}
     */
    modifyTokenAttribute<T extends keyof ActorData2Type>(attribute: T, value: ActorData2Type[T], isDelta?: boolean, isBar?: boolean): Promise<this>;


    /**
     * Import a new owned Item from a compendium collection
     * The imported Item is then added to the Actor as an owned item.
     * 
     * TODO: More specific types?
     *
     * @param collection {String}     The name of the pack from which to import
     * @param entryId {String}        The ID of the compendium entry to import
     */
    importItemFromCollection(collection: string, entryId: string): Promise<unknown>;


    /**
     * Get an Item instance corresponding to the Owned Item with a given id
     * @param {string} itemId   The OwnedItem id to retrieve
     * @return {Item}           An Item instance representing the Owned Item within the Actor entity
     */
    getOwnedItem<ItemType extends OtherClassTypes['item'] = OtherClassTypes['item']>(itemId: string): ItemType;

    /**
     * Create a new item owned by this Actor. This redirects its arguments to the createEmbeddedEntity method.
     * @see {Entity#createEmbeddedEntity}
     *
     * @param {Object} itemData     Data for the newly owned item
     * @param {Object} options      Item creation options
     * @param {boolean} options.renderSheet Render the Item sheet for the newly created item data
     * @return {Promise.<Object>}   A Promise resolving to the created Owned Item data
     */
    createOwnedItem<ItemType extends OtherClassTypes['item'] = OtherClassTypes['item']>(itemData: DeepPartial<ItemType['data']>, options?: ItemCreateOptions): Promise<ItemType>;


    /**
     * Update an owned item using provided new data. This redirects its arguments to the updateEmbeddedEntity method.
     * @see {Entity#updateEmbeddedEntity}
     *
     * @param {Object} itemData     Data for the item to update
     * @param {Object} options      Item update options
     * @return {Promise.<Object>}   A Promise resolving to the updated Owned Item data
     */
    updateOwnedItem<ItemType extends OtherClassTypes['item'] = OtherClassTypes['item']>(itemData: DeepPartial<ItemType['data']>, options?: ItemUpdateOptions): Promise<ItemType>;


    /**
     * Delete an owned item by its id. This redirects its arguments to the deleteEmbeddedEntity method.
     * @see {Entity#deleteEmbeddedEntity}
     *
     * @param {string} itemId       The ID of the item to delete
     * @param {Object} options      Item deletion options
     * @return {Promise.<Object>}   A Promise resolving to the deleted Owned Item data
     */
    deleteOwnedItem<ItemType extends OtherClassTypes['item'] = OtherClassTypes['item']>(itemId: string, options?: ItemDeleteOptions): Promise<ItemType>;




    /**
     * The items owned by this actor. This is initialized in prepareEmbeddedEntities(), which itself is run once before prepareData and once after.
     * Thus, this property will not always be available.
     * 
     * TODO: I don't think this can be modified in-place. I think you need to either update the data.items array, or to createEmbeddedItem.
     */
    items?: Collection<string, OtherClassTypes['item']>;

    get sheet(): ActorSheetType;

}


//  = Actor<unknown, ActorSheet<Actor<unknown, any, any>, any>>
declare class Actors<ActorType extends Actor<any, any, any>> extends EntityCollection<ActorType> {
    //static registerSheet<T extends typeof ActorSheet>(arg1: string, entityClass: T, options?: { types?: string[], makeDefault?: boolean }): void;
    //static unregisterSheet<T extends typeof ActorSheet>(arg1: string, entityClass: T): void;

    createOwnedItem(itemData: ItemBaseData<any>, options: { renderSheet?: boolean }): Promise<this>;
    deleteOwnedItem(itemId: string, options?: never): Promise<ItemBaseData>

    createEmbeddedEntity(embeddedName: 'OwnedItem', data: any, options?: { temporary?: false }): Promise<this>;
    createEmbeddedEntity(embeddedName: 'OwnedItem', data: any, options?: { temporary: true }): null;
}
