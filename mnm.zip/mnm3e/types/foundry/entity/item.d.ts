

declare class Items<ItemType extends Item<any, any, any>> extends EntityCollection<ItemType> {
}

declare interface ItemEmbeddedEntities extends EntityEmbeddedEntities {
    // TODO: Anything in here?
}

declare interface ItemBaseData<ItemData2Type = unknown> extends EntityBaseData<ItemData2Type> {
    img: string;
}

declare interface ItemOptions<TokenClassType extends Token<any, any>> extends EntityOptions {
    token?: TokenClassType;
}

declare interface ItemConfig<ItemType extends Item<any, any, any>, ItemSheetType extends ItemSheet<any>> extends EntityConfig<ItemType, ItemSheetType> {
    baseEntity: ItemType,
    label: "ENTITY.Item",
    permissions: {
        create: "ITEM_CREATE"
    }
}

declare interface ItemCreateOptions extends EntityCreateOptions { }
declare interface ItemUpdateOptions extends EntityUpdateOptions { }
declare interface ItemDeleteOptions extends EntityDeleteOptions { }


/*declare class Item<
    ItemData1Type extends ItemData1<any> = ItemData1,
    ItemSheetData1Type extends ItemSheetData1<any> = ItemSheetData1<Item<ItemData1, any, any, any>>,
    EmbeddedEntities extends ItemEmbeddedEntities = ItemEmbeddedEntities,
    ActorType extends Actor<any, any, any> = Actor
    > extends Entity<ItemData1Type, ItemSheetData1Type, EmbeddedEntities>*/


declare class Item<
    ItemData2Type = unknown,
    ItemSheetType extends ItemSheet = ItemSheet,
    OtherTypes extends { actor: Actor, scene: Scene } = { actor: Actor, scene: Scene }
    > extends Entity<ItemBaseData<ItemData2Type>, ItemSheetType> {

    actor: OtherTypes['actor'] | null;
    config: ItemConfig<this, ItemSheetType>;
    options: ItemOptions<Token>;

    data: ItemBaseData<ItemData2Type>;

    img: ItemBaseData<ItemData2Type>['img'];
    readonly type: ItemBaseData<ItemData2Type>['type'];

    /** 
     * Whether or not this item is owned by an Actor or not
     * TODO: Under what conditions, aside from being in the menu, would an item not be owned?
     */
    readonly isOwned: boolean;


    /**
     * Indicates whether or not current game user has ONLY limited visibility for this Item.
     * If this item is owned by an actor, then its visibility is further constrained by the actor's visibility.
     */
    get limited(): boolean;

    /**
     * Functions the same as entity#update, but also handles the case where this item is owned by an actor 
     * (and thus needs to actually update two things)
     */
    update<T extends ItemData2Type = ItemData2Type>(data: DeepPartial<ItemBaseData<T>>, options?: ItemUpdateOptions | ActorUpdateOptions): Promise<this>;

    /**
     * Functions the same as entity#delete, but also handles the case where this item is owned by an actor
     */
    delete(options?: ItemDeleteOptions | ActorDeleteOptions): Promise<this>;


    /**
     * A convenience constructor method to create an Item instance which is owned by an Actor
     * @param {Object} itemData
     * @param {Actor} actor
     */
    static createOwned<ItemType extends Item<any, any, any>>(itemData: ItemType['data'], actor: Actor<any, any, any>): Promise<ItemType>;

}




