/**
 * A helper class which assists with localization and string translation
 */
declare class Localization<StringIds extends string = string> {

    lang: string;
    translations: { [key in StringIds]: string; };


    constructor();

    /* -------------------------------------------- */

    /**
     * Initialize the Localization module
     * Discover available language translations and apply the current language setting
     * 
     * TODO: Is it required to manually call this?
     * @return {Promise}
     */
    initialize(): Promise<void>;

    /* -------------------------------------------- */

    /**
     * Set a language as the active translation source for the session
     * @param {string} lang       A language string in CONFIG.supportedLanguages
     * @return {Promise}          A Promise which resolves once the translations for the requested language are ready
     */
    setLanguage(lang: string): Promise<void>;


    /**
     * Localize a string by drawing a translation from the available translations dictionary, if available
     * If a translation is not available, the original string is returned
     * @param {String} stringId     The string ID to translate
     * @return {String}             The translated string
     */
    localize(stringId: string): string;

    /* -------------------------------------------- */

    /**
     * Localize a string including variable formatting for input arguments.
     * Provide a string ID which defines the localized template.
     * Variables can be included in the template enclosed in braces and will be substituted using those named keys.
     *
     * @param {string} stringId     The string ID to translate
     * @param {Object} data         Provided input data
     * @return {string}             The translated and formatted string
     *
     * @example
     * const stringId = "MY_TEST_STRING"; // "Your name is {name}"
     * game.i18n.format("MY_TEST_STRING", {name: "Andrew"}); // Produces "Your name is Andrew"
     */
    format(stringId: StringIds, data?: { [k: string]: string }): string;
}
