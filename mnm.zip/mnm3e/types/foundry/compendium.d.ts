
interface CompendiumMetadata {
    package: unknown;
    name: string;
    entity: EntityTypes;
    label: string;
}

interface CompendiumData {
    collection: string,
    searchString: string,
    cssClass: string,
    index: unknown[];
}

/**
 * The Compendium class provides an interface for interacting with compendium packs which are 
 * collections of similar Entities which are stored outside of the world database but able to
 * be easily imported into an active session.
 * 
 * When the game session is initialized, each available compendium pack is constructed and 
 * added to the ``game.packs``.
 *
 * Each Compendium is distinctly referenced using its canonical "collection" name which is a 
 * unique string that contains the package name which provides the compendium as well as the
 * name of the pack within that package. For example, in the D&D5e system, the compendium pack
 * which provides the spells available within the SRD has the collection name "dnd5e.spells".
 *
 * @type {Application}
 *
 * @param metadata {Object}   The compendium metadata, an object provided by game.data
 * @param options {Object}    Application rendering options
 *
 * @example
 * // Let's learn the collection names of all the compendium packs available within a game
 * game.packs.keys();
 *
 * // Suppose we are working with a particular pack named "dnd5e.spells"
 * const pack = game.packs.get("dnd5e.spells");
 * 
 * // We can load the index of the pack which contains all entity IDs, names, and image icons
 * pack.getIndex().then(index => console.log(index));
 * 
 * // We can find a specific entry in the compendium by its name
 * let entry = pack.index.find(e => e.name === "Acid Splash");
 * 
 * // Given the entity ID of "Acid Splash" we can load the full Entity from the compendium
 * pack.getEntity(entry.id).then(spell => console.log(spell));
 * 
 * @example
 * // We often may want to programmatically create new Compendium content
 * // Let's start by creating a custom spell as an Item instance
 * let itemData = {name: "Custom Death Ray", type: "Spell"};
 * let item = new Item(itemData);
 * 
 * // Once we have an entity for our new Compendium entry we can import it, if the pack is unlocked
 * pack.importEntity(item);
 * 
 * // When the entity is imported into the compendium it will be assigned a new ID, so let's find it
 * pack.getIndex().then(index => {
 *   let entry = index.find(e => e.name === itemData.name));
 *   console.log(entry);
 * });
 *
 * // If we decide to remove an entry from the compendium we can do that by the entry ID
 * pack.removeEntry(entry.id);
 */
declare class Compendium<StoredType extends Entity<any, any>> extends Application {

    getData(): Promise<CompendiumData> | CompendiumData;

    /**
     * The compendium metadata which defines the compendium content and location
     * @type {Object}
     */
    metadata: CompendiumMetadata;

    /**
     * Track whether the compendium pack is locked for editing
     * @type {boolean}
     */
    locked: boolean;


    /**
     * Track whether the compendium pack is private
     * @type {Boolean}
     */
    private: boolean;

    /**
     * The most recently retrieved index of the Compendium content
     * This index is not guaranteed to be current - call getIndex() to reload the index
     * @type {Array}
     */
    index: unknown[];

    // Internal flags
    searchString: null | string;

    constructor(metadata: CompendiumMetadata, options: ApplicationOptions);

    /* ----------------------------------------- */

    /**
     * The canonical Compendium name - comprised of the originating package and the pack name
     * @return {string}     The canonical collection name
     */
    get collection(): string;

    /* ----------------------------------------- */

    /**
     * The Entity type which is allowed to be stored in this collection
     * @type {String}
     */
    get entity(): EntityTypes;

    /* ----------------------------------------- */

    /**
     * A reference to the Entity class object contained within this Compendium pack
     * @return {*}
     */
    get cls(): unknown;



    /**
     * Create a new Compendium pack using provided
     * @param {Object} metadata   The compendium metadata used to create the new pack
     * @param {Options} options   Additional options which modify the Compendium creation request
     * @return {Promise.<Compendium>}
     */
    static create<CompendiumType extends Compendium<any> = Compendium<any>>(metadata: CompendiumMetadata, options?: DeepPartial<ApplicationOptions>): Promise<CompendiumType>;

    /* ----------------------------------------- */

    /**
     * Assign configuration metadata settings to the compendium pack
     * @param {Object} settings   The object of compendium settings to define
     * @return {Promise}          A Promise which resolves once the setting is updated
     */
    configure(settings?: ApplicationOptions): Promise<void>;

    /* ----------------------------------------- */

    /**
     * Delete a world Compendium pack
     * This is only allowed for world-level packs by a GM user
     * @return {Promise.<Compendium>}
     */
    delete(): Promise<this>;

    /* ----------------------------------------- */

    /**
     * Duplicate a compendium pack to the current World
     * @param label
     * @return {Promise<Compendium>}
     */
    duplicate(options?: { label: string }): Promise<this>;

    /* ----------------------------------------- */

    /**
     * Returns a promise to an array containing all the objects' data in this compendium, 
     * but does NOT construct their corresponding class objects, 
     * instead just including the ID, name, and img fields to save time and/or space.
     */
    getIndex(): Promise<Pick<StoredType['data'], '_id' | 'img' | 'name'>[]>;

    /* ----------------------------------------- */

    /**
     * Returns a promise to array representing every entity in this compendium as its actual class type.
     */
    getContent(): Promise<StoredType[]>;

    /* ----------------------------------------- */

    /**
     * Get a single Compendium entry as an Object
     * @param entryId {String}  The compendium entry ID to retrieve
     *
     * @return {Promise.<Object|null>}  A Promise containing the return entry data, or null
     */
    getEntry(entryId: string): Promise<StoredType>

    /* ----------------------------------------- */

    /**
     * Get a single Compendium entry as an Entity instance
     * @param {string} entryId          The compendium entry ID to load and instantiate
     * @return {Promise.<Entity|null>}   A Promise containing the returned Entity, if it exists, otherwise null
     */
    getEntity(entryId: string): Promise<StoredType | null>

    /* ----------------------------------------- */

    /* ----------------------------------------- */

    /**
     * Import a new Entity into a Compendium pack
     * @param {Entity} entity     The Entity instance you wish to import
     * @return {Promise}          A Promise which resolves to the created Entity once the operation is complete
     */
    importEntity(entity: StoredType): Promise<void>;

    /* -------------------------------------------- */

    /**
     * Create a new Entity within this Compendium Pack using provided data
     * @param {Object} data       Data with which to create the entry
     * @param {Options} options   Additional options which modify the creation
     * @return {Promise}          A Promise which resolves to the created Entity once the operation is complete
     */
    createEntity(data: StoredType['data'], options: EntityCreateOptions): Promise<StoredType>; 
    createEntity(data: Array<StoredType['data']>, options: EntityCreateOptions): Promise<StoredType[]>; 

    /* -------------------------------------------- */

    /**
     * Update a single Compendium entry programmatically by providing new data with which to update
     * @param {Object} data       The incremental update with which to update the Entity. Must contain the _id
     * @param {Object} options    Additional options which modify the update request
     * @return {Promise}          A Promise which resolves with the updated Entity once the operation is complete
     */
    updateEntity(data: StoredType['data'], options: EntityUpdateOptions): Promise<StoredType>; 
    updateEntity(data: Array<StoredType['data']>, options: EntityUpdateOptions): Promise<StoredType[]>; 

    /* ----------------------------------------- */

    /**
     * Delete a single Compendium entry by its provided _id
     * @param {String} id         The entry ID to delete
     * @param {Object} options    Additional options which modify the deletion request
     * @return {Promise}          A Promise which resolves to the deleted entry ID once the operation is complete
     */
    deleteEntity(id: string, options: EntityDeleteOptions): Promise<string>; 
    deleteEntity(ids: Array<string>, options: EntityDeleteOptions): Promise<string[]>; 

    /* -------------------------------------------- */

    /**
     * Request that a Compendium pack be migrated to the latest System data template
     * @return {Promise.<Compendium>}
     */
    migrate(options: unknown): Promise<unknown>;

    /* -------------------------------------------- */

    /**
     * Filter the results in the Compendium pack to only show ones which match a provided search string
     * @param {string} searchString    The search string to match
     */
    search(searchString: string): void;

}
