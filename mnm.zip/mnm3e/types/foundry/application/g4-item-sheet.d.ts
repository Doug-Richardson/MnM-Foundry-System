
declare interface ItemSheetData<TargetItemType extends Item<any, any, any>> extends BaseEntitySheetBaseData<TargetItemType> {
    item: TargetItemType['data'];
    data: TargetItemType['data']['data'];
}



declare interface ItemSheetOptions extends BaseEntitySheetOptions { }


declare class ItemSheet<DescribedItemType extends Item = Item<any, any>> extends BaseEntitySheet<DescribedItemType> {

    actor: DescribedItemType['actor'];
    item: DescribedItemType;
    getData(): ItemSheetData<DescribedItemType> | Promise<ItemSheetData<DescribedItemType>>

    readonly options: DeepPartial<ItemSheetOptions>;
    static get defaultOptions(): ItemSheetOptions;

    protected _onDragStart(ev: DragEvent): void;
}



