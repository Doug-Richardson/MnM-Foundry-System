
declare interface FormApplicationData<TargetObjectType> {
    object: TargetObjectType;
    options: FormApplicationOptions;
}

declare interface FormApplicationOptions extends ApplicationOptions {
    editable: boolean;
    tabs: [{ navSelector: string, contentSelector: string, initial: string }];
    classes: string[],
    closeOnSubmit: boolean,
    submitOnChange: boolean,
    submitOnClose: boolean
}


declare abstract class FormApplication<TargetObjectType extends Entity<any, any>> extends Application {
    constructor(object: TargetObjectType, options?: FormApplicationOptions);

    object: TargetObjectType;
    form: HTMLFormElement | null;

    filepickers: FilePicker[];

    editors: { [key: string]: unknown };

    /**
     * Is the Form Application currently editable?
     * TODO: When is this true or false?
     */
    get isEditable(): boolean;


    abstract getData(options?: FormApplicationOptions): FormApplicationData<TargetObjectType> | Promise<FormApplicationData<TargetObjectType>>;

    /**
     * Besides the standard logic of Application#close, destroys any remaining MCE instances 
     * and allows overriding the default behavior of submitOnClose with the submit option.
     */
    close(options?: { submit?: boolean }): Promise<this>;

    /**
     * 
     * @param options 
     * 
     * @param {Object|null} [updateData]  Additional specific data keys/values which override or extend the contents of
     *                                    the parsed form. This can be used to update other flags or data fields at the
     *                                    same time as processing a form submission to avoid multiple database operations.
     * @param {Boolean} [preventClose]    Override the standard behavior of whether to close the form on submit
     * @param {boolean} [preventRender]   Prevent the application from re-rendering as a result of form submission
     */
    submit(options: { updateData?: boolean, preventClose?: boolean, preventRender?: boolean }): Promise<void>;

    /**
     * This method is called upon form submission after form data is validated.
     * Subclasses of the FormApplication class must implement this method.
     * 
     * @param event {Event}       The initial triggering submission event
     * @param formData {Object}   The object of validated form data with which to update the object
     * @returns {Promise}         A Promise which resolves once the update operation has completed 
     * @abstract
     */
    abstract _updateObject(event: Event, formData: FormData): Promise<unknown>;

	options: DeepPartial<FormApplicationOptions>;
    static get defaultOptions(): FormApplicationOptions;
}
