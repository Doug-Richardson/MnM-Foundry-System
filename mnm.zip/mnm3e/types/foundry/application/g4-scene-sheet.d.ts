
declare interface SceneSheetData<TargetSceneType extends Scene<any, any, any>> extends BaseEntitySheetBaseData<TargetSceneType> {
    scene: TargetSceneType['data'];
    data: TargetSceneType['data']['data'];
}



declare interface SceneSheetOptions extends BaseEntitySheetOptions { }


declare class SceneSheet<DescribedSceneType extends Scene<any, any, any>> extends BaseEntitySheet<DescribedSceneType> {

    scene: DescribedSceneType;

    protected _onDragStart(ev: DragEvent): void;

    options: DeepPartial<SceneSheetOptions>;
    get defaultOptions(): SceneSheetOptions;

    getData(): SceneSheetData<DescribedSceneType> | Promise<SceneSheetData<DescribedSceneType>>;
}



