
// TODO: I'm pretty sure we can't just combine these because of circular references?
declare interface BaseEntitySheetBaseData<TargetEntityType extends Entity<any,  any>> extends FormApplicationData<TargetEntityType> {
    entity: TargetEntityType['data'];
    data: TargetEntityType['data']['data'];
    owner: boolean;
    limited: boolean;
    editable: boolean;
    cssClass: 'editable' | 'locked';
}

// No new properties are introduced, but we name these interfaces anyway for consistency
declare interface BaseEntitySheetOptions extends FormApplicationOptions { }


declare abstract class BaseEntitySheet<DescribedEntityType extends Entity<EntityBaseData, any>> extends FormApplication<DescribedEntityType> {

    /**
     * Handles the FormData's _updateObject function.  This sets the formData's _id field and then calls the FormApplication's object's update method.
     */
    _updateObject(event: Event, formData: FormData): Promise<void>;

    /**
     * A convenience accessor for the object property, which in the case of a BaseEntitySheet is an Entity instance.
     * Note that this is different from the "entity" property on Entities, which is a string and generally unrelated.
     */
    readonly object: DescribedEntityType;
    readonly entity: this['object'];

    abstract getData(options?: BaseEntitySheetOptions): BaseEntitySheetBaseData<DescribedEntityType> | Promise<BaseEntitySheetBaseData<DescribedEntityType>>;

    options: DeepPartial<BaseEntitySheetOptions>;
    static get defaultOptions(): BaseEntitySheetOptions;
}

