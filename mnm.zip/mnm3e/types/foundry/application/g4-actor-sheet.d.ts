
declare interface ActorSheetData<TargetActorType extends Actor> extends BaseEntitySheetBaseData<TargetActorType> {
    actor: TargetActorType['data'];
    items: Array<Item>;
}


declare interface ActorSheetOptions extends BaseEntitySheetOptions { 
    resizable: boolean,
    baseApplication: "ActorSheet",
    dragDrop?: { dragSelector: string, dropSelector: null | unknown }[]
}

declare class ActorSheet<DescribedActorType extends Actor = Actor> extends BaseEntitySheet<DescribedActorType> {
    
    readonly object: DescribedActorType;
    readonly actor: this['object'];
    readonly token: DescribedActorType['token'];
    getData(options?: ActorSheetOptions): ActorSheetData<DescribedActorType> | Promise<ActorSheetData<DescribedActorType>>;

    options: DeepPartial<ActorSheetOptions>;
    static defaultOptions: ActorSheetOptions;
}


