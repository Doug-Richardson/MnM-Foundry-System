interface ApplicationOptions {

	/** A custom CSS id to use in the rendered HTML, if you don't want to use the default (based off of the Application's appId). */
	id: string;

	/** A named "base application" which generates an additional hook */
	baseApplication: string;

	/** The default pixel width for the rendered HTML */
	width: number | string;

	/** The default pixel height for the rendered HTML */
	height: number | string;

	/** The default offset-top position for the rendered HTML */
	top: number;

	/** The default offset-left position for the rendered HTML */
	left: number;

	/** Whether to display the application as a pop-out container */
	popOut: boolean;

	/** Whether the rendered application can be minimized (popOut only) */
	minimizable: boolean;

	/** Whether the rendered application can be drag-resized (popOut only) */
	resizable: boolean;

	/** An array of CSS string classes to apply to the rendered HTML */
	classes: string[];

	/** Track Tab navigation handlers which are active for this Application */
	//tabs?: TabV2Options[];
	/** A default window title string (popOut only) */
	title: string;

	/** The default HTML template path to render for this Application */
	template: string;

	/**
	 * A list of unique CSS selectors which target containers that should
	 * have their vertical scroll positions preserved during a re-render.
	 */
	scrollY: string[];

	// TODO: Are these editable?
	insertKeys: true;
	insertValues: true;
	overwrite: true;
	inplace: false;
}


interface ApplicationRenderOptions<AppDataType> extends ApplicationPosition {

	/** Whether to display a log message that the Application was rendered */
	log: boolean;

	/** A context-providing string which suggests what event triggered the render */
	renderContext: string;

	/** The data change which motivated the render request */
	renderData: AppDataType;
}

interface ApplicationPosition {
	width: number;
	height: number;
	left: number;
	top: number;
	scale: number;
}

/**
 * The standard application window that is rendered for a large variety of UI elements in Foundry VTT
 */
declare abstract class Application {


	/**
	 * This is the data that gets passed to the Handlebars-rendered template.
	 * 
	 * An application should define the data object used to render its template.
	 * This function may either return an Object directly, or a Promise which resolves to an Object
	 * If undefined, the default implementation will return an empty object allowing only for rendering of static HTML
	 *
	 * @return {Object|Promise}
	 */
	abstract getData(options?: ApplicationOptions): {} | Promise<{}>;

	readonly appId: number;
	readonly position: ApplicationPosition;

	options: DeepPartial<ApplicationOptions>;
	static get defaultOptions(): ApplicationOptions;


	/**
	 * The CSS application ID which uniquely references this UI element.
	 * This can be overridden by options.id, but otherwise it will be based on this.appId.
	 */
	readonly id: string;


	/**
	 * Return the active application element, if it currently exists in the DOM
	 */
	get element(): JQuery<HTMLElement>;

	// Resolves to the template passed options or defaultOptions
	get template(): string;


	/**
	 * Controls the rendering style of the application. 
	 * If true, the application is rendered in its own wrapper window, 
	 * otherwise only the inner app content is rendered.
	 * 
	 * TODO: I think this means it controls whether a new browser window is opened for the application as opposed to a render in the same canvas
	 */
	popOut: boolean;

	/**
	 * Whether the Application instance is currently rendered
	 * 
	 * TODO: Does this return false when the application is closing?
	 */
	get rendered(): boolean;


	/* -------------------------------------------- */

	/**
	 * TODO: This is pop-out only? Only on the options object?
	 */
	get title(): string;


	/**
	 * Render the Application by evaluating its HTML template against the object of data provided by the getData method
	 * If the Application is rendered as a pop-out window, it also wraps the contained HTML in an outer frame with window controls
	 *
	 * @param {Boolean} force   Add the rendered application to the DOM if it is not already present. 
	 * 							If false, (the default), Application will only be re-rendered if it is already present.
	 *
	 */
	render(force?: boolean, options?: ApplicationRenderOptions<unknown>): this;



	/**
	 * This function is called just after the application is rendered in order to add event handlers to the newly added content.
	 * Subclasses should override this to provide increasingly more sophisticated event handler logic to the Application's content.
	 * TODO:  Is there a cleanup function opposite of activateListeners?
	 * 
	 * By default, this function handles TabsV2 and Drag and Drop handlers. 
	 */
	activateListeners(html: JQuery<HTMLElement>): void;



	/**
	 * Close the application and un-register references to it within UI mappings
	 * This function returns a Promise which resolves once the window closing animation concludes
	 * 
	 * TODO: Does this clean up event handlers?
	 */
	close(): Promise<this>;


	/**
	 * Minimize the pop-out window, collapsing it to a small tab
	 * Take no action for applications which are not of the pop-out variety or apps which are already minimized
	 * This function returns a Promise which resolves once the window minimizing animation concludes
	 */
	minimize(): Promise<void>;


	/**
	 * Maximize the pop-out window, expanding it to its original size
	 * Take no action for applications which are not of the pop-out variety or are already maximized
	 * This function returns a Promise which resolves once the window maximizing animation concludes
	 */
	maximize(): Promise<void>;


	/**
	 * Set the application position and store its new location.
	 *
	 * @param {number|null} left            The left offset position in pixels
	 * @param {number|null} top             The top offset position in pixels
	 * @param {number|null} width           The application width in pixels
	 * @param {number|string|null} height   The application height in pixels
	 * @param {number|null} scale           The application scale as a numeric factor where 1.0 is default
	 *
	 * @returns {{left: number, top: number, width: number, height: number, scale:number}}
	 * The updated position object for the application containing the new values
	 */
	setPosition(newPosition?: ApplicationPosition): Required<ApplicationPosition>;
}
