
    /**
     * Customize behaviors of this PlaceablesLayer by modifying some behaviors at a class level
     * @static
     * @type {Object}
     *
     * @property {boolean} canDragCreate        Does this layer support a mouse-drag workflow to create new objects?
     * @property {boolean} controllableObjects  Can placeable objects in this layer be controlled?
     * @property {boolean} rotatableObjects     Can placeable objects in this layer be rotated?
     * @property {boolean} snapToGrid           Do objects in this layer snap to the grid
     * @property {number} gridPrecision         At what numeric grid precision do objects snap?
     */
interface PlaceablesLayerOptions {
    canDragCreate: boolean,
    canDelete: boolean,
    controllableObjects: boolean,
    rotatableObjects: boolean,
    snapToGrid: boolean,
    gridPrecision: null,
    objectClass: null | unknown,
    sheetClass: null| unknown
  }

declare class PlaceablesLayer extends CanvasLayer {

    get objects(): PIXI.Container | null;
    get preview(): null | unknown;
    get history(): unknown[];
    get options(): PlaceablesLayerOptions;

    constructor();
  
    /* -------------------------------------------- */
    /*  Properties                                  */
    /* -------------------------------------------- */
  
    static get layerOptions(): PlaceablesLayerOptions;
    
  
    /* -------------------------------------------- */
  
    /**
     * Return a reference to the active instance of this canvas layer
     */
    static get instance(): PlaceablesLayer
  
    /* -------------------------------------------- */
  
    /**
     * Define the named Array within Scene.data containing the placeable objects displayed in this layer
     * @static
     * @type {String}
     */
    static get dataArray(): unknown[];
  
    /* -------------------------------------------- */
  
    /**
     * Define a Container implementation used to render placeable objects contained in this layer
     * @static
     * @type {PIXI.Container}
     */
    static get placeableClass(): PlaceablesLayerOptions['objectClass'];
  
    /* -------------------------------------------- */
  
    /**
     * Return the precision relative to the Scene grid with which Placeable objects should be snapped
     * @return {number}
     */
    get gridPrecision(): PlaceablesLayerOptions['gridPrecision'];
  
    /* -------------------------------------------- */
  
    /**
     * If objects on this PlaceableLayer have a HUD UI, provide a reference to its instance
     * @type {BasePlaceableHUD|null}
     */
    get hud(): unknown | null;
  
    /* -------------------------------------------- */
  
    /**
     * A convenience method for accessing the placeable object instances contained in this layer
     * @type {Array}
     */
    get placeables(): PIXI.DisplayObject[];
  
    /* -------------------------------------------- */
  
    /**
     * An Array of placeable objects in this layer which have the _controlled attribute
     * @return {Array.<PlaceableObject>}
     */
    get controlled(): boolean;
    createObject(data: unknown): unknown;
  
    /* -------------------------------------------- */
    /*  Methods                                     */
    /* -------------------------------------------- */
  
  
    /**
     * Get a PlaceableObject contained in this layer by it's ID
     * @param {string} objectId   The ID of the contained object to retrieve
     * @return {PlaceableObject}  The object instance, or undefined
     */
    get(objectId: string): PlaceableObject<PlaceableObjectBaseData, Scene>;
  
    /* -------------------------------------------- */
  
    /**
     * Release all controlled PlaceableObject instance from this layer.
     * @return {Number}           The number of PlaceableObject instances which were released
     */
    releaseAll(): number;
  
    /* -------------------------------------------- */
  
    /**
     * Simultaneously rotate multiple PlaceableObjects using a provided angle or incremental.
     * This executes a single database operation using Scene.update.
     * If rotating only a single object, it is better to use the PlaceableObject.rotate instance method.
  
     * @param {Number} angle      A target angle of rotation (in degrees) where zero faces "south"
     * @param {Number} delta      An incremental angle of rotation (in degrees)
     * @param {Number} snap       Snap the resulting angle to a multiple of some increment (in degrees)      
     * @param {Array|Set} ids     An Array or Set of object IDs to target for rotation
  
     * @return {Promise}          The resulting Promise from the Scene.update operation
     */
    rotateMany(options?: {angle?: number | null, delta?: number | null, snap?: number | null, ids?: number | null}): Promise<unknown>;
  
    /* -------------------------------------------- */
  
    /**
     * Simultaneously move multiple PlaceableObjects via keyboard movement offsets.
     * This executes a single database operation using Scene.update.
     * If moving only a single object, this will delegate to PlaceableObject.update for performance reasons.
     * 
     * @param {Number} dx         The number of incremental grid units in the horizontal direction
     * @param {Number} dy         The number of incremental grid units in the vertical direction
     * @param {Boolean} rotate    Rotate the token to the keyboard direction instead of moving
     * @param {Array|Set} ids     An Array or Set of object IDs to target for rotation
     *
     * @return {Promise}          The resulting Promise from the Scene.update operation
     */
    moveMany(options?: {dx?: number, dy?: number, rotate?: boolean, ids?: Iterable<string> | ArrayLike<string>}): Promise<void>;
  
    /* -------------------------------------------- */
  
    /**
     * Undo a change to the objects in this layer
     * This method is typically activated using CTRL+Z while the layer is active
     * @return {Promise}
     */
    undoHistory(): Promise<unknown>;
  
    /* -------------------------------------------- */
  
    /**
     * Create multiple embedded entities in a parent Entity collection using an Array of provided data
     *
     * @param {Array} data          An Array of update data Objects which provide incremental data
     * @param {Object} options      Additional options which customize the update workflow
     *
     * @return {Promise}            A Promise which resolves to the returned socket response (if successful)
     */
    createMany<EntityType extends Entity<any, any>>(data: Array<DeepPartial<EntityType['data']>>, options?: EntityCreateOptions): Promise<EntityType[]>;
  
    /* -------------------------------------------- */
  
    /**
     * Update multiple embedded entities in a parent Entity collection using an Array of provided data
     *
     * @param {Array} data          An Array of update data Objects which provide incremental data
     * @param {Object} options      Additional options which customize the update workflow
     *
     * @return {Promise}            A Promise which resolves to the returned socket response (if successful)
     */
    updateMany<EntityType extends Entity<any, any>>(data: Array<DeepPartial<EntityType['data']>>, options?: EntityUpdateOptions): Promise<EntityType[]>;
  
    /* -------------------------------------------- */
  
    /**
     * Simultaneously delete multiple PlaceableObjects.
     * This executes a single database operation using Scene.update.
     * If deleting only a single object, this will delegate to PlaceableObject.delete for performance reasons.
     *
     * @param {Array} ids           An Array of object IDs to target for deletion
     * @param {Object} options      Additional options which customize the update workflow
     *
     * @return {Promise}            A Promise which resolves to the returned socket response (if successful)
     */
    deleteMany<EntityType extends Entity<any, any>>(ids: Array<string>, options?: EntityDeleteOptions): Promise<EntityType[]>;
  
    /* -------------------------------------------- */
  
  }
