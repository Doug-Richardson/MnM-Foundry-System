
declare interface PlaceableObjectBaseData {
    _id: string;
}

declare class PlaceableObject<BaseDataType extends PlaceableObjectBaseData, SceneType extends Scene<any, any, any>> extends PIXI.Container {
    constructor(data: BaseDataType, scene: SceneType);

    vision: { fov: null | unknown, los: null | unknown };
    get id(): BaseDataType['_id'];
    get fov(): this['vision']['fov'];
    get los(): this['vision']['los'];
    controlIcon: null | unknown;
    mouseInteractionManager: null | unknown;

    get center(): PIXI.Point;

    get embeddedName(): string;

    static get layer(): PlaceablesLayer;
    get layer(): PlaceablesLayer;
    
    /*data: Data1Type;
    scene: Scene<unknown>;
    vision: { fov: null | unknown, los: null | unknown };
    

    get id: Data1Type['_id'];
    get fov: this['vision']['fov'];
    get los: this['vision']['los'];
    //get embeddedName: never;

    get layer: unknown;

    get sheet: SheetClass;
    get uuid: string;*/

}

