declare class CanvasLayer extends PIXI.Container {
    constructor();
  
    readonly name: string;
  
    
    /**
     * Deconstruct data used in the current layer in preparation to re-draw the canvas
     */
    tearDown(): void;
  
    
    /**
     * Draw the canvas layer, rendering its internal components and returning a Promise
     * The Promise resolves to the drawn layer once its contents are successfully rendered.
     * @return {Promise.<CanvasLayer>}
     */
    draw(): Promise<this>;
    activate(): void
    deactivate(): void
  }