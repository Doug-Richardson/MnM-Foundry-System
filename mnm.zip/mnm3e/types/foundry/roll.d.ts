
interface ToMessageData {

}

interface RollJson { 
    class: string, 
    formula: string, 
    dice: unknown, 
    parts: unknown[], 
    result: string, 
    total: number 
}

/**
 * This class provides an interface and API for conducting dice rolls.
 * The basic structure for a dice roll is a string formula and an object of data against which to parse it.
 *
 * @param formula {String}    The string formula to parse
 * @param data {Object}       The data object against which to parse attributes within the formula
 *
 * @see {@link Die}
 * @see {@link DicePool}
 *
 * @example
 * // Attack with advantage!
 * let r = new Roll("2d20kh + @prof + @strMod", {prof: 2, strMod: 4});
 *
 * // The parsed components of the roll formula
 * console.log(r.parts);    // [Die, +, 2, +, 4]
 * 
 * // Execute the roll
 * r.roll();
 *
 * // The resulting equation after it was rolled
 * console.log(r.result);   // 16 + 2 + 4
 *
 * // The total resulting from the roll
 * console.log(r.total);    // 22
 */
declare class Roll<OriginalData> {
    constructor(formula: string, data?: OriginalData);

    data: OriginalData;
    formula: string;        // The given formula, but with the @attr values replaced
    parts: unknown[];
    rgx: {
        dice: RegExp,
        pool: RegExp,
        reroll: RegExp,
        explode: RegExp,
        keep: RegExp,
        success: RegExp,
        parenthetical: RegExp
    };

    get result(): string;
    get total(): number;
    get dice(): Array<unknown>;

    static get diceRgx(): RegExp;

    static get rgx(): {
        dice: string,
        pool: string
    }


    /**
     * Record supported arithmetic operators for Roll instances
     * @private
     * @type {Array.<String>}
     */
    static get arithmeticOperators(): ["+", "-", "*", "/"];


    roll(): this;

    /**
     * Create a new Roll object using the original provided formula and data
     * Each roll is immutable, so this method returns a new Roll instance using the same data.
     * @returns {Roll}    A new Roll object, rolled using the same formula and data
     */
    reroll(): this;

    /**
     * Render a Roll instance to HTML
     * @param chatOptions {Object}      An object configuring the behavior of the resulting chat message.
     * @return {Promise.<HTMLElement>}  A Promise which resolves to the rendered HTML
     */
    render(chatOptions?: DeepPartial<ChatMessageData1<any>>): Promise<HTMLElement>;


    /**
     * Render the tooltip HTML for a Roll instance
     * TODO: Something about returning a rendered CONFIG.Dice.tooltip template.
     * @return {Promise.<HTMLElement>}
     */
    getTooltip(): Promise<HTMLElement>;


    /**
     * Transform a Roll instance into a ChatMessage, displaying the roll result.
     * This function can either create the ChatMessage directly, or return the data object that will be used to create.
     *
     * @param {Object} messageData          The data object to use when creating the message
     * @param {string|null} [rollMode=null] The template roll mode to use for the message from CONFIG.Dice.rollModes
     * @param {boolean} [create=true]       Whether to automatically create the chat message, or only return the prepared
     *                                      chatData object.
     * @return {Promise|Object}             A promise which resolves to the created ChatMessage entity, if create is true
     *                                      or the Object of prepared chatData otherwise.
     */
    toMessage<M extends ToMessageData>(messageData?: M): Promise<ChatMessage>;
    toMessage<M extends ToMessageData>(messageData?: M, options?: { rollMode?: string | null }): Promise<ChatMessage>;
    toMessage<M extends ToMessageData>(messageData?: M, options?: { rollMode?: string | null, create: true }): Promise<ChatMessage>;
    toMessage<M extends ToMessageData>(messageData?: M, options?: { rollMode?: string | null, create?: false }): ChatMessage;




    /**
     * Alter the Roll formula by adding or multiplying the number of dice included in each roll term
     *
     * @param add {Number}      A number of dice to add to each Die term
     * @param multiply {Number} A multiplier for the number of dice in each Die term
     *
     * @example
     * let r = new Roll("4d8 + 4 + 2d4");
     * r.alter(1, 2);
     * r.formula;
     * > 9d8 + 4 + 5d4
     */
    alter(add?: number, multiply?: number): this;


    /**
     * Clean a dice roll formula, returning the formatted string with proper spacing
     * @param formula
     * @return {*}
     */
    static cleanFormula(formula: string): string;




    /**
     * Return the minimum possible Dice roll which can result from the given formula
     * @param {string} formula      A dice roll formula to minimize
     * @return {Roll}               A Roll instance representing the minimal roll
     */
    static minimize(formula: string): Roll<never>;

    /* -------------------------------------------- */

    /**
     * Return the maximum possible Dice roll which can result from the given formula
     * @param {string} formula      A dice roll formula to maximize
     * @return {Roll}               A Roll instance representing the maximal roll
     */
    static maximize(formula: string): Roll<never>;

    /* -------------------------------------------- */

    // TODO: Returns the total of formula run n times, I think
    static simulate(formula: string, n: number): number;

    /* -------------------------------------------- */
    /*  Saving and Loading
    /* -------------------------------------------- */

    /**
     * Structure the Roll data as an object suitable for JSON stringification
     * @return {Object}     Structured data which can be serialized into JSON
     */
    toJSON(): RollJson;

    /* -------------------------------------------- */


    /**
     * Recreate a Roll instance using a provided JSON string
     * @param {string} json   Serialized JSON data representing the Roll
     * @return {Roll}         A revived Roll instance
     */
    static fromJSON<RollType extends Roll<any> = Roll<unknown>>(json: string): RollType;

    /* -------------------------------------------- */

    /**
     * Recreate a Roll instance using a provided JSON string
     * @param {Object} data   Unpacked data representing the Roll
     * @return {Roll}         A revived Roll instance
     */
    static fromData<RollType extends Roll<any> = Roll<unknown>>(data: { class: string, formula: string, dice: unknown, parts: unknown[], result: string, total: number }): RollType;
}
