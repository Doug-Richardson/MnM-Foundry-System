
declare const vtt = "Foundry VTT";
declare const VTT = "Foundry Virtual Tabletop";
declare const WEBSITE_URL = "https://foundryvtt.com";

/**
 * Define the string name used for the base entity type when specific sub-types are not defined by the system
 * @type {String}
 */
declare const BASE_ENTITY_TYPE = "base";

/**
 * Valid Chat Message types
 * @type {Object}
 */
declare const CHAT_MESSAGE_TYPES: {
    OTHER: 0,
    OOC: 1,
    IC: 2,
    EMOTE: 3,
    WHISPER: 4,
    ROLL: 5
};


/**
 * The allowed Entity types which may exist within a Compendium pack
 * This is a subset of ENTITY_TYPES
 * @type {Array}
 */
declare const COMPENDIUM_ENTITY_TYPES: ["Actor", "Item", "Scene", "JournalEntry", "Macro", "RollTable", "Playlist"];
type CompendiumEntityTypes = (typeof COMPENDIUM_ENTITY_TYPES)[number];

/**
 * Define the set of languages which have built-in support in the core software
 * @type {string[]}
 */
declare const CORE_SUPPORTED_LANGUAGES: ["en"];
type CoreSupporetedLanguages = (typeof CORE_SUPPORTED_LANGUAGES)[number];

/**
 * The default artwork used for Token images if none is provided
 * @type {String}
 */
declare const DEFAULT_TOKEN: 'icons/svg/mystery-man.svg';

/**
 * The default artwork used for Note placeables if none is provided
 * @type {String}
 */
declare const DEFAULT_NOTE_ICON: 'icons/svg/book.svg';

/**
 * The supported dice roll visibility modes
 * @type {Object}
 */
declare const DICE_ROLL_MODES: {
    PUBLIC: "roll",
    PRIVATE: "gmroll",
    BLIND: "blindroll",
    SELF: "selfroll"
};


/* -------------------------------------------- */


/**
 * The allowed Drawing types which may be saved
 * @type {Object}
 */
declare const DRAWING_TYPES: {
    RECTANGLE: "r",
    ELLIPSE: "e",
    TEXT: "t",
    POLYGON: "p",
    FREEHAND: "f"
};

/**
 * The allowed fill types which a Drawing object may display
 * NONE: The drawing is not filled
 * SOLID: The drawing is filled with a solid color
 * PATTERN: The drawing is filled with a tiled image pattern
 * @type {Object}
 */
declare const DRAWING_FILL_TYPES: {
    NONE: 0,
    SOLID: 1,
    PATTERN: 2
};
type DrawingFillType = (keyof typeof DRAWING_FILL_TYPES) | ((typeof DRAWING_FILL_TYPES)[keyof typeof DRAWING_FILL_TYPES]);


/**
 * The default configuration values used for Drawing objects
 * @type {Object}
 */
declare const DRAWING_DEFAULT_VALUES: {
    width: 0,
    height: 0,
    rotation: 0,
    z: 0,
    hidden: false,
    locked: false,
    fillType: (typeof DRAWING_FILL_TYPES)['NONE'],
    fillAlpha: 0.5,
    bezierFactor: 0.0,
    strokeAlpha: 1.0,
    strokeWidth: 8,
    fontSize: 48,
    textAlpha: 1.0,
    textColor: "#FFFFFF"
};

/* -------------------------------------------- */

/**
 * Define the allowed Entity class types
 * @type {Array}
 */
declare const ENTITY_TYPES: [
    "Actor",
    "ChatMessage",
    "Combat",
    "Item",
    "Folder",
    "JournalEntry",
    "Macro",
    "Playlist",
    "RollTable",
    "Scene",
    "User",
];
type EntityTypes = (typeof ENTITY_TYPES)[number];

/**
 * Define the allowed Entity types which may be dynamically linked in chat
 * @type {Array}
 */
declare const ENTITY_LINK_TYPES: ["Actor", "Item", "Scene", "JournalEntry", "Macro", "RollTable"];
type EntityLinkTypes = (typeof ENTITY_LINK_TYPES)[number];
type EntityUnlinkableTypes = Exclude<EntityTypes, EntityLinkTypes>;

/**
 * Define the allowed permission levels for a non-user Entity.
 * Each level is assigned a value in ascending order. Higher levels grant more permissions.
 * @type {Object}
 */
declare const ENTITY_PERMISSIONS: {
    "NONE": 0,
    "LIMITED": 1,
    "OBSERVER": 2,
    "OWNER": 3
};
type EntityPermission = (keyof typeof ENTITY_PERMISSIONS) | ((typeof ENTITY_PERMISSIONS)[keyof typeof ENTITY_PERMISSIONS]);

/**
 * EULA version number
 * @type {String}
 */
declare const EULA_VERSION = "0.6.1";

/**
 * Define the allowed Entity types which Folders may contain
 * @type {Array}
 */
declare const FOLDER_ENTITY_TYPES: ["Actor", "Item", "Scene", "JournalEntry", "RollTable"];
type FolderEntityTypes = (typeof FOLDER_ENTITY_TYPES)[number];

/**
 * The maximum allowed level of depth for Folder nesting
 * @type {Number}
 */
declare const FOLDER_MAX_DEPTH = 3;

/**
 * The minimum allowed grid size which is supported by the software
 * @type {Number}
 */
declare const GRID_MIN_SIZE = 50;

/**
 * The allowed Grid types which are supported by the software
 * @type {Object}
 */
declare const GRID_TYPES: {
    "GRIDLESS": 0,
    "SQUARE": 1,
    "HEXODDR": 2,
    "HEXEVENR": 3,
    "HEXODDQ": 4,
    "HEXEVENQ": 5
};
type GridType = (keyof typeof GRID_TYPES) | ((typeof GRID_TYPES)[keyof typeof GRID_TYPES]);

/**
 * An Array of valid MacroAction scope values
 * @type {Array.<string>}
 */
declare const MACRO_SCOPES: ["global", "actors", "actor"];
type MacroScope = (typeof MACRO_SCOPES)[number];


/**
 * The allowed playback modes for an audio Playlist
 * DISABLED: The playlist does not play on its own, only individual Sound tracks played as a soundboard
 * SEQUENTIAL: The playlist plays sounds one at a time in sequence
 * SHUFFLE: The playlist plays sounds one at a time in randomized order
 * SIMULTANEOUS: The playlist plays all contained sounds at the same time
 * @type {Object}
 */
declare const PLAYLIST_MODES: {
    "DISABLED": -1,
    "SEQUENTIAL": 0,
    "SHUFFLE": 1,
    "SIMULTANEOUS": 2
};
type PlaylistMode = (keyof typeof PLAYLIST_MODES) | ((typeof PLAYLIST_MODES)[keyof typeof PLAYLIST_MODES]);


/**
 * Encode the reasons why a package may be available or unavailable for use
 * @type {Object}
 */
declare const PACKAGE_AVAILABILITY_CODES: {
    "UNKNOWN": -1,
    "AVAILABLE": 0,
    "REQUIRES_UPDATE": 1,
    "REQUIRES_SYSTEM": 2,
    "REQUIRES_DEPENDENCY": 3,
    "REQUIRES_CORE": 4
};
type PackageAvailabilityCode = (keyof typeof PACKAGE_AVAILABILITY_CODES) | ((typeof PACKAGE_AVAILABILITY_CODES)[keyof typeof PACKAGE_AVAILABILITY_CODES]);

/**
 * A safe password string which can be displayed
 */
declare const PASSWORD_SAFE_STRING = "••••••••••••••••"


/**
 * The allowed software update channels
 * @type {Object}
 */
declare const SOFTWARE_UPDATE_CHANNELS: {
    "alpha": "SETUP.UpdateAlpha",
    "beta": "SETUP.UpdateBeta",
    "release": "SETUP.UpdateRelease"
};
type SoftwareUpdateChannel = (keyof typeof SOFTWARE_UPDATE_CHANNELS) | ((typeof SOFTWARE_UPDATE_CHANNELS)[keyof typeof SOFTWARE_UPDATE_CHANNELS]);


/**
 * The default sorting density for manually ordering child objects within a parent
 * @type {Number}
 */
declare const SORT_INTEGER_DENSITY = 100000;

/**
 * The allowed types of a TableResult document
 * @type {Object}
 */
declare const TABLE_RESULT_TYPES: {
    TEXT: 0,
    ENTITY: 1,
    COMPENDIUM: 2
};
type TableResultType = (keyof typeof TABLE_RESULT_TYPES) | ((typeof TABLE_RESULT_TYPES)[keyof typeof TABLE_RESULT_TYPES]);

/**
 * Define the valid anchor locations for a Tooltip displayed on a Placeable Object
 * @type {Object}
 */
declare const TEXT_ANCHOR_POINTS: {
    CENTER: 0,
    BOTTOM: 1,
    TOP: 2,
    LEFT: 3,
    RIGHT: 4
};
type TextAnchorPoint = (keyof typeof TEXT_ANCHOR_POINTS) | ((typeof TEXT_ANCHOR_POINTS)[keyof typeof TEXT_ANCHOR_POINTS]);

/**
 * Describe the various thresholds of token control upon which to show certain pieces of information
 * NONE - no information is displayed
 * CONTROL - displayed when the token is controlled
 * OWNER HOVER - displayed when hovered by a GM or a user who owns the actor
 * HOVER - displayed when hovered by any user
 * OWNER - always displayed for a GM or for a user who owns the actor
 * ALWAYS - always displayed for everyone
 * @type {Object}
 */
declare const TOKEN_DISPLAY_MODES: {
    "NONE": 0,
    "CONTROL": 10,
    "OWNER_HOVER": 20,
    "HOVER": 30,
    "OWNER": 40,
    "ALWAYS": 50
};
type TokenDisplayMode = (keyof typeof TOKEN_DISPLAY_MODES) | ((typeof TOKEN_DISPLAY_MODES)[keyof typeof TOKEN_DISPLAY_MODES]);

/**
 * The allowed Token disposition types
 * HOSTILE - Displayed as an enemy with a red border
 * NEUTRAL - Displayed as neutral with a yellow border
 * FRIENDLY - Displayed as an ally with a cyan border
 */
declare const TOKEN_DISPOSITIONS: {
    "HOSTILE": -1,
    "NEUTRAL": 0,
    "FRIENDLY": 1
};
type TokenDisposition = (keyof typeof TOKEN_DISPOSITIONS) | ((typeof TOKEN_DISPOSITIONS)[keyof typeof TOKEN_DISPOSITIONS]);

/**
 * Define the allowed User permission levels.
 * Each level is assigned a value in ascending order. Higher levels grant more permissions.
 * @type {Object}
 */
declare const USER_ROLES: {
    "NONE": 0,
    "PLAYER": 1,
    "TRUSTED": 2,
    "ASSISTANT": 3,
    "GAMEMASTER": 4
};
type UserRole = (keyof typeof USER_ROLES) | ((typeof USER_ROLES)[keyof typeof USER_ROLES]);

/**
 * Invert the User Role mapping to recover role names from a role integer
 * @type {Object}
 */
declare const USER_ROLE_NAMES: {
    0: "NONE",
    1: "PLAYER",
    2: "TRUSTED",
    3: "ASSISTANT",
    4: "GAMEMASTER"
};


/**
 * Define the named actions which users or user roles can be permitted to do.
 * Each key of this Object denotes an action for which permission may be granted (true) or withheld (false)
 * @type {Object}
 */
declare const USER_PERMISSIONS: {
    "BROADCAST_AUDIO": {
        label: "PERMISSION.BroadcastAudio",
        hint: "PERMISSION.BroadcastAudioHint",
        disableGM: true,
        defaultRole: (typeof USER_ROLES)['TRUSTED']
    },
    "BROADCAST_VIDEO": {
        label: "PERMISSION.BroadcastVideo",
        hint: "PERMISSION.BroadcastVideoHint",
        disableGM: true,
        defaultRole: (typeof USER_ROLES)['TRUSTED']
    },
    "ACTOR_CREATE": {
        label: "PERMISSION.ActorCreate",
        hint: "PERMISSION.ActorCreateHint",
        disableGM: false,
        defaultRole: (typeof USER_ROLES)['ASSISTANT']
    },
    "DRAWING_CREATE": {
        label: "PERMISSION.DrawingCreate",
        hint: "PERMISSION.DrawingCreateHint",
        disableGM: false,
        defaultRole: (typeof USER_ROLES)['TRUSTED']
    },
    "ITEM_CREATE": {
        label: "PERMISSION.ItemCreate",
        hint: "PERMISSION.ItemCreateHint",
        disableGM: false,
        defaultRole: (typeof USER_ROLES)['ASSISTANT']
    },
    "FILES_BROWSE": {
        label: "PERMISSION.FilesBrowse",
        hint: "PERMISSION.FilesBrowseHint",
        disableGM: false,
        defaultRole: (typeof USER_ROLES)['TRUSTED']
    },
    "FILES_UPLOAD": {
        label: "PERMISSION.FilesUpload",
        hint: "PERMISSION.FilesUploadHint",
        disableGM: false,
        defaultRole: (typeof USER_ROLES)['ASSISTANT']
    },
    "JOURNAL_CREATE": {
        label: "PERMISSION.JournalCreate",
        hint: "PERMISSION.JournalCreateHint",
        disableGM: false,
        defaultRole: (typeof USER_ROLES)['TRUSTED']
    },
    "MACRO_SCRIPT": {
        label: "PERMISSION.MacroScript",
        hint: "PERMISSION.MacroScriptHint",
        disableGM: false,
        defaultRole: (typeof USER_ROLES)['PLAYER']
    },
    "MESSAGE_WHISPER": {
        label: "PERMISSION.MessageWhisper",
        hint: "PERMISSION.MessageWhisperHint",
        disableGM: false,
        defaultRole: (typeof USER_ROLES)['PLAYER']
    },
    "SETTINGS_MODIFY": {
        label: "PERMISSION.SettingsModify",
        hint: "PERMISSION.SettingsModifyHint",
        disableGM: false,
        defaultRole: (typeof USER_ROLES)['ASSISTANT']
    },
    "SHOW_CURSOR": {
        label: "PERMISSION.ShowCursor",
        hint: "PERMISSION.ShowCursorHint",
        disableGM: true,
        defaultRole: (typeof USER_ROLES)['PLAYER']
    },
    "SHOW_RULER": {
        label: "PERMISSION.ShowRuler",
        hint: "PERMISSION.ShowRulerHint",
        disableGM: true,
        defaultRole: (typeof USER_ROLES)['PLAYER']
    },
    "TEMPLATE_CREATE": {
        label: "PERMISSION.TemplateCreate",
        hint: "PERMISSION.TemplateCreateHint",
        disableGM: false,
        defaultRole: (typeof USER_ROLES)['PLAYER']
    },
    "TOKEN_CREATE": {
        label: "PERMISSION.TokenCreate",
        hint: "PERMISSION.TokenCreateHint",
        disableGM: false,
        defaultRole: (typeof USER_ROLES)['ASSISTANT']
    },
    "TOKEN_CONFIGURE": {
        label: "PERMISSION.TokenConfigure",
        hint: "PERMISSION.TokenConfigureHint",
        disableGM: false,
        defaultRole: (typeof USER_ROLES)['TRUSTED']
    },
    "WALL_DOORS": {
        label: "PERMISSION.WallDoors",
        hint: "PERMISSION.WallDoorsHint",
        disableGM: false,
        defaultRole: (typeof USER_ROLES)['PLAYER']
    }
};

type UserPermission = keyof typeof USER_PERMISSIONS;

/**
 * The allowed directions of effect that a Wall can have
 * BOTH: The wall collides from both directions
 * LEFT: The wall collides only when a ray strikes its left side
 * RIGHT: The wall collides only when a ray strikes its right side
 * @type {Object}
 */
declare const WALL_DIRECTIONS: {
    BOTH: 0,
    LEFT: 1,
    RIGHT: 2
};
type WallDirection = (keyof typeof WALL_DIRECTIONS) | ((typeof WALL_DIRECTIONS)[keyof typeof WALL_DIRECTIONS]);

/**
 * The allowed door types which a Wall may contain
 * NONE: The wall does not contain a door
 * DOOR: The wall contains a regular door
 * SECRET: The wall contains a secret door
 * @type {Object}
 */
declare const WALL_DOOR_TYPES: {
    NONE: 0,
    DOOR: 1,
    SECRET: 2
};
type WallDoorType = (keyof typeof WALL_DOOR_TYPES) | ((typeof WALL_DOOR_TYPES)[keyof typeof WALL_DOOR_TYPES]);

/**
 * The allowed door states which may describe a Wall that contains a door
 * CLOSED: The door is closed
 * OPEN: The door is open
 * LOCKED: The door is closed and locked
 * @type {Object}
 */
declare const WALL_DOOR_STATES: {
    CLOSED: 0,
    OPEN: 1,
    LOCKED: 2
};
type WallDoorState = (keyof typeof WALL_DOOR_STATES) | ((typeof WALL_DOOR_STATES)[keyof typeof WALL_DOOR_STATES]);

/**
 * The types of movement collision which a Wall may impose
 * NONE: Movement does not collide with this wall
 * NORMAL: Movement collides with this wall
 * @type {Object}
 */
declare const WALL_MOVEMENT_TYPES: {
    NONE: 0,
    NORMAL: 1
};
type WallMovementType = (keyof typeof WALL_MOVEMENT_TYPES) | ((typeof WALL_MOVEMENT_TYPES)[keyof typeof WALL_MOVEMENT_TYPES]);

/**
 * The types of sensory collision which a Wall may impose
 * NONE: Senses do not collide with this wall
 * NORMAL: Senses collide with this wall
 * LIMITED: Senses collide with the second intersection, bypassing the first
 * @type {Object}
 */
declare const WALL_SENSE_TYPES: {
    NONE: 0,
    NORMAL: 1,
    LIMITED: 2
};
type WallSenseType = (keyof typeof WALL_SENSE_TYPES) | ((typeof WALL_SENSE_TYPES)[keyof typeof WALL_SENSE_TYPES]);

/**
 * The allowed set of HTML template extensions
 * @type {string[]}
 */
declare const HTML_FILE_EXTENSIONS: ["html", "hbs"];

/**
 * The supported file extensions for image-type files
 * @type {Array}
 */
declare const IMAGE_FILE_EXTENSIONS: ["jpg", "jpeg", "png", "svg", "webp"];

/**
 * The supported file extensions for video-type files
 * @type {Array}
 */
declare const VIDEO_FILE_EXTENSIONS: ["mp4", "ogg", "webm", "m4v"];

/**
 * The supported file extensions for audio-type files
 * @type {Array}
 */
declare const AUDIO_FILE_EXTENSIONS: ["flac", "mp3", "ogg", "wav", "webm"];

declare const CONST: {
    vtt: typeof vtt,
    VTT: typeof VTT,
    WEBSITE_URL: typeof WEBSITE_URL,
    BASE_ENTITY_TYPE: typeof BASE_ENTITY_TYPE,
    CHAT_MESSAGE_TYPES: typeof CHAT_MESSAGE_TYPES,
    COMPENDIUM_ENTITY_TYPES: typeof COMPENDIUM_ENTITY_TYPES,
    CORE_SUPPORTED_LANGUAGES: typeof CORE_SUPPORTED_LANGUAGES,
    DEFAULT_TOKEN: typeof DEFAULT_TOKEN,
    DEFAULT_NOTE_ICON: typeof DEFAULT_NOTE_ICON,
    DICE_ROLL_MODES: typeof DICE_ROLL_MODES,
    DRAWING_DEFAULT_VALUES: typeof DRAWING_DEFAULT_VALUES,
    DRAWING_TYPES: typeof DRAWING_TYPES,
    DRAWING_FILL_TYPES: typeof DRAWING_FILL_TYPES,
    ENTITY_PERMISSIONS: typeof ENTITY_PERMISSIONS,
    ENTITY_TYPES: typeof ENTITY_TYPES,
    ENTITY_LINK_TYPES: typeof ENTITY_LINK_TYPES,
    EULA_VERSION: typeof EULA_VERSION,
    FOLDER_ENTITY_TYPES: typeof FOLDER_ENTITY_TYPES,
    FOLDER_MAX_DEPTH: typeof FOLDER_MAX_DEPTH,
    GRID_MIN_SIZE: typeof GRID_MIN_SIZE,
    GRID_TYPES: typeof GRID_TYPES,
    MACRO_SCOPES: typeof MACRO_SCOPES,
    PLAYLIST_MODES: typeof PLAYLIST_MODES,
    PACKAGE_AVAILABILITY_CODES: typeof PACKAGE_AVAILABILITY_CODES,
    PASSWORD_SAFE_STRING: typeof PASSWORD_SAFE_STRING,
    SOFTWARE_UPDATE_CHANNELS: typeof SOFTWARE_UPDATE_CHANNELS,
    SORT_INTEGER_DENSITY: typeof SORT_INTEGER_DENSITY,
    TABLE_RESULT_TYPES: typeof TABLE_RESULT_TYPES,
    TEXT_ANCHOR_POINTS: typeof TEXT_ANCHOR_POINTS,
    TOKEN_DISPLAY_MODES: typeof TOKEN_DISPLAY_MODES,
    TOKEN_DISPOSITIONS: typeof TOKEN_DISPOSITIONS,
    USER_PERMISSIONS: typeof USER_PERMISSIONS,
    USER_ROLES: typeof USER_ROLES,
    USER_ROLE_NAMES: typeof USER_ROLE_NAMES,
    WALL_SENSE_TYPES: typeof WALL_SENSE_TYPES,
    WALL_MOVEMENT_TYPES: typeof WALL_MOVEMENT_TYPES,
    WALL_DOOR_STATES: typeof WALL_DOOR_STATES,
    WALL_DIRECTIONS: typeof WALL_DIRECTIONS,
    WALL_DOOR_TYPES: typeof WALL_DOOR_TYPES,
    HTML_FILE_EXTENSIONS: typeof HTML_FILE_EXTENSIONS,
    IMAGE_FILE_EXTENSIONS: typeof IMAGE_FILE_EXTENSIONS,
    VIDEO_FILE_EXTENSIONS: typeof VIDEO_FILE_EXTENSIONS,
    AUDIO_FILE_EXTENSIONS: typeof AUDIO_FILE_EXTENSIONS
};
