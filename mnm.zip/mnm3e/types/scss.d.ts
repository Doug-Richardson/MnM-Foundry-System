
declare module '*.scss' {
    const scss: string;
    export default scss;
}
