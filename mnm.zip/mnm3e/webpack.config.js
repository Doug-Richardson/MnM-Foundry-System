const path = require('path');

module.exports = {
    entry: {
        main: ['./src/scripts/index.ts', './src/styles/mnm.scss'],
    },
    module: {
        rules: [
            {
                test: /\.tsx?$/,
                use: 'ts-loader',
                exclude: /node_modules/,
            },
            {
                test: /\.s[ac]ss$/i,
                use: [
					{
                        loader: 'file-loader',
                        options: { name: '[name].css'}
                    },
                    'extract-loader',
                    'css-loader',
                    {
                        loader: 'sass-loader',
                        options: {
                            // Prefer `dart-sass`
                            implementation: require('sass'),
                        },
                    },
                ],
            },
        ],
    },
    mode: "development",
    resolve: {
        extensions: ['.tsx', '.ts', '.js', '.scss', '.css'],
    },
    output: {
        path: path.resolve(__dirname, 'module'),
    },
};
