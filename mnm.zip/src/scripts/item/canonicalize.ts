
import { MnmEffectData2, MnmEquipmentEffectData2, MnmItem, MnmItemData2 } from "./item";



function safeNumber(obj: number | null | undefined, defaultRet = 0): number {
    if (obj == null)
        return defaultRet;

    if (isNaN(obj))
        return defaultRet;

    if (!isFinite(obj))
        return defaultRet;

    return obj || 0; // Normalize -0 to 0
}

// Foundry's version, but handles arrays correctly
/*export function diffObject2<T, U>(original: T, other: U): DeepPartial<T> {

    function _difference<T, U>(v0: T | undefined, v1: U | undefined): [boolean, any] {
        let t0 = getType(v0);
        let t1 = getType(v1);
        if (t0 !== t1) {
            return [true, v1];
        }
        if (Array.isArray(v0) && Array.isArray(v1)) {
            if (v0.length != v1.length) {
                return [true, v1];
            }
            for (let i = 0; i < v0.length; ++i) {
                let diff = diffObject2((v0 as any[])[i], v1[i]);
                if (!isObjectEmpty(diff)) {
                    return [true, v1];
                }
            }
            return [false, v1];
        }
        if (t0 === "Object") {
            if (isObjectEmpty(v0 as any) !== isObjectEmpty(v1 as any)) return [true, v1];
            let d = diffObject2(v0, v1);
            return [!isObjectEmpty(d as any), d];
        }
        return [v0 !== v1, v1];
    }

    // Recursively call the _difference function
    return Object.keys(other).reduce((obj, key) => {
        let [isDifferent, difference] = _difference(original[key as keyof T], other[key as keyof U]);
        if (isDifferent) (obj as any)[key] = difference;
        return obj;
    }, {}) as any;
}*/


//type V1Advantage = { "description": "<p>once per round using your reaction, place yourself between a ranged attack and the character origionally targeted. The attack targets you instead.</p>", "rank": 1 };
//type V1Effect = { "description": "<p>Immune to Fort and Will saves.</p>", "rank": 30, "basecpr": 1, "flatcost": 0 };
//type V1Equipment = { "description": "", "rank": 0, "basecpr": 0, "flatcost": 0 }
//type V1EquipmentEffect = { "description": "", "rank": 0, "basecpr": 0, "flatcost": 2 };

type V1Advantage = { "description": string, "rank": number };
type V1Effect = MnmEffectData2;
type V1EquipmentEffect = MnmEquipmentEffectData2;

//type V2Advantage = MnmAdvantageData2;

//type LatestAdvantage = V2Advantage;
type LatestEffect = V1Effect;
type LatestEquipmentEffect = V1EquipmentEffect;
//type LatestPower = V2Power;
//type LatestEffectModifier = V2EffectModifier;

// This is just an example object (with some of the properties reduced to string or number types)
//type V1 = V1Advantage | V1Effect | V1Equipment | V1EquipmentEffect
//type V2 = V2Advantage | V1Effect | V2EquipmentEffect; // V2Power | V2Effect | V2EffectModifier | 
//type LatestVersion = LatestAdvantage | LatestEffect | LatestEquipmentEffect;
//type AnyVersion = V1Advantage | LatestVersion;




// Returns a property and removes it from an object.
// Used to get and remove an obsolete property in one operation.
function siphon<T, K extends keyof T>(obj: T | undefined, key: K, transform?: (obj: Exclude<T[K], null | undefined>) => T[K]) {
    if (obj) {
        if (obj[key] != null) {
            let ret = obj[key];
            obj[key] = null!;
            return transform ? transform(ret as Exclude<T[K], null | undefined>) : ret;
        }
    }
    return undefined;
}

// Ensures the data is converted to the latest version and matches the schema exactly, also including _meta and at least an empty _derived object.
/*
export function canonicalizeItemData(data: Partial<ItemBaseData<DeepPartial<AnyVersion>>>): ItemBaseData<LatestVersion> {


    switch (data?.type) {
        case 'advantage': {
            let v1Advantage = (data.data as DeepPartial<V1Advantage> | undefined);
            let v2Advantage = (data.data as DeepPartial<V2Advantage> | undefined);
            let version = (v2Advantage?._lastConfirmedVersion ?? (v1Advantage?.rank? 1 : v2Advantage?.ranks? 2 : -1));
            const upgradingFromV1 = (version < 2);

            // This variable, existingAdvantage, should only ever be valid at most once for any item, it'll be null for all other situations and items.
            // It's exclusively used when upgrading an item from V1 to an existing V2 item.
            //const existingAdvantage = (game.items && upgradingFromV1 && data.name ? (await findExistingItem(data.name, data.type)) : null);

            const name = data.name ?? 'New Advantage';
            const img = data.img ?? '';

            let ret: ItemBaseData<LatestAdvantage> = {
                ...(data as Required<typeof data>),
                _id: data._id!,
                name,
                type: 'advantage',
                img,
                data: {
                    _derived: v2Advantage?._derived ?? {} as any,
                    category: v2Advantage?.category ?? 'general',
                    summary: v2Advantage?.summary ?? '(Advantage summary)',
                    description: (v2Advantage?.description ?? ''),
                    ranks: v2Advantage?.ranks ?? v1Advantage?.rank ?? 1,
                    maxRanks: v2Advantage?.maxRanks ?? null,
                    ranked: v2Advantage?.ranked ?? true,
                    isCustom: v2Advantage?.isCustom,
                    _lastConfirmedVersion: 2
                }
            }

            if (upgradingFromV1) {
                ret.data.ranks = (v1Advantage?.rank ?? 1);
                ret.data._eligibleForV1CompendiumRefresh = true;
                addDeletes(data, ret);
            }


            return ret;

        }

        case 'effect': {
            let v1Effect = (data?.data as DeepPartial<V1Effect> | undefined);

            let ret: ItemBaseData<LatestEffect> = {
                ...(data as Required<typeof data>),
                type: 'effect',
                data: {
                    _derived: {
                        totalCost: 0
                    },
                    basecpr: v1Effect?.basecpr ?? 1,
                    flatcost: v1Effect?.flatcost ?? 0,
                    description: v1Effect?.description ?? ('' as any),
                    rank: v1Effect?.rank ?? (1 as any)
                }
            };

            ret.data._derived.totalCost = ret.data.basecpr * ret.data.rank + ret.data.flatcost;

            return ret;
        }

        case 'equipmenteffect': {
            let v1EquipmentEffect = (data?.data as DeepPartial<V1EquipmentEffect> | undefined);

            let ret: ItemBaseData<LatestEquipmentEffect> = {
                ...(data as Required<typeof data>),
                type: 'equipmenteffect',
                data: {
                    _derived: {
                        totalCost: 0
                    },
                    basecpr: v1EquipmentEffect?.basecpr ?? 1,
                    flatcost: v1EquipmentEffect?.flatcost ?? 0,
                    description: v1EquipmentEffect?.description ?? ('' as any),
                    rank: v1EquipmentEffect?.rank ?? (1 as any)
                }
            };

            ret.data._derived.totalCost = ret.data.basecpr * ret.data.rank + ret.data.flatcost;

            return ret;

        }

        /*let v1Effect = (data?.data as DeepPartial<V1Effect> | undefined);
        let v2Effect = (data?.data as DeepPartial<V2Effect> | undefined);
        let version = (v2Effect?._lastConfirmedVersion ?? (v1Effect?.rank != null ? 1 : v2Effect?.ranks != null ? 2 : -1));
        const upgradingFromV1 = (version < 2);

        if (upgradingFromV1) {
            // Turn this effect into a power
            let v2Power: ItemData1<LatestPower> = {
                ...data,
                type: 'power',
                data: {
                    _lastConfirmedVersion: 2,
                    _derived: {} as any,
                    summary: '(Short summary of the power)',
                    description: v1Effect?.description ?? '(Detailed description of the power)',
                    effects: [],
                    additionalCost: {
                        flat: v1Effect?.flatcost ?? 0,
                        perRank: v1Effect?.basecpr ?? 1,
                        ranks: v1Effect?.rank ?? 1
                    }
                }
            };

            return v2Power;
        }
        else {
            let ret: ItemData1<LatestEffect> = {
                ...data,
                type: 'effect',
                data: {
                    _lastConfirmedVersion: 2,
                    _derived: v2Effect?._derived ?? {} as any,
                    _meta: v2Effect?._meta as any ?? { availableExclusiveModifiers: [] },
                    action: v2Effect?.action ?? 'standard',
                    summary: v2Effect?.summary ?? '(Short summary of the effect)',
                    type: v2Effect?.type ?? 'general',
                    duration: v2Effect?.duration ?? 'instant',
                    description: v2Effect?.description ?? '(Detailed description of the effect)',
                    isCustom: v2Effect?.isCustom ?? true,
                    baseCost: {
                        flat: v2Effect?.baseCost?.flat ?? 0,
                        perRank: v2Effect?.baseCost?.perRank ?? 1
                    },
                    ranks: v2Effect?.ranks ?? 1,
                    appliedModifiers: v2Effect?.appliedModifiers as any ?? [],
                    resistances: {
                        dodge: v2Effect?.resistances?.dodge ?? false,
                        fortitude: v2Effect?.resistances?.fortitude ?? false,
                        parry: v2Effect?.resistances?.parry ?? false,
                        toughness: v2Effect?.resistances?.toughness ?? false,
                        will: v2Effect?.resistances?.will ?? false
                    }
                }
            }

            return ret;
        }*/


        /*case 'equipment': {
            let v1Effect = (data.data as DeepPartial<V1Equipment> | undefined);
            return {
                ...data,
                data: <V1Equipment>{
                    basecpr: v1Effect?.basecpr ?? 1,
                    flatcost: v1Effect?.flatcost ?? 0,
                    description: v1Effect?.description ?? '',
                    rank: v1Effect?.rank ?? 1
                }
            }
        }*/

        /*case 'power': {
            let v2Power = (data.data as DeepPartial<V2Power> | undefined);
            let ret: ItemData1<LatestPower> = {
                ...data,
                data: {
                    additionalCost: {
                        flat: v2Power?.additionalCost?.flat ?? 0,
                        perRank: v2Power?.additionalCost?.perRank ?? 1,
                        ranks: v2Power?.additionalCost?.ranks ?? 1
                    },
                    description: v2Power?.description ?? '',
                    summary: v2Power?.summary ?? '',
                    effects: canonicalizeArray(v2Power?.effects as any ?? []),
                    _derived: v2Power?._derived ?? {} as any,
                    _lastConfirmedVersion: 2
                }
            }

            return ret;
        }*
    }

    return data as any;

    /*if (isV1(type, input)) {
        
        return convertV1(type, name, input);
    }
    else if (isV2(type, input)) {
        let converted = convertV2(type, name, input);
        const diff = diffObject2(input, converted);
        console.assert(isObjectEmpty(diff));
        return input;
    }
    else {
        const v1 = isV1(type, input);
        const v2 = isV2(type, input);
        // TODO: Better failsafe.
        alert("Can't confirm that your character is up to date for the latest version (just ask Matt or Doug what's up).");

        return input as LatestVersion;
    }*
}
*/
/*export function ensureLatestVersion(item: MnmItem): void {
    if (game.items) {
        const updatedData = getLatestData(item.data);
        if (!item.sentInitialUpgradeInfo) {
            item.sentInitialUpgradeInfo = true;
            const difference = diffObject2(item.data.data, updatedData);
            if (!isObjectEmpty(difference)) {
                item.update({ data: difference });
            }
        }
        item.data.data = updatedData;
    }
    else {
        item.data.data._upgradePending = true;
    }
}*/


