import { AdvantageMetadata } from "../meta";


export class AdvantageList extends Application {
    
  /** @override */
  static get defaultOptions(): ApplicationOptions & { tabs?: any } {
    return mergeObject<ApplicationOptions & { tabs?: any[] }>(super.defaultOptions, {
      classes: ["mnm", "sheet", "actor"],
      template: "systems/mnm3e/templates/item/item-advantage-list.html",
      width: 600,
      height: 600,
      tabs: [{ navSelector: ".sheet-tabs", contentSelector: ".sheet-body", initial: "description" }]
    } as any);
  }

  getData() {
      return { advantages: AdvantageMetadata };
  }

}
