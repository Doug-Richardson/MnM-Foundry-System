
import { MnmActor, MnmActorData2, MnmToken } from "./actor";
import { AbilityMetadata, AbilityType, DefenseMetadata, DefenseType, SkillMapDynamic, SkillMetadata, SkillType } from "../meta";
import { MnmItem } from "../item/item";
import { ObjectArray } from "../object-array";
import type { SkillInfo } from './actor';


function safeNumber(obj: number | null | undefined, defaultRet = 0): number {
    if (obj == null)
        return defaultRet;

    if (isNaN(obj))
        return defaultRet;

    if (!isFinite(obj))
        return defaultRet;

    return obj || 0; // Normalize -0 to 0
}

/*export function canonicalizeArray<T>(input?: T[] | null): T[];
export function canonicalizeArray<T>(input?: unknown): T[];
export function canonicalizeArray<T>(input?: any): T[] {
    if (input == null)
        return [];


    let attempt1 = Array.from(input as any);
    if (attempt1.length === 0 && 0 in input) {
        // This is actually an object whose keys are array indices
        return Object.entries(input)
            .map(([key, value]) => [+key as number, value as any])
            .filter(([key, value]) => isFinite(key))
            .sort((([lhsKey], [rhsKey]) => lhsKey - rhsKey))
            .map(([key, value]) => value);
    }
    else if (Array.isArray(attempt1)) {
        return attempt1;
    }

    return [];
}*/


type V1Advantage = { "description": "<p>once per round using your reaction, place yourself between a ranged attack and the character origionally targeted. The attack targets you instead.</p>", "rank": 1 };
type V1Effect = { "description": "<p>Immune to Fort and Will saves.</p>", "rank": 30, "basecpr": 1, "flatcost": 0 };
type V1Equipment = { "description": "", "rank": 0, "basecpr": 0, "flatcost": 0 }
type V1EquipmentEffect = { "description": "", "rank": 0, "basecpr": 0, "flatcost": 2 };

// This is just an example object (with most of the properties reduced to string or number types)
type V1 = {
    "_id": "7EGTi0F2q3ExdbsJ",
    "name": "Billy Bravado",
    "type": "character",
    "folder": unknown,
    "permission": unknown,
    "data": {
        "PLWARNabilityskill:": string,
        "PPSummary": string,
        "powerlevel": number,
        "powerpoints": { "value": number, "min": number, "max": number },
        "biography": string,
        "attributes": { "level": { "value": number } },
        "abilities": { "str": { "value": number, "damage": number, "current": number }, "dex": { "value": number, "damage": number, "current": number }, "int": { "value": number, "damage": number, "current": number }, "pre": { "value": number, "damage": number, "current": number }, "fgt": { "value": number, "damage": number, "current": number }, "agi": { "value": number, "damage": number, "current": number }, "awe": { "value": number, "damage": number, "current": number }, "sta": { "value": number, "damage": number, "current": number } },
        "defenses": { "dodge": { "value": number, "damage": number, "modifier": string, "current": number }, "parry": { "value": number, "damage": number, "modifier": string, "current": number }, "fort": { "value": number, "damage": number, "modifier": string, "current": number }, "will": { "value": number, "damage": number, "modifier": string, "current": number }, "toughness": { "value": number, "damage": number, "modifier": string, "current": number } },
        "skills": { "acrobatics": { "rank": number, "modifier": string, "spec": string, "current": number }, "athletics": { "rank": number, "modifier": string, "spec": string, "current": number }, "closecombat": { "rank": number, "modifier": string, "spec": string, "current": number }, "deception": { "rank": number, "modifier": string, "spec": string, "current": number }, "expertise": { "rank": number, "modifier": string, "spec": string, "current": number }, "insight": { "rank": number, "modifier": string, "spec": string, "current": number }, "intimidation": { "rank": number, "modifier": string, "spec": string, "current": number }, "investigation": { "rank": number, "modifier": string, "spec": string, "current": number }, "perception": { "rank": number, "modifier": string, "spec": string, "current": number }, "persuasion": { "rank": number, "modifier": string, "spec": string, "current": number }, "rangedCombat": { "rank": number, "modifier": string, "spec": string, "current": number }, "sleightofhand": { "rank": number, "modifier": string, "spec": string, "current": number }, "stealth": { "rank": number, "modifier": string, "spec": string, "current": number }, "technology": { "rank": number, "modifier": string, "spec": string, "current": number }, "treatment": { "rank": number, "modifier": string, "spec": string, "current": number }, "vehicles": { "rank": number, "modifier": string, "spec": string, "current": number } },
        "PLWARNabilityskill": string,
        "eqpoints": { "value": number, "min": number, "max": number },
        "HeroPoints": number
    },
    "sort": 100001,
    "flags": {
        "exportSource": {
            "world": "testworld2",
            "system": "mnm",
            "coreVersion": "0.6.6",
            "systemVersion": "1.0.3"
        }
    },
    "img": "Pawns/Heroes/TheFacebookMemelord.jpg",
    "token": {
        "flags": {},
        "name": "Billy Bravado",
        "displayName": 30,
        "img": "Pawns/Heroes/TheFacebookMemelord.jpg",
        "tint": "",
        "width": 1,
        "height": 1,
        "scale": 1,
        "mirrorX": false,
        "mirrorY": false,
        "lockRotation": false,
        "rotation": 0,
        "vision": true,
        "dimSight": 0,
        "brightSight": 0,
        "dimLight": 0,
        "brightLight": 0,
        "sightAngle": 360,
        "lightAngle": 360,
        "lightColor": "",
        "lightAlpha": 1,
        "actorId": "7EGTi0F2q3ExdbsJ",
        "actorLink": false,
        "actorData": {},
        "disposition": -1,
        "displayBars": 0,
        "bar1": {
            "attribute": "defenses.toughness.damage"
        },
        "bar2": {
            "attribute": ""
        },
        "randomImg": false
    },
    "items": Array<ActorBaseData<V1Advantage | V1Effect | V1Equipment | V1EquipmentEffect, { token: MnmToken, item: MnmItem }>>
}['data']
type V2 = ActorBaseData<MnmActorData2, { token: MnmToken, item: MnmItem }>['data'];

//type V1Partial = DeepPartial<V1>;
//type V2Partial = DeepPartial<V2>;


type LatestVersion = V2;

const v1 = {
    convertAbilities(abilities: DeepPartial<V1['abilities']> | undefined): LatestVersion['abilities'] {

        function convertAbility<T extends keyof NonNullable<typeof abilities>, U extends AbilityType>(v1Key: T, v2Key: U): LatestVersion['abilities'][AbilityType] {
            const ability = abilities?.[v1Key];

            return {
                absent: ability?.value == -10,
                ranks: safeNumber(ability?.value),
                temporary: safeNumber(ability?.damage) * -1,
                rollFlavorText: null,
                _derived: {} as any,
            }
        }

        return {
            str: convertAbility('str', 'str'),
            sta: convertAbility('sta', 'sta'),
            agl: convertAbility('agi', 'agl'),
            dex: convertAbility('dex', 'dex'),
            fgt: convertAbility('fgt', 'fgt'),
            int: convertAbility('int', 'int'),
            awe: convertAbility('awe', 'awe'),
            pre: convertAbility('pre', 'pre'),
        }
    },



    convertDefenses(defenses: DeepPartial<V1['defenses']> | undefined): LatestVersion['defenses'] {

        function convertDefense<T extends keyof NonNullable<typeof defenses>, U extends DefenseType>(v1Key: T, v2Key: U): LatestVersion['defenses'][U] {
            const defense = defenses?.[v1Key];

            return {
                ranks: safeNumber(defense?.value),
                temporary: safeNumber(defense?.damage) * -1,
                other: safeNumber(0),
                rollFlavorText: null,
                _meta: DefenseMetadata[v2Key],
                _derived: {} as any,
            }
        }

        return {
            dodge: convertDefense('dodge', "dodge"),
            parry: convertDefense('parry', "parry"),
            fortitude: convertDefense('fort', "fortitude"),
            toughness: convertDefense('toughness', "toughness"),
            will: convertDefense('will', "will")
        }
    },

    convertSkills(skills: DeepPartial<V1['skills']> | undefined): LatestVersion['skills'] {

        function convertSkill<T extends keyof NonNullable<typeof skills>, U extends SkillType>(v1Key: T, v2Key: U): LatestVersion['skills']['acrobatics'] {
            const skill = skills?.[v1Key];
            return {
                _meta: SkillMetadata[v2Key],
                _derived: {} as any,
                ranks: safeNumber(skill?.rank),
                other: 0,
                rollFlavorText: null,
                temporary: 0
            }
        }

        function convertMultiskill<T extends keyof NonNullable<typeof skills>, U extends SkillType>(v1Key: T, v2Key: U): LatestVersion['skills']['close_combat'] {

            const skill = skills?.[v1Key];

            const subtypes = [{ ...convertSkill(v1Key, v2Key), name: skill?.spec || v1Key || v2Key }];

            return {
                //subtypes: v2Skill?.subtypes ? ObjectArray.map(v2Skill.subtypes, subtype => ({ ...convertSkill(key, subtype), name: subtype?.name ?? '' })) : ObjectArray.fromArray([{ ...convertSkill('close_combat', v1Skill), name: siphon(v1Skill, 'spec') ?? '' }]),
                subtypes: ObjectArray.fromArray(subtypes),
                subtypeCount: subtypes.length,
                _meta: SkillMetadata[v2Key],
                _derived: {} as any,
            }
        }

        return {
            acrobatics: convertSkill('acrobatics', "acrobatics"),
            athletics: convertSkill('athletics', "athletics"),
            close_combat: convertMultiskill('closecombat', "close_combat"),
            deception: convertSkill('deception', "deception"),
            expertise: convertMultiskill('expertise', "expertise"),
            insight: convertSkill('insight', "insight"),
            intimidation: convertSkill('intimidation', "intimidation"),
            investigation: convertSkill('investigation', "investigation"),
            perception: convertSkill('perception', "perception"),
            persuasion: convertSkill('persuasion', "persuasion"),
            ranged_combat: convertMultiskill('rangedCombat', "ranged_combat"),
            sleight_of_hand: convertSkill("sleightofhand", "sleight_of_hand"),
            stealth: convertSkill('stealth', "stealth"),
            technology: convertSkill('technology', "technology"),
            treatment: convertSkill('treatment', "treatment"),
            vehicles: convertSkill('vehicles', "vehicles")
        }

    },


    convert(input: DeepPartial<V1> | undefined): V2 {
        return {
            confirmedVersion: 2,
            abilities: this.convertAbilities(input?.abilities),
            defenses: this.convertDefenses(input?.defenses),
            skills: this.convertSkills(input?.skills),
            editMode: "temp",
            heroPoints: safeNumber(input?.HeroPoints),
            biography: input?.biography || "",
            powerLevel: safeNumber(input?.powerlevel),
            powerPoints: safeNumber(input?.powerpoints?.max),
            _derived: {} as any
        }
    }

}

const v2 = {

    convertAbilities(abilities: DeepPartial<V2['abilities']> | undefined): LatestVersion['abilities'] {

        function convertAbility<T extends keyof NonNullable<typeof abilities>>(key: T): LatestVersion['abilities'][T] {
            const ability = abilities?.[key];

            return {
                absent: ability?.absent || false,
                ranks: safeNumber(ability?.ranks),
                temporary: safeNumber(ability?.temporary),
                rollFlavorText: ability?.rollFlavorText || null,
                _derived: ability?._derived ?? {} as any,
            }
        }

        return {
            str: convertAbility('str'),
            sta: convertAbility('sta'),
            agl: convertAbility('agl'),
            dex: convertAbility('dex'),
            fgt: convertAbility('fgt'),
            int: convertAbility('int'),
            awe: convertAbility('awe'),
            pre: convertAbility('pre'),
        }
    },



    convertDefenses(defenses: DeepPartial<V2['defenses']> | undefined): LatestVersion['defenses'] {

        function convertDefense<T extends DefenseType>(key: T): LatestVersion['defenses']['dodge'] {
            const defense = defenses?.[key];

            return {
                ranks: safeNumber(defense?.ranks),
                temporary: safeNumber(defense?.temporary),
                other: safeNumber(defense?.other),
                rollFlavorText: defense?.rollFlavorText,
                _meta: DefenseMetadata[key],
                _derived: (defense?._derived || {}) as any
            }
        }

        return {
            dodge: convertDefense('dodge'),
            parry: convertDefense('parry'),
            fortitude: convertDefense('fortitude'),
            toughness: convertDefense('toughness'),
            will: convertDefense('will')
        }
    },

    convertSkills(skills: DeepPartial<V2['skills']> | undefined): LatestVersion['skills'] {


        function convertSkill<T extends SkillType>(key: T, subtypeIndex?: number): LatestVersion['skills'][(Exclude<SkillType, 'close_combat' | 'expertise' | 'ranged_combat'>)] {

            let skill = skills?.[key as (Exclude<SkillType, 'close_combat' | 'expertise' | 'ranged_combat'>)];

            if (["close_combat", 'expertise', 'ranged_combat'].includes(key)) {
                skill = (skill as LatestVersion['skills']["close_combat"]).subtypes[subtypeIndex || 0] || {};
            }

            return {
                _meta: SkillMetadata[key],
                _derived: (skill?._derived || {}) as any,
                ranks: safeNumber(skill?.ranks),
                other: safeNumber(skill?.other),
                rollFlavorText: skill?.rollFlavorText,
                temporary: safeNumber(skill?.temporary)
            }
        }

        function convertMultiskill<T extends (Extract<SkillType, 'close_combat' | 'expertise' | 'ranged_combat'>)>(key: T): LatestVersion['skills']["close_combat"] {

            const skill = skills?.[key];


            let subtypes = ObjectArray.toArray<SkillInfo & { name: string; }>((skill?.subtypes ?? {}) as any);
            subtypes = subtypes.map((subtype, index) => ({ ...convertSkill(key, index), name: subtype?.name || '' }));

            let subtypeCount = skill?.subtypeCount;

            if (subtypes.length == 0) {
                subtypes.push({
                    name: "",
                    other: 0,
                    ranks: 0,
                    temporary: 0,
                    rollFlavorText: null,
                    _derived: {} as any,
                    _meta: SkillMetadata[key]
                });


                subtypeCount = 1;
            }

            return {
                //subtypes: v2Skill?.subtypes ? ObjectArray.map(v2Skill.subtypes, subtype => ({ ...convertSkill(key, subtype), name: subtype?.name ?? '' })) : ObjectArray.fromArray([{ ...convertSkill('close_combat', v1Skill), name: siphon(v1Skill, 'spec') ?? '' }]),
                subtypes: ObjectArray.fromArray(subtypes),
                subtypeCount: skill?.subtypeCount ?? subtypes.length,
                _meta: SkillMetadata[key] as any,
                _derived: (skill?._derived ?? {} as any),
            }
        }

        return {
            acrobatics: convertSkill('acrobatics'),
            athletics: convertSkill('athletics',),
            close_combat: convertMultiskill('close_combat'),
            deception: convertSkill('deception',),
            expertise: convertMultiskill('expertise',),
            insight: convertSkill('insight',),
            intimidation: convertSkill('intimidation',),
            investigation: convertSkill('investigation',),
            perception: convertSkill('perception',),
            persuasion: convertSkill('persuasion',),
            ranged_combat: convertMultiskill('ranged_combat',),
            sleight_of_hand: convertSkill('sleight_of_hand',),
            stealth: convertSkill('stealth',),
            technology: convertSkill('technology',),
            treatment: convertSkill('treatment',),
            vehicles: convertSkill('vehicles',)
        }

    },

    convert(input: DeepPartial<V2> | undefined): V2 {
        return {
            confirmedVersion: 2,
            abilities: this.convertAbilities(input?.abilities),
            defenses: this.convertDefenses(input?.defenses),
            skills: this.convertSkills(input?.skills),
            editMode: input?.editMode || "temp",
            heroPoints: safeNumber(input?.heroPoints),
            biography: input?.biography || "",
            powerLevel: safeNumber(input?.powerLevel),
            powerPoints: safeNumber(input?.powerPoints),
            _derived: (input?._derived || {}) as any
        }
    }


}


// Returns a property and removes it from an object.
// Used to get and remove an obsolete property in one operation.
/*function siphon<T, K extends keyof T>(obj: T | undefined, key: K, transform?: (obj: Exclude<T[K], null | undefined>) => T[K]) {
    if (obj) {
        if (obj[key] != null) {
            let ret = obj[key];
            // TODO: Find a way to remove the property in Foundry? The -= syntax doesn't seem to stick.
            obj[key] = null!;
            return transform ? transform(ret as Exclude<T[K], null | undefined>) : ret;
        }
    }
    return undefined;
}*/



// Foundry's version, but handles arrays correctly
/*export function diffObject2<T>(original: DeepPartial<T>, other: DeepPartial<T>): DeepPartial<T> {

    function _difference<T>(v0: T | undefined, v1: T | undefined): [boolean, any] {
        let t0 = getType(v0);
        let t1 = getType(v1);
        if (t0 !== t1) {
            return [true, v1];
        }
        if (Array.isArray(v0) && Array.isArray(v1)) {
            if (v0.length != v1.length) {
                return [true, v1];
            }
            for (let i = 0; i < v0.length; ++i) {
                let diff = diffObject2(v0[i], v1[i]);
                if (!isObjectEmpty(diff)) {
                    return [true, v1];
                }
            }
            return [false, v1];
        }
        if (t0 === "Object") {
            if (isObjectEmpty(v0 as any) !== isObjectEmpty(v1 as any)) return [true, v1];
            let d = diffObject2<any>(v0, v1);
            return [!isObjectEmpty(d as any), d];
        }
        return [v0 !== v1, v1];
    }

    // Recursively call the _difference function
    return Object.keys(other).reduce((obj, key) => {
        let [isDifferent, difference] = _difference<T>((original as any)[key as keyof T], (other as any)[key as keyof T]);
        if (isDifferent) (obj as any)[key] = difference;
        return obj;
    }, {}) as any;
}*/


/*
function convertV1(v1: V1): LatestVersion {

    return {
        abilities: V1.convertAbilities(v1.abilities),
        defenses: V1.convertDefenses(v1.defenses),
        skills: V1.convertSkills(v1.skills),
        biography: v1.biography,
        editMode: 'level-up' as const,
        powerLevel: v1.powerlevel,
        powerPoints: v1.powerpoints.max
    }
}

function convertV2(v2: V2): LatestVersion {

    return {
        abilities: V2.convertAbilities(v2.abilities),
        defenses: V2.convertDefenses(v2.defenses),
        skills: V2.convertSkills(v2.skills),
        biography: v2.biography,
        editMode: v2.editMode,
        powerLevel: v2.powerLevel,
        powerPoints: v2.powerPoints,
    }

}
*/

/*
function isV1(input: V1 | V2): input is V1 {
    return ((input as V1).powerlevel != undefined) && ((input as V2).powerLevel == undefined);
}

function isV2(input: V1 | V2): input is V2 {
    return (input as V2).powerLevel != undefined;
}*/

function stripHiddenProperties(input: any) {
    for (let key in input) {

        // Basically just assuming that nothing else in the JSON will have properties like these
        // Which is a pretty reasonable assumption I think--
        // we're in charge of everything that's in there to begin with, unless Foundary puts extra stuff in there suddenly.
        delete input._derived;
        delete input._meta;
        delete input._upgradePending;

        if (Array.isArray(input[key])) {
            for (let obj of input[key]) {
                stripHiddenProperties(obj);
            }
        }
        if ((typeof input[key] === 'object') && !Array.isArray(input[key])) {
            stripHiddenProperties(input[key]);
        }
    }
}

// Ensures the data is converted to the latest version and matches the schema exactly, also including _meta and at least an empty _derived object.
export function canonicalizeActorData(input: ActorBaseData<DeepPartial<V1> | DeepPartial<V2>, any>): ActorBaseData<LatestVersion, any> {

    const version = Math.floor((input.data as V2).confirmedVersion || 0);

    switch (version) {
        case null:
        case undefined:
        case 0:
        case 1:
        default:
            return {
                ...input,
                data: v1.convert(input.data as V1)
            }

        case 2:
            return {
                ...input,
                data: v2.convert(input.data as V2)
            }
    }
}

declare const SocketInterface: any;

/*export function ensureLatestVersion(actor: MnmActor): void {
    if (game.items) {
        const updatedData = getLatestData(actor.data.data);
        if (!actor.sentInitialUpgradeInfo) {
            actor.sentInitialUpgradeInfo = true;
            const difference = diffObject2(actor.data.data, updatedData);
            if (!isObjectEmpty(difference)) {
                // Trigger the Socket workflow
                (SocketInterface as any).dispatch("modifyDocument", {
                    type: "Actor",
                    action: "update",
                    data: [{ data: difference }],
                    options: {}
                }).then((response: any) => {

                    // Call the response handler and return the created Entities
                    const entities = (actor as any)._handleUpdate(response);
                    //actor.update({ data: difference });

                });
            }
        }
        actor.data.data = updatedData;
    }
    else {
        actor.data.data._upgradePending = true;
    }
}*/
