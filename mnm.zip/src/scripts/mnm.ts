// Import Modules

import '../lib/bootstrap.js';

import { MnmActor } from "./actor/actor.js";
import { MnmActorSheet } from "./actor/actor-sheet.js";
import { MnmItem } from "./item/item.js";
import { MnmItemSheet } from "./item/item-sheet.js";
import type { Template } from "handlebars";

declare function getTemplate(path: string): Template<any>;





Hooks.once('init', async function() {

  game.mnm = {
    MnmActor,
    MnmItem,
    //rollItemMacro
  };

  /**
   * Set an initiative formula for the system
   * @type {String}
   */
  CONFIG.Combat.initiative = {
    formula: "1d20 + @abilities.dex._derived.totalNetBonus",
    decimals: 2
  };

  // Define custom Entity classes
  CONFIG.Actor.entityClass = MnmActor as typeof Actor;
  CONFIG.Item.entityClass = MnmItem as typeof Item;


  // Register sheet application classes
  (Actors).unregisterSheet("core", ActorSheet);
  (Actors).registerSheet("mnm3e", MnmActorSheet, { makeDefault: true });
  (Items).unregisterSheet("core", ItemSheet);
  (Items).registerSheet("mnm3e", MnmItemSheet, { makeDefault: true });

  // If you need to add Handlebars helpers, here are a few useful examples:
  Handlebars.registerHelper('concat', function() {
    var outStr = '';
    for (var arg in arguments) {
      if (typeof arguments[arg] != 'object') {
        outStr += arguments[arg];
      }
    }
    return outStr;
  });

  Handlebars.registerHelper('toLowerCase', function(str) {
    return str.toLowerCase();
  });

  Handlebars.registerHelper('valueExists', function (value) {
    return value != null;
  });

  Handlebars.registerHelper('arrayLength', function (value) {
    return Array.isArray(value)? value.length : 0;
  });

  //Handlebars.registerPartial('character-skill-row', getTemplate("systems/mnm3e/templates/actor/actor-skill-row.html",))
});

Hooks.once("ready", async function() {
  // Wait to register hotbar drop hook on ready so that modules could register earlier if they want to
  //Hooks.on("hotbarDrop", (bar: unknown, data: unknown, slot: unknown) => createmnmMacro(data, slot));
  for (let actor of game.actors) {
    actor.prepareData();
  }
  for (let item of game.items) {
    item.prepareData();
  }
});

/* -------------------------------------------- */
/*  Hotbar Macros                               */
/* -------------------------------------------- */

/**
 * Create a Macro from an Item drop.
 * Get an existing item macro if one exists, otherwise create a new one.
 * @param {Object} data     The dropped data
 * @param {number} slot     The hotbar slot to use
 * @returns {Promise}
 */
/*async function createmnmMacro(data: { type: 'Item', data: Item<{}> }, slot: number) {
  if (data.type !== "Item") return;
  if (!("data" in data)) 
    return ui.notifications.warn("You can only create macro buttons for owned Items");
  const item = data.data;

  // Create the macro command
  const command = `game.mnm.rollItemMacro("${item.name}");`;
  let macro = game.macros.entities.find(m => (m.name === item.name) && (m.command === command));
  if (!macro) {
    macro = await Macro.create<Macro<MacroDataBase>>({
      name: item.name,
      type: "script",
      img: item.img,
      command: command,
      flags: { "mnm.itemMacro": true }
    });
  }
  game.user.assignHotbarMacro(macro, slot);
  return false;
}*/

/**
 * Create a Macro from an Item drop.
 * Get an existing item macro if one exists, otherwise create a new one.
 * @param {string} itemName
 * @return {Promise}
 */
/*function rollItemMacro(itemName: string) {
  const speaker = ChatMessage.getSpeaker();
  let actor;
  //if (speaker.token) 
  //  actor = game.actors.tokens[speaker.token];
  if (!actor) 
    actor = game.actors.get(speaker.actor ?? '');

  const item = actor ? actor.items.find(i => i.name === itemName) : null;
  if (!item) 
  return ui.notifications.warn(`Your controlled Actor does not have an item named ${itemName}`);

  // Trigger the item roll
  return item.roll();
}*/
