


// Copy and paste the data from template.json into this file to type-check it.

import { MnmActorData2 } from "./actor/actor";
//import { MnmEffect2Data2, MnmEffectModifierData2, MnmPowerData2 } from "./item/effect";
import type { MnmEffectData2, MnmEquipmentEffectData2 } from "./item/item";
import { MnmAdvantageData2 } from "./item/types/advantage";


const E: {
    Actor: {
        types: ['character'];
        templates?: any;
        character: { templates?: string[]; } & StripHidden<MnmActorData2>
    };
    Item: {
        types: ["advantage", "effect", "equipmenteffect"];
        templates?: any;
        advantage: { templates?: string[]; } & StripHidden<MnmAdvantageData2>;
        effect: { templates?: string[]; } & StripHidden<MnmEffectData2>;
        //effect2: { templates?: string[]; } & StripHidden<MnmEffect2Data2>;
        //power: { templates?: string[]; } & StripHidden<MnmPowerData2>;
        //effectModifier: { templates?: string[]; } & StripHidden<MnmEffectModifierData2>;
        equipmenteffect: { templates?: string[]; } & StripHidden<MnmEquipmentEffectData2>;
        //equipment: { templates?: string[]; } & StripHidden<MnmEquipmentData2>;
    };
} =


// (Paste starting after this comment)
{
    "Actor": {
        "types": [
            "character"
        ],
        "character": {
            "confirmedVersion": 2,
            "biography": "And here is where I would write my backstory... IF I HAD ONE.",
            "editMode": "level-up",
            "powerLevel": 1,
            "powerPoints": 15,
            "heroPoints": 0,
            "abilities": {
                "str": {
                    "ranks": 0,
                    "temporary": 0,
                    "absent": false
                },
                "sta": {
                    "ranks": 0,
                    "temporary": 0,
                    "absent": false
                },
                "agl": {
                    "ranks": 0,
                    "temporary": 0,
                    "absent": false
                },
                "dex": {
                    "ranks": 0,
                    "temporary": 0,
                    "absent": false
                },
                "fgt": {
                    "ranks": 0,
                    "temporary": 0,
                    "absent": false
                },
                "int": {
                    "ranks": 0,
                    "temporary": 0,
                    "absent": false
                },
                "awe": {
                    "ranks": 0,
                    "temporary": 0,
                    "absent": false
                },
                "pre": {
                    "ranks": 0,
                    "temporary": 0,
                    "absent": false
                }
            },
            "defenses": {
                "dodge": {
                    "ranks": 0,
                    "temporary": 0,
                    "other": 0
                },
                "parry": {
                    "ranks": 0,
                    "temporary": 0,
                    "other": 0
                },
                "fortitude": {
                    "ranks": 0,
                    "temporary": 0,
                    "other": 0
                },
                "toughness": {
                    "ranks": 0,
                    "temporary": 0,
                    "other": 0
                },
                "will": {
                    "ranks": 0,
                    "temporary": 0,
                    "other": 0
                }
            },
            "skills": {
                "acrobatics": {
                    "ranks": 0,
                    "temporary": 0,
                    "other": 0
                },
                "athletics": {
                    "ranks": 0,
                    "temporary": 0,
                    "other": 0
                },
                "close_combat": {
                    "subtypes": [],
                    "subtypeCount": 0
                },
                "deception": {
                    "ranks": 0,
                    "temporary": 0,
                    "other": 0
                },
                "expertise": {
                    "subtypes": [],
                    "subtypeCount": 0
                },
                "insight": {
                    "ranks": 0,
                    "temporary": 0,
                    "other": 0
                },
                "intimidation": {
                    "ranks": 0,
                    "temporary": 0,
                    "other": 0
                },
                "investigation": {
                    "ranks": 0,
                    "temporary": 0,
                    "other": 0
                },
                "perception": {
                    "ranks": 0,
                    "temporary": 0,
                    "other": 0
                },
                "persuasion": {
                    "ranks": 0,
                    "temporary": 0,
                    "other": 0
                },
                "ranged_combat": {
                    "subtypes": [],
                    "subtypeCount": 0
                },
                "sleight_of_hand": {
                    "ranks": 0,
                    "temporary": 0,
                    "other": 0
                },
                "stealth": {
                    "ranks": 0,
                    "temporary": 0,
                    "other": 0
                },
                "technology": {
                    "ranks": 0,
                    "temporary": 0,
                    "other": 0
                },
                "treatment": {
                    "ranks": 0,
                    "temporary": 0,
                    "other": 0
                },
                "vehicles": {
                    "ranks": 0,
                    "temporary": 0,
                    "other": 0
                }
            }
        }
    },
    "Item": {
        "types": [
            "advantage",
            "effect",
            "equipmenteffect"
        ],
        "advantage": {
            "confirmedVersion": 2,
            "isCustom": false,
            "summary": "(Advantage summary)",
            "description": "(Advantage description)",
            "ranked": false,
            "ranks": 1,
            "maxRanks": null,
            "category": "general"
        },
        "equipmenteffect": {
            "confirmedVersion": 1,
            "rank": 0,
            "basecpr": 0,
            "flatcost": 0,
            "description": ""
        },
        "effect": {
            "confirmedVersion": 1,
            "rank": 0,
            "basecpr": 0,
            "flatcost": 0,
            "description": ""
        }
    }
}


// (Paste up until this comment)






type StripHidden<T> =
    T extends number ? number :
    T extends string ? string :
    T extends boolean ? boolean :
    T extends null ? null :
    T extends undefined ? never :
    T extends (infer U)[] ? StripHidden<U>[] :
    {
        [P in Exclude<keyof T, '_derived' | '_meta' | '_upgradePending' | '_lastConfirmedVersion' | 'eligibleForV1CompendiumRefresh' | 'rollFlavorText'>]: StripHidden<T[P]>
    }



//)

/*
TemplateData.Actor.character.



// Implementation stuff
type TemplateInfo<Types extends string> = {
    types: Types[];
    templates?: { [k: string]: unknown; };
} & {
    [k in Types]: {
        templates?: string[];
        [l: string]: unknown
    };
}

interface FttTemplateSchema<ActorTypes extends string, ItemTypes extends string> {
    Actor: TemplateInfo<ActorTypes>;
    Item: TemplateInfo<ItemTypes>;
}

function T<A extends string, I extends string>(t: FttTemplateSchema<A, I>)
{
    t.Actor.
    return t;
}*/
